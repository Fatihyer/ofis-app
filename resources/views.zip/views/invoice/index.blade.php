@extends('layouts.app')
@section('content')
    <div class="row">
        <div class="col-lg-12 grid-margin">
            <div class="card">
                <div class="card-body">
                    <h4 class="card-title">Invoices</h4>
                    Page {{ $invoices->currentPage() }} of {{ $invoices->lastPage() }}
                    <div class="table-responsive">
                        <form action="{{ route('invoices.index') }}" method="GET">
                            <div class="form-group">
                                <label for="search">Search:</label>
                                <input type="text" name="search" id="search" class="form-control" placeholder="Enter search keyword">
                            </div>
                        </form>
                        <table class="table table-bordered">
                            <thead>
                                <tr>
                                    <th scope="col">@sortablelink('sirket_id','Company')</th>
                                    <th scope="col">@sortablelink('id','Proforma No')</th>
                                    <th scope="col">File NO</th>
                                    <th scope="col">@sortablelink('acente_id','Acente')</th>
                                    <th scope="col">@sortablelink('acente_id','Date')</th>
                                    <th scope="col">Amount</th>
                                    <th scope="col">@sortablelink('resmi','Invoice #')</th>
                                    <th scope="col">Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                @foreach ($invoices as $invoice)
                                <tr>
                                    <td>{{ $invoice->sirket->name}}</td>
                                    <th scope="row"><a href="{{ route('invoicetopdf',[$invoice->id,'html']) }}"><b>{{ $invoice->id}}</b></a></th>
                                    <td><a href="{{ route('posts.show', $invoice->post_id ) }}"><b>{{ $invoice->post->id}}</b></a></td>
                                    <td><a href="{{ route('acentes.show', $invoice->acente_id ) }}"><b>{{ isset($invoice->acente->name)?$invoice->acente->name:""}}</b></a></td>
                                    <td>{{ date("d-m-Y", strtotime($invoice->tarih))}}</td>
                                    <td>{{ $invoice->amount}} {{ $invoice->kur->short_name }}</td>
                                    <td>
                                    @if (isset($invoice->avoir)) 
                                    AVOIR {{ $invoice->avoir }} 
                                    @else
                                    FACTURE
                                    {{ $invoice->resmi }}
                                    @endif
                                </td>
                                    <td>
                                        <div class="btn-group btn-group-toggle">
                                            <a href="{{ route('invoices.edit',$invoice->id)}}" class="btn btn-primary"><i class="fas fa-edit"></i></a>
                                            <a class="btn btn-success" href="{{ route('invoicetopdf',[$invoice->id,'pdf']) }}"><i class="fas fa-file-pdf"></i></a>
                                            <a class="btn btn-secondary" href="{{ route('invoicetopdf',[$invoice->id,'pdf2']) }}"><i class="fas fa-file-pdf"></i></a>
                                            <a class="btn btn-primary" href="{{ route('invoicetopdf',[$invoice->id,'html']) }}"><i class="fab fa-internet-explorer"></i></a>
                                            <form class="deleteinvoice" action="{{ route('invoices.destroy', $invoice->id) }}" method="POST">
                                                {{ method_field('DELETE') }}
                                                {{ csrf_field() }}
                                                <button class="btn btn-danger"><i class="fas fa-trash-alt"></i></button>
                                            </form>
                                        </div>
                                    </td>
                                </tr>
                                @endforeach
                            </tbody>
                        </table>
                    </div>
                    <div class="text-center">
                        {!! $invoices->appends(request()->except('page'))->links() !!}
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection

@section('footer')
<script>
    jQuery(document).ready(function($){
        $('.deleteinvoice').on('submit', function(e){
            if(!confirm('Do you want to delete this item?')){
                e.preventDefault();
            }
        });
    })
</script>
@endsection
