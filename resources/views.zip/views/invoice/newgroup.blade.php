@extends('layouts.app')
@section('style')

 <style>
#kds ul {height:300px;overflow-y:scroll;}
</style>

@endsection
@section('title', '| New Group Proforma')
@section('style')
<link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">
 <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-multiselect/0.9.13/css/bootstrap-multiselect.css" type="text/css"/>

@endsection
@section('content')
<div id="kds">
  
       {{ Form::open(array('route' => 'groupinvoices.store')) }}
                   
                          
                 {{Form::label('date','Proforma Date')}}   
                 {{Form::date('tarih',"", array('class' => 'form-control', 'id'=>'invoicetarih')) }}
                 {{Form::label('resmi','Invoice no')}}   
                 {{Form::text('resmi',null, array('class' => 'form-control')) }} 
                 {{Form::select('invoicelist[]',$invoices,"",array('multiple'=>'multiple','class' => 'form-control','id'=>'multiselect'))}}
                 {{Form::select('sirket_id',$sirkets,"",array('class' => 'form-control'))}}
                 {{Form::submit('save',null,array('class'=>'form-control'))}}
        
{{form::close()}}
</div>
            
@endsection
@section('footer')
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
  <script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-multiselect/0.9.13/js/bootstrap-multiselect.js"></script>
<script type="text/javascript">
    $(document).ready(function() {
        $('#multiselect').multiselect({
            buttonWidth: '400px'
        });
    });
</script>
<style type="text/css">
    .multiselect-container {
        width: 100% !important;
    }
</style>
@endsection