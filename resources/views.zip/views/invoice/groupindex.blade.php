@extends('layouts.app')
@section('content')
  
        <div class="row">
          
                <div class="col-lg-12 grid-margin">
                    <div class="card">
                      <div class="card-body">
                        <h4 class="card-title">Invoices</h4>  Page {{ $groupinvoices->currentPage() }} of {{ $groupinvoices->lastPage() }}
                        <div class="table-responsive">
                          <table class="table table-bordered">
                            <thead>
           
                                <tr>
                                  <th scope="col">GrProforma/Invoice No </th>
                                  <th scope="col">File NO </th>
                                  <th scope="col">Agency </th>
                                  <th scope="col">Date</th>
                                  <th scope="col">Amount</th>
                                  <th scope="col">Invoice No</th>
                                
                                  <th scope="col">#</th>
                                </tr>
                              </thead>
                              <tbody>
                    @foreach ($groupinvoices as $groupinvoice)
                     <tr>
                                    <th scope="row"><a href="{{ route('grinvoicetopdf',[$groupinvoice->id,'html']) }}"><b>{{$groupinvoice->id}}</b></a>/
                       {{$groupinvoice->resmi}} <br/>
                       {{$groupinvoice->sirket->name}}             
                       
                       </th>
                                      <td>
                                         @foreach($groupinvoice->invoices as $invoice)
                                     <a href="{{ route('posts.show', $invoice->post_id ) }}"> {{$invoice->post_id}}</a>
                                    @endforeach  
                                        
                                       </td> 
                                     <td>
                                      @if(isset($groupinvoice->invoices[0]))
                                      <a href="{{ route('acentes.show', $groupinvoice->invoices[0]->acente_id ) }}"><b>{{$groupinvoice->invoices[0]->acente->name}}</b></a>
                                    @endif
                                    
                                    </td>
                                 
                                     <td>{{ date("d-m-Y", strtotime($groupinvoice->tarih))}}</td>
                                    <td>
                                     {{$groupinvoice->invoices->sum('amount')}}
                                  </td>
                                    <td> @foreach($groupinvoice->invoices as $invoice)
                                     <a href="{{ route('invoices.edit', $invoice->id ) }}"> {{$invoice->id}}</a>
                                    @endforeach  </td>
                                    <td>
                                     <div class="btn-group btn-group-toggle">
                                         <a  href="{{route('groupinvoices.edit',$groupinvoice->id)}}" class="btn btn-primary"><i class="fas fa-edit"></i></a>
                                       <a  class="btn btn-success" href="{{ route('grinvoicetopdf',[$groupinvoice->id,'pdf']) }}"><i class="fas fa-file-pdf"></i></a>
                                       <a  class="btn btn-secondary" href="{{ route('invoicetopdf',[$groupinvoice->id,'xls']) }}"><i class="fas fa-file-excel"></i></a>
                                       @if(isset($groupinvoice->invoices[0]))
                                       <a  class="btn btn-primary" href="{{ route('acentes.show', $groupinvoice->invoices[0]->acente_id ) }}"><i class="fab fa-internet-explorer"></i></a>
                                       @endif
                                      </li>
        </ul> 
                                       
                                       <form  class="deleteinvoice" action="{{ route('groupinvoices.destroy', $groupinvoice->id) }}" method="POST">
                                          {{ method_field('DELETE') }}
                                          {{ csrf_field() }}
                                          <button class="btn btn-danger" ><i class="fas fa-trash-alt"></i></button>
                                          
                                        </form>
                                      </div>
                                      
                       </td>      
                              
                     
                                   
                                  </tr>
                       
                       
                    @endforeach
                      </tbody></table>
                    </div>
                    <div class="text-center">
                        {!! $groupinvoices->links() !!}
                    </div>
                </div>
            </div>
</div>
</div>

@endsection
@section('footer')
<script>
jQuery(document).ready(function($){
     $('.deleteinvoice').on('submit',function(e){
        if(!confirm('Do you want to delete this item?')){
              e.preventDefault();
        }
      });
})
</script>
@endsection