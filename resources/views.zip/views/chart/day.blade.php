@extends('layouts.app')
@section('style')
<link href="{{ asset('css/daterangepicker.css') }}" rel="stylesheet">
@endsection

@section('content')

<div class="container-fluid">

    <div class="row">
        <div class="col-md-12">
        <form method="get" name="tarih" class="form-inline">
    @php
        $today = date('Y-m-d');
        $startDate = request('start_date') ?? $today;
        $yesterday = date('Y-m-d', strtotime('-1 day'));
        $tomorrow = date('Y-m-d', strtotime('+1 day'));
        $prevDate = date('Y-m-d', strtotime($startDate . ' -1 day'));
        $nextDate = date('Y-m-d', strtotime($startDate . ' +1 day'));
    @endphp

    <!-- Yesterday Button -->
  
    <a href="{{ route('day', ['start_date' => $yesterday, 'acente' => request('acente'), 'airportshuttle' => request('airportshuttle')]) }}" 
       class="btn {{ request('start_date') === $yesterday ? 'btn-secondary' : 'btn-light' }}">
        Yesterday
    </a>

    <!-- Today Button -->

    <a href="{{ route('day', ['start_date' => $today, 'acente' => request('acente'), 'airportshuttle' => request('airportshuttle')]) }}" 
       class="btn {{ request('start_date') === $today || !request('start_date') ? 'btn-secondary' : 'btn-light' }}">
        Today
    </a>

    <!-- Tomorrow Button -->
  
    <a href="{{ route('day', ['start_date' => $tomorrow, 'acente' => request('acente'), 'airportshuttle' => request('airportshuttle')]) }}" 
       class="btn {{ request('start_date') === $tomorrow ? 'btn-secondary' : 'btn-light' }}">
        Tomorrow
    </a>
    <a href="{{ route('day') }}?start_date={{ $prevDate }}&acente={{ request('acente') }}&airportshuttle={{ request('airportshuttle') }}"
   class="btn btn-light">
    &#9664; <!-- Left Arrow -->
</a>

    <!-- Date Picker -->
    <input type="text" name="daterange" class="form-control ml-2" 
           value="{{ date('d/m/Y', strtotime(request('start_date') ?? $today)) }}">
    <input type="hidden" name="start_date" id="hiddenStartDate"/>
    <input type="hidden" name="acente" value="{{ request('acente') }}">
<input type="hidden" name="airportshuttle" value="{{ request('airportshuttle') }}">

    <a href="{{ route('day') }}?start_date={{ $nextDate }}&acente={{ request('acente') }}&airportshuttle={{ request('airportshuttle') }}"" 
           class="btn btn-light">
            &#9654; <!-- Right Arrow -->
        </a>
        <select name="acente" class="form-control ml-2" onchange="this.form.submit()">
    <option value="">Tümü</option>
    @foreach ($acenteListesi as $acente)
        <option value="{{ $acente }}" {{ request('acente') == $acente ? 'selected' : '' }}>
            {{ $acente }}
        </option>
    @endforeach
</select>   
<div class="form-group ml-2">
    <label>Airport Shuttle:</label><br>
    <label class="form-check-label mr-2">
        <input type="radio" name="airportshuttle" value="" 
               class="form-check-input" onchange="this.form.submit()" 
               {{ request('airportshuttle') === null ? 'checked' : '' }}> All
    </label>
    <label class="form-check-label mr-2">
        <input type="radio" name="airportshuttle" value="yes" 
               class="form-check-input" onchange="this.form.submit()" 
               {{ request('airportshuttle') === 'yes' ? 'checked' : '' }}> Yes
    </label>
    <label class="form-check-label mr-2">
        <input type="radio" name="airportshuttle" value="no" 
               class="form-check-input" onchange="this.form.submit()" 
               {{ request('airportshuttle') === 'no' ? 'checked' : '' }}> No
    </label>
</div>
    </form>
    
        
<div class="mt-3 mb-3">
            <a class="btn btn-primary" href="{{route('vehiculescontrol')}}">Vehicule Usage</a>
            <a class="btn btn-primary" href="{{route('driverUsage.index')}}">Driver Usage</a>
            <a class="btn btn-success" href="{{ route('heuredetravail') }}">Heure de Travail</a>
            <a href="{{route('driver-calendar')}}" class="btn btn-info">Driver Work Time</a>   
        </div>   
       
  </div>
        </div>
    </div>  

    <div class="row mt-4">
        @foreach ($data as $key => $value)
            <div onclick="location.href='{{route('transfers.show', $value->id)}}';" class="col-3 border border-dark" style="text-align: center; background:{{ isset($value->driver->color) ? $value->driver->color : '' }}; color:{{ isset($value->driver->color) ? '#FFF' : '#000' }}; cursor: pointer;">
                <br>
                @if (in_array($value->servicetype_id, $congeIds))
                    <h4 class="align-middle">{{$value->servicetype->name}}</h4>
                @else
                <h5>
                    @if ($value->ofis_start == null) 
                        <span class="text-danger">?</span>
                    @else 
                        RDV Depot {{ date('H:i', strtotime($value->ofis_start)) }} 
                    @endif 
                </h5>
                <br><br>
                @php
                $surplaceBefore = \App\Option::where('name', 'surplaceMinBefore')->value('value') ?? 15;
                $surplaceTime = \Carbon\Carbon::parse($value->start_date)->subMinutes($surplaceBefore);
            @endphp
            <h3 class="align-middle">Sur Place {{ $surplaceTime->format('H:i') }}</h3>
               <h3 class="align-"> PEC {{ date('H:i', strtotime($value->start_date)) }} </h3>
                @endif
            </div>

            <div class="col-9 border border-{{isset($value->status->color->name)?$value->status->color->name:''}}">
                <p> @if ($value->post->user)
                    <span class="text-warning">{{$value->post->user->name}}</span>
                @endif
                    <span class="badge-{{isset($value->status->color->name)?$value->status->color->name:''}}">{{isset($value->status->name)?$value->status->name:''}}</span>
                    <a href="{{route('posts.show', $value->post_id)}}">{{$value->post_id}}</a>
                    Fin: {{date('H:i', strtotime($value->end_date))}} Duration: <?php $dateDiff = intval((strtotime($value->end_date)) - strtotime($value->start_date)) / 60; ?> {{ intval($dateDiff / 60) }}h{{ $dateDiff % 60 }}m ||
                    @if (isset($value->driver->id))
                        <a href="{{route('acentes.show', $value->driver->id)}}" style="color:{{ isset($value->driver->color) ? $value->driver->color : '' }};">{{ $value->driver->name }}</a>

                        <a href="#" class="driver-name" data-driver-id="{{$value->driver->id }}" data-driver-name="{{ $value->driver->name }}"><i class="fa fa-calendar"></i></a>
                        <a href="#" class="driver-calendar" data-driver-id="{{ $value->driver->id }}" data-driver-name="{{ $value->driver->name }}">View Calendar</a>
                      
                        <span class="driver-days" data-driver-id="{{ $value->driver->id }}" data-driver-name="{{ $value->driver->name }}"></span>
                        <strong>{{ $value->servicetype->name }}</strong>
                        <i><a href="{{ route('vehicules.show', $value->vehicule_id) }}">{{ isset($value->vehicule->name) ? $value->vehicule->name : '' }}</a></i>
                        @if (isset($value->harekets[0]->payment->color_id))
                            <span class="badge-{{$value->harekets[0]->payment->color->name}}">{{$value->harekets[0]->payment->name}}</span>
                           
                            @hasrole('Admin')
                            <br> Sale price: {{$value->harekets[0]->default_price}} Buying Price {{$value->harekets[0]->amount}}
                            @endhasrole
                            @endif
                    @else
                        NO DRIVER
                    @endif
                   
                    <br> <a href="{{ route('acentes.show', $value->post->acente->id) }}"> {{$value->post->acente->name}}</a> <strong>{{$value->pax}}pax 
                        From:</strong>{{$value->from}}<strong> To:</strong> {{$value->target}} ***{{$value->comments}}
                        @php
                        $googleAddresses = $value->trajets->pluck('google_address');
                        $origin = $googleAddresses->first(); // İlk değer origin
                        $destination = $googleAddresses->last(); // Son değer destination
                        $waypoints = $googleAddresses->slice(1, $googleAddresses->count() - 2)->implode('|'); // Aradakiler waypoints
                        @endphp
                      
                        @foreach ($value->trajets as $index => $trajet)

                     

                        <span class="badge badge-primary badge-pill">{{$index+1 }}</span>
                        {{date('H:i', strtotime($trajet->datetime))}}
                        {{$trajet->type}}:
                                            {{$trajet->from}}
                                            {{$trajet->google_address}}
                        @endforeach
                        KM: {{$value->km}}
                        <a href="https://www.google.com/maps/dir/?api=1&origin={{ $origin }}&waypoints={{ $waypoints }}&destination={{ $destination }}" target="_blank">
                            Open in Google Maps
                    </a>
                </p>
                <p>Name:
                    @foreach ($value->post->client as $misafir)
                        {{$misafir->tittle}} {{$misafir->name}} {{$misafir->surname}} {{$misafir->tel}}<br>
                    @endforeach
                </p>
                Mission: 
                @if (isset($value->missionr->hareket))
                    Dep Bourget: {{date('H:i', strtotime($value->missionr->hareket))}}, Sur place: {{date('H:i', strtotime($value->missionr->surplace))}}, On board: {{date('H:i', strtotime($value->missionr->taked))}}, Finish: {{date('H:i', strtotime($value->missionr->finish))}}
                @else
                    No mission assigned
                @endif
             <!-- Superadmin-only content -->
        @if (Auth::user() && Auth::user()->role === 'superadmin')
                
          
            <?php $datestart = \Carbon\Carbon::parse($value->start_date);
            $dateend = \Carbon\Carbon::parse($value->end_date);
            $ofisstart = $value->ofis_start ? \Carbon\Carbon::parse($value->ofis_start) : NULL;    ?>

            <a class="btn btn-primary btn-sm" href="#"  data-toggle="modal" 
            data-id="{{$value->id}}"
            data-servicetype="{{$value->servicetype->id}}"
            data-date="{{$datestart->format('Y-m-d')}}"
            data-time="{{$datestart->format('H:i')}}"

            data-dateend="{{$dateend->format('Y-m-d')}}"
            data-endtime="{{$dateend->format('H:i')}}"

            data-ofisdate="<?php echo e($ofisstart ? $ofisstart->format('Y-m-d') : ''); ?>"
            data-ofistime="<?php echo e($ofisstart ? $ofisstart->format('H:i') : ''); ?>"
            
            data-from="{{$value->from}}"
            data-to="{{$value->target}}"
            data-vehicule="{{$value->vehicule?$value->vehicule->id:''}}"
            data-driver="{{isset($value->driver->id)?$value->driver->id:""}}" 
            data-pax="{{$value->pax}}"
            data-comments="{{$value->comments}}"
            data-mission="{{$value->mission}}"
            data-firma="{{(isset($value->driver->firmas[0])?$value->driver->firmas[0]->id:0)}}"
            data-status="{{$value->status_id}}"
            data-target="#edittransfert">Edit</a>
            <a href="{{route('transfers.edit',$value->id)}}">Edit++</a>
            @endif
        </div>
      
        @endforeach
   
    </div>

    <!-- Modal -->
   <!-- Modal HTML -->
<div class="modal fade" id="driverModal" tabindex="-1" role="dialog" aria-labelledby="driverModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="driverModalLabel">Driver Work Hours</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <ul id="workHoursList" class="list-group">
                    <!-- List of work hours will be appended here by JavaScript -->
                </ul>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>

<!-- Calendar Modal HTML -->
<div class="modal fade" id="calendarModal" tabindex="-1" role="dialog" aria-labelledby="calendarModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="calendarModalLabel">Driver Monthly Calendar</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <div class="d-flex justify-content-between mb-3">
                    <a href="#" id="prevMonth" class="btn btn-outline-primary">&larr; Previous Month</a>
                    <span id="driverName"></span>
                    <a href="#" id="nextMonth" class="btn btn-outline-primary">Next Month &rarr;</a>
                </div>
                <table id="calendarTable" class="table table-bordered">
                    <thead>
                        <tr>
                            <th>Lundi</th>
                            <th>Mardi</th>
                            <th>Mercredi</th>
                            <th>Jeudi</th>
                            <th>Vendredi</th>
                            <th>Samedi</th>
                            <th>Dimanche</th>
                        </tr>
                    </thead>
                    <tbody>
                        <!-- Calendar days will be appended here by JavaScript -->
                    </tbody>
                </table>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>
@include ('transfert.edit') {{-- Including create blade file --}}
@endsection

@section('footer') 

<script src="{{ asset('/js/moment.min.js') }}"></script>
<script src="{{ asset('/js/daterangepicker.js') }}"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>

<script>
    $(document).ready(function() {
        $('input[name="daterange"]').daterangepicker({
            singleDatePicker: true,
            locale: {
                format: 'DD/MM/YYYY'
            }
        });

        $('input[name="daterange"]').on('apply.daterangepicker', function(ev, picker) {
            $('#hiddenStartDate').val(picker.startDate.format('YYYY-MM-DD'));
            document.forms['tarih'].submit();
        });

        function getMonthName(monthNumber) {
            const monthNames = [
                "Janvier", "Février", "Mars", "Avril", "Mai", "Juin", "Juillet",
                "Août", "Septembre", "Octobre", "Novembre", "Décembre"
            ];
            return monthNames[monthNumber - 1];
        }

        // Fetch driver work days
        $.ajax({
            url: '{{ route("getDriverWorkDays") }}',
            type: 'GET',
            dataType: 'json',
            success: function(response) {
                $('.driver-days').each(function() {
                    var driverId = $(this).data('driver-id');
                    var driverData = response.driverWorkDays.find(driver => driver.driver_id == driverId);
                    if (driverData) {
                        var badge = '<span class="badge badge-info">' + driverData.days_worked + ' days</span>';
                        $(this).html(badge);
                    }
                });
            },
            error: function(xhr, status, error) {
                console.error(error);
            }
        });

        $('.driver-name').on('click', function(e) {
            e.preventDefault();
            var driverId = $(this).data('driver-id');
            var driverName = $(this).data('driver-name');
            $.ajax({
                url: '{{ url("/get-driver-hours") }}/' + driverId,
                type: 'GET',
                dataType: 'json',
                success: function(response) {
                    var workHoursList = $('#workHoursList');
                    workHoursList.empty();

                    if (response.hoursWorked.length === 0) {
                        workHoursList.append('<li class="list-group-item">Not Work</li>');
                    } else {
                        $.each(response.hoursWorked, function(index, work) {
                            var listItem = '<li class="list-group-item' + (work.hours_worked === 'congé' ? ' text-danger' : '') + '">' +
                                work.date + ': ' + work.hours_worked +
                                '</li>';
                            workHoursList.append(listItem);
                        });
                    }

                    $('#driverModalLabel').text('Driver: ' + driverName + ' Work Hours');
                    $('#driverModal').modal('show');
                },
                error: function(xhr, status, error) {
                    console.error(error);
                }
            });
        });

        // Show modal on driver name click
        $('.driver-calendar').on('click', function(e) {
            e.preventDefault();
            var driverId = $(this).data('driver-id');
            var driverName = $(this).data('driver-name');
            loadMonthlyCalendar(driverId, driverName, new Date().getFullYear(), new Date().getMonth() + 1);
        });

        function loadMonthlyCalendar(driverId, driverName, year, month) {
            $.ajax({
                url: '{{ url("/get-driver-monthly-calendar") }}/' + driverId + '/' + year + '/' + month,
                type: 'GET',
                dataType: 'json',
                success: function(response) {
                    var calendarTable = $('#calendarTable tbody');
                    calendarTable.empty();

                    var daysInMonth = new Date(year, month, 0).getDate();
                    var startDate = new Date(year, month - 1, 1);
                    var dayOfWeek = startDate.getDay() || 7; // Adjust for Monday start

                    // Generate calendar rows and cells
                    var row = $('<tr></tr>');
                    for (var i = 1; i < dayOfWeek; i++) {
                        row.append('<td></td>');
                    }
                    for (var day = 1; day <= daysInMonth; day++) {
                        if (dayOfWeek > 7) {
                            calendarTable.append(row);
                            row = $('<tr></tr>');
                            dayOfWeek = 1;
                        }

                        var date = year + '-' + (month < 10 ? '0' : '') + month + '-' + (day < 10 ? '0' : '') + day;
                        var dayContent = response.calendar[date] === 'congé' ? '<span class="text-danger">' + day + '</span>' : day;

                        row.append('<td>' + dayContent + '</td>');
                        dayOfWeek++;
                    }
                    if (row.children().length) {
                        calendarTable.append(row);
                    }

                    var monthName = getMonthName(month);

                    $('#calendarModalLabel').text('Driver: ' + driverName + ' - ' + monthName + ' ' + year);
                    $('#prevMonth').data('driver-id', driverId).data('driver-name', driverName).data('year', year).data('month', month - 1);
                    $('#nextMonth').data('driver-id', driverId).data('driver-name', driverName).data('year', year).data('month', month + 1);
                    $('#calendarModal').modal('show');
                },
                error: function(xhr, status, error) {
                    console.error(error);
                }
            });
        }

        $('#prevMonth').on('click', function(e) {
            e.preventDefault();
            var driverId = $(this).data('driver-id');
            var driverName = $(this).data('driver-name');
            var year = $(this).data('year');
            var month = $(this).data('month');

            if (month < 1) {
                year--;
                month = 12;
            }

            loadMonthlyCalendar(driverId, driverName, year, month);
        });

        $('#nextMonth').on('click', function(e) {
            e.preventDefault();
            var driverId = $(this).data('driver-id');
            var driverName = $(this).data('driver-name');
            var year = $(this).data('year');
            var month = $(this).data('month');

            if (month > 12) {
                year++;
                month = 1;
            }

            loadMonthlyCalendar(driverId, driverName, year, month);
        });
    });
</script>

@include ('transfert.createEdit-js') {{-- Including create blade file --}}


@endsection
