@extends('layouts.app')
@section('style')
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/fullcalendar/3.9.0/fullcalendar.min.css"/>
<style>
    /* Yükleme animasyonu için stil */
    .loading-spinner {
        display: none;
        position: fixed;
        top: 50%;
        left: 50%;
        transform: translate(-50%, -50%);
        z-index: 1000;
        width: 50px;
        height: 50px;
        border: 5px solid #f3f3f3;
        border-top: 5px solid #3498db;
        border-radius: 50%;
        animation: spin 1s linear infinite;
    }

    @keyframes spin {
        0% { transform: rotate(0deg); }
        100% { transform: rotate(360deg); }
    }
</style>
@endsection

@section('content')
<div class="row">
    <!-- Yükleme animasyonu -->
    <div class="loading-spinner" id="loadingSpinner"></div>
    <div id="calendar"></div>
</div>
@endsection

@section('footer')
<script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.9.0/moment.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/fullcalendar/3.9.0/fullcalendar.min.js"></script>
<script>
$(document).ready(function() {
    $('#calendar').fullCalendar({
        events: @if($file==1) '/events' @else '/files' @endif, // URL to fetch events

        // Yükleme sırasında gösterilecek animasyon
        loading: function(isLoading) {
            if (isLoading) {
                $('#loadingSpinner').show(); // Yükleme animasyonunu göster
            } else {
                $('#loadingSpinner').hide(); // Yükleme animasyonunu gizle
            }
        },

        eventRender: function(event, element) {
            element.attr('title', event.description); // Add tooltip for description
            element.attr('href', event.url); // Add link to event
        }
    });
});
</script>
@endsection
