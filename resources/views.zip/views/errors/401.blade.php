@extends('layouts.app')

@section('content')
 <div class="container"> 
    <div class='col-lg-4 col-lg-offset-4'>
        <h1><center>401<br>
        ACCESS DENIED</center></h1>
    </div>
</div>
@endsection