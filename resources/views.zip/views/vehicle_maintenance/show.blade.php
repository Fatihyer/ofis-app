@extends('layouts.app')

@section('content')
<div class="container">
    <h1>Vehicle Maintenance Record</h1>
    <div class="card">
        <div class="card-header">
            Maintenance Record #{{ $maintenance->id }}
        </div>
        <div class="card-body">
            <p><strong>Vehicule:</strong> {{ $maintenance->vehicule->name }}</p>
            <p><strong>Description:</strong> {{ $maintenance->description }}</p>
            <p><strong>Maintenance Date:</strong> {{ $maintenance->service_date }}</p>
            <p><strong>Amount:</strong>{{$maintenance->amount}}</p>
        </div>
    </div>
    <a href="{{ route('vehicle_maintenance.index') }}" class="btn btn-secondary mt-3">Back to List</a>
</div>
@endsection
