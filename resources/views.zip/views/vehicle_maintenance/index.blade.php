@extends('layouts.app')

@section('content')
<div class="container">
    <h1>Vehicle Maintenance Records</h1>
    <a href="{{ route('vehicle_maintenance.create') }}" class="btn btn-primary">Add Maintenance Record</a>
    @if(session('success'))
        <div class="alert alert-success">{{ session('success') }}</div>
    @endif
    <table class="table table-striped">
        <thead>
            <tr>
                <th>ID</th>
                <th>Vehicule</th>
                <th>Description</th>
                <th>Maintenance Date</th>
                <th>Amount</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            @foreach($maintenances as $maintenance)
                <tr>
                    <td>{{ $maintenance->id }}</td>
                    <td>{{ $maintenance->vehicule->name }}</td>
                    <td>{{ $maintenance->description }}</td>
                    <td>{{ $maintenance->service_date }}</td>
                    <td>{{ $maintenance->amount }}</td>
                    <td>
                        <a href="{{ route('vehicle_maintenance.show', $maintenance->id) }}" class="btn btn-info">View</a>
                        <a href="{{ route('vehicle_maintenance.edit', $maintenance->id) }}" class="btn btn-warning">Edit</a>
                        <form action="{{ route('vehicle_maintenance.destroy', $maintenance->id) }}" method="POST" style="display:inline;">
                            @csrf
                            @method('DELETE')
                            <button type="submit" class="btn btn-danger">Delete</button>
                        </form>
                    </td>
                </tr>
            @endforeach
        </tbody>
    </table>
</div>
@endsection
