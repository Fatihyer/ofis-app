@extends('layouts.app')

@section('content')
<div class="container">
    <h1>Add Vehicle Maintenance Record</h1>
    <form action="{{ route('vehicle_maintenance.store') }}" method="POST">
        @csrf
        <div class="form-group">
            <label for="vehicule_id">Vehicule</label>
            <select name="vehicule_id" id="vehicule_id" class="form-control">
                @foreach($vehicules as $vehicule)
                    <option value="{{ $vehicule->id }}">{{ $vehicule->name }}</option>
                @endforeach
            </select>
        </div>
        <div class="form-group">
            <label for="description">Description</label>
            <textarea name="description" id="description" class="form-control" required></textarea>
        </div>
        <div class="form-group">
            <label for="service_date">Maintenance Date</label>
            <input type="date" name="service_date" id="service_date" class="form-control" required>
        </div>
        <div class="form-group">
            <label for="amount">Price</label>
            <input type="number" name="amount" id="amount" class="form-control" step="0.01" required>
        </div>
        <button type="submit" class="btn btn-primary">Add</button>
    </form>
</div>
@endsection
