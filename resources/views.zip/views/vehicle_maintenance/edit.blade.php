@extends('layouts.app')

@section('content')
<div class="container">
    <h1>Edit Vehicle Maintenance Record</h1>
    <form action="{{ route('vehicle_maintenance.update', $maintenance->id) }}" method="POST">
        @csrf
        @method('PUT')
        <div class="form-group">
            <label for="vehicule_id">Vehicule</label>
            <select name="vehicule_id" id="vehicule_id" class="form-control">
                @foreach($vehicules as $vehicule)
                    <option value="{{ $vehicule->id }}" {{ $maintenance->vehicule_id == $vehicule->id ? 'selected' : '' }}>{{ $vehicule->name }}</option>
                @endforeach
            </select>
        </div>
        <div class="form-group">
            <label for="description">Description</label>
            <textarea name="description" id="description" class="form-control" required>{{ $maintenance->description }}</textarea>
        </div>
        <div class="form-group">
            <label for="service_date">Maintenance Date</label>
            <input type="date" name="service_date" id="service_date" class="form-control" required value="{{ $maintenance->service_date }}">
        </div>
        <div class="form-group">
            <label for="amount">Price</label>
            <input type="number" name="amount" id="amount" class="form-control" step="0.01" required value="{{$maintenance->amount}}">
        </div>
        <button type="submit" class="btn btn-primary">Update</button>
    </form>
</div>
@endsection
