@extends('layouts.kaptan')
@section('style')
  <link href="{{ asset('css/daterangepicker.css') }}" rel="stylesheet">

@endsection
@section('title', '| View Post')

@section('content')

   
             <div class="card">
                <div class="card-body">
  
  

              

                   <h5 class="card-title">Transfer</h5>
                    @if (session('status'))
                        <div class="alert alert-success">
                            {{ session('status') }}
                        </div>
                    
                    @endif
                  <form method="get" name='tarih' class="form-inline">
                    <label >@lang('app.start_date'): </label>
                    <input type="text" name="daterange" class="form-control" value="{{ app('request')->input('daterange') }}"/> 
                    <input type="hidden" name="start_date" id="hiddenStartDate"/>
                    <input type="hidden" name="end_date" id="hiddenEndDate"/>
                  
                  </form>
 
                
                </div>
 </div>
<table class="table table-bordered">
        <tr>
            <th width="80px">@sortablelink('post_id',__('app.file'))</th>
            <th>@sortablelink('start_date',__('app.start_date'))</th>
            <th>@sortablelink('servicetype_id',__('app.service'))</th>
            <th>@lang('app.from')</th>
            <th>@lang('app.to')</th>
          <th>Statues</th>
           <th>Payment:</th>
           <th>Detail</th>
         
            
        </tr> 
     
            @foreach($transfers as $key => $transfer)
                <tr class="table-{{$transfer->status->color->name}}">
                  <td>
                    <a href="{{ route('showdriver', $transfer->id ) }}" class='btn btn-primary'><i class="fa fa-eye" aria-hidden="true"></i>Transfer <Detail></Detail></a>
                

                  @if ($transfer->mission==true)
                 

                 
                  <a href='{{route('mission',$transfer->id )}}' class='btn btn-danger'><i class="fa fa-binoculars" aria-hidden="true"></i>Suivi de Mission</a>
                  @endif
                  
                  </td>
                    <td>{{date('d-m-Y H:i', strtotime($transfer->start_date)) }}</td>
                    <td>{{ $transfer->servicetype->name}}</td>
                
                    <td>{{ $transfer->from }}</td>
                    <td>{{ $transfer->target }}</td>
                    <td>{{isset($transfer->status->name)?$transfer->status->name:"" }}</td>
                  
                  <td>  {{(isset($transfer->harekets[0]->payment->name)?$transfer->harekets[0]->payment->name:"")}}
                              {{$transfer->harekets[0]->aciklama}}
        </td>
           
           <td>
           @foreach($transfer->post->client as $clients) 
           {{$clients->name." ".$clients->surname." ".$clients->tel}}<br/>
          @endforeach 
           {{$transfer->comments}}</td> 
                      <td>{{$transfer->dcomments}}</td>   
                </tr>
            @endforeach
    
    </table>
               
    {{ $transfers->appends(\Request::except('page'))->links('vendor/pagination/bootstrap-4') }}
</div>
</div></div>
@endsection
@section('footer')
<script src="{{ asset('/js/moment.min.js') }}"></script>
  <script src="{{ asset('/js/daterangepicker.js') }}"></script>
<script>

  $('input[name="daterange"]').daterangepicker({
 
    locale: {
      format: 'DD/MM/YYYY'
    }
  });

  $('input[name="daterange"]').on('apply.daterangepicker', function(ev, picker) {
 
    $('#hiddenStartDate').val(picker.startDate.format('YYYY-MM-DD'));
  $('#hiddenEndDate').val(picker.endDate.format('YYYY-MM-DD'));
    var x = document.getElementsByName('tarih');
    x[0].submit(); // Form submission
});
</script>
@endsection