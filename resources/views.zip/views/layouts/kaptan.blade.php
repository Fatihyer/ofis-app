<!DOCTYPE html>
<html lang="{{ app()->getLocale() }}">
<head>
  @include('layouts.partials.head')
   @yield('style')
</head>
<body>
 <div id="app">
   @if (Auth::guest())
   Please login 
   @else
  
  <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
  <!-- Navbar content -->

  <a class="navbar-brand" href="{{ url('/ev') }}">{{env('APP_NAME')}}</a>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>

 <div class="collapse navbar-collapse" id="navbarNavDropdown">
    <ul class="navbar-nav">
        <li class="nav-item">
            <a href="{{ route('kaptanshow') }}" class="nav-link">List</a>
        </li>
        <li class="nav-item">
            <a href="/" class="nav-link">Transfer List</a>
        </li>
    </ul> 

    <ul class="navbar-nav ml-auto">
        <li class="nav-item dropdown">
           
                <a href="{{ route('logout') }}" class="dropdown-item text-danger"
                   onclick="event.preventDefault();document.getElementById('logout-form').submit();">
                   Sign Out
                </a>
                <form id="logout-form" action="{{ route('logout') }}" method="POST" style="display: none;">
                    {{ csrf_field() }}
                </form>
           
        </li>
       
    </ul>
</div>
</nav>

@endif 

@if(Session::has('flash_message'))
<div class="container">      
    <div class="alert alert-success"><em> {!! session('flash_message') !!}</em></div>
</div>
@endif 

@include ('errors.list') {{-- Including error file --}}

@yield('content')

<!-- content-wrapper ends -->
<!-- partial:../../partials/_footer.html -->
@include('layouts.partials.footer')
<!-- partial -->

<!-- Scripts -->
<script src="{{mix('js/app.js') }}"></script>

<script>
$(document).ready(function(){
 
 $.ajax({
               url: '/last-attendance',
               type: 'GET',
               headers: {
                  
               },
               success: function(response) {
                   if (response.data) {
                       $('#attendance-name').text( response.data.permanence_name);
                       $('#attendance-names').text( response.data.permanence_name);
                   }
               },
               error: function(error) {
                   console.log('Son yoklama alınırken hata oluştu');
               }
           });
          });  
                    
</script>           

</div>
<script src="{{mix('js/app.js') }}"></script>
<script src="{{asset('js/main.js') }}"></script>
@yield('footer')
@yield('scripts')
</body>
</html>
