
<a href="{{ url('/ev') }}/?daterange={{ urlencode(session('daterange')) }}&start_date={{ urlencode(session('start_date')) }}&end_date={{ urlencode(session('end_date')) }}&driver={{ urlencode(session('driver')) }}&vehicule={{ urlencode(session('vehicule')) }}" class="list-group-item list-group-item-action" data-toggle="tooltip"> <i class="fas fa-home"></i></a>
  
    <a href="{{ route('table-driverUsage.index') }}" class="list-group-item list-group-item-action" data-toggle="tooltip"> <i class="fas fa-user-tie"></i></a>
    <a href="{{ route('vehiculescontrol') }}" class="list-group-item list-group-item-action" data-toggle="tooltip"><i class="fas fa-bus"></i></a>
    <a href="{{route('heuredetravail') }}" class="list-group-item list-group-item-action" data-toggle="tooltip"><i class="fas fa-chart-line"></i></a>
    <a href="{{route('transferstable.index') }}" class="list-group-item list-group-item-action" data-toggle="tooltip"><i class="fas fa-route"></i></a>
 

