<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
  <a class="navbar-brand" href="{{ url('/') }} ">
    Via
  </a>

  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>

  <div class="collapse navbar-collapse" id="navbarNavDropdown">
    <ul class="navbar-nav mr-auto">

      <li class="nav-item">
        <button class="btn btn-sm">
          {{ Form::number('git', "", ['onchange' => "location='/posts/' + this.value;"]) }}
        </button>
      </li>
      <li class="nav-item">   <a href="{{ url('/ev') }}/?daterange={{ urlencode(session('daterange')) }}&start_date={{ urlencode(session('start_date')) }}&end_date={{ urlencode(session('end_date')) }}&driver={{ urlencode(session('driver')) }}&vehicule={{ urlencode(session('vehicule')) }}" class="list-group-item list-group-item-action"> <i class="fas fa-home"></i></a></li>

      <li class="nav-item"><a class="nav-link" href="{{ route('charts') }}">@lang('app.chart')</a></li>
      <li class="nav-item"><a class="nav-link" href="{{ route('transfersday') }}">@lang('app.transfers')</a></li>
      <li class="nav-item"><a class="nav-link" href="{{ route('day') }}?start_date={{ urlencode(session('start_date')) }}">Shuttle</a></li>
      <li class="nav-item"><a class="nav-link" href="{{ route('missionlist') }}">Mission</a></li>

      <!-- Vehicule Dropdown -->
      <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="#" id="vehiculeDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Vehicule</a>
        <div class="dropdown-menu" aria-labelledby="vehiculeDropdown">
          <a class="dropdown-item" href="{{ route('vehicules.index') }}">Vehicules</a>
          <a class="dropdown-item" href="{{ route('vehicle_maintenance.index') }}">Vehicule Maintenance</a>
          <a class="dropdown-item" href="{{ route('vehiculescontrol') }}">Vehicule Usage</a>
          <a class="dropdown-item" href="{{ route('vehiculesusage') }}">Vehicule Chart</a>
        </div>
      </li>

      <!-- Provider Dropdown -->
      <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="#" id="providerDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Provider</a>
        <div class="dropdown-menu" aria-labelledby="providerDropdown">
          <a class="dropdown-item" href="{{ route('acentes.index') }}">Provider</a>
          <a class="dropdown-item" href="{{ route('acentes.create') }}">Provider Add</a>
        </div>
      </li>

      <!-- Data Dropdown -->
      <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="#" id="dataDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">@lang('app.data')</a>
        <div class="dropdown-menu" aria-labelledby="dataDropdown">
          <a class="dropdown-item" href="{{ route('acentes.index') }}">Provider @lang('app.list')</a>
          <a class="dropdown-item" href="{{ url('/manuale') }}">@lang('app.manual')</a>
          <a class="dropdown-item" href="{{ route('statuss.index') }}">@lang('app.status')</a>
          <a class="dropdown-item" href="{{ route('firmas.index') }}">@lang('app.providers_type')</a>
          <a class="dropdown-item" href="{{ route('servicetype.index') }}">@lang('app.services_type')</a>
          <a class="dropdown-item" href="{{ route('kurs.index') }}">@lang('app.exchange_name')</a>
          <a class="dropdown-item" href="{{ route('dovizs.index') }}">Döviz Kurları</a>
          <a class="dropdown-item" href="{{ route('kdvs.index') }}">@lang('app.tva')</a>
          <a class="dropdown-item" href="{{ route('accounts.index') }}">@lang('app.bankaccount')</a>
          <a class="dropdown-item" href="{{ route('payments.index') }}">@lang('app.payment_type')</a>
          <a class="dropdown-item" href="{{ route('options.index') }}">@lang('app.options')</a>
          <a class="dropdown-item" href="{{ route('sirkets.index') }}">Company</a>
          <a class="dropdown-item" href="{{ route('listexcel') }}">GarantiBankası döküm al</a>
          <a class="dropdown-item" href="{{ route('fuel.bank.import.form') }}">Société Générale excel get</a>
          <a class="dropdown-item" href="{{ route('efatura') }}">E-Fatura Giriş</a>
        </div>
      </li>

      <!-- List Dropdown -->
      <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="#" id="listDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">@lang('app.list')</a>
        <div class="dropdown-menu" aria-labelledby="listDropdown">
          <a class="dropdown-item" href="{{ route('invoices.index') }}">@lang('app.invoice')</a>
          <a class="dropdown-item" href="{{ route('groupinvoices.index') }}">Group Invoice</a>
          <a class="dropdown-item" href="{{ route('posts.index') }}">@lang('app.filelist')</a>
          <a class="dropdown-item" href="{{ route('balancefile') }}">Balance File</a>
          <a class="dropdown-item" href="{{ route('balanceprovider') }}">Balance Provider</a>
          <a class="dropdown-item" href="{{ route('acentes.index') }}">@lang('app.providers') List</a>
          <a class="dropdown-item" href="{{ route('transfers.index') }}">Transfer List</a>
          <a class="dropdown-item" href="{{ route('offsets.index') }}">@lang('app.offsets')</a>
          <a class="dropdown-item" href="{{ route('stocks.index') }}">@lang('app.stocks')</a>
          <a class="dropdown-item" href="{{ route('userattendances') }}">Permanence Saat</a>
          <a class="dropdown-item" href="{{ route('fichier.index') }}"><i class="fa fa-file"></i> Documents</a>
        </div>
      </li>

      <!-- Fuel Dropdown -->
      <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="#" id="fuelDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Fuel</a>
        <div class="dropdown-menu" aria-labelledby="fuelDropdown">
          <a class="dropdown-item" href="{{ route('fuel.list') }}">Fuel List</a>
          <a class="dropdown-item" href="{{ route('fuel.index') }}">Fuel</a>
          <a class="dropdown-item" href="{{ route('fuel.chart') }}">Fuel Chart</a>
          <a class="dropdown-item" href="{{ route('fuel.import.form') }}">Fuel from Excel</a>
        </div>
      </li>

     
      <li class="nav-item"><a class="nav-link btn btn-success" href="{{ route('talepler.index') }}">Talepler</a></li>
        <li class="nav-item"><a class="nav-link" href="{{ route('hermes.index') }}">Hermes</a></li>
    </ul>

    <!-- Sağdaki özel alanlar (Paris Gezgini, Operation, Attendance) -->
    <ul class="navbar-nav">

      <!-- Notifications -->
      <li class="nav-item dropdown" onclick="markNotificationAsRead()">
        <a class="nav-link dropdown-toggle" href="#" id="notificationDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
          <i class="fas fa-exclamation-triangle"></i>
          <span class="badge badge-danger">{{ count(auth()->user()->unreadNotifications) }}</span>
        </a>
        <div class="dropdown-menu dropdown-menu-right" aria-labelledby="notificationDropdown">
          @foreach (auth()->user()->unreadNotifications as $notification)
            <a class="dropdown-item" href="{{ route('transfers.show', $notification->data['transfer']['id']) }}">
              {{ $notification->data['user'] }} confirmed transfer on {{ $notification->data['transfer']['start_date'] }} (ID: {{ $notification->data['transfer']['id'] }})
            </a>
          @endforeach
          <div class="dropdown-divider"></div>
          <a class="dropdown-item text-center" href="#" onclick="deleteNotification()">Delete all</a>
        </div>
      </li>

      <!-- Paris Gezgini -->
      <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="#" id="parisgezginiDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
          <span class="text-danger">Paris Gezgini:</span> <span class="profile-text" id="parisgezgini-name"></span>
        </a>
        <div class="dropdown-menu dropdown-menu-right" aria-labelledby="parisgezginiDropdown">
          <form action="{{ route('parisgezgini') }}" method="POST">@csrf
            <button class="dropdown-item btn btn-secondary">Bende!</button>
          </form>
        </div>
      </li>

      <!-- Operation -->
      <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="#" id="operationDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
          <span class="text-danger">Operation:</span> <span class="profile-text" id="operation-name"></span>
        </a>
        <div class="dropdown-menu dropdown-menu-right" aria-labelledby="operationDropdown">
          <form action="{{ route('operation') }}" method="POST">@csrf
            <button class="dropdown-item btn btn-secondary">Operation Bende!</button>
          </form>
        </div>
      </li>

      <!-- Attendance -->
      <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="#" id="attendanceDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
          <span class="text-danger">Demande:</span> <span class="profile-text" id="attendance-name"></span>
        </a>
        <div class="dropdown-menu dropdown-menu-right" aria-labelledby="attendanceDropdown">
          <form action="{{ route('permanence') }}" method="POST">@csrf
            <button class="dropdown-item btn btn-danger">Demande Bende!</button>
          </form>
          <a class="dropdown-item" href="https://chat.whatsapp.com/IycDQzbJIK0BkdN5eSqIGt" target="_blank">
            <i class="fab fa-whatsapp"></i> Permanence Grup
          </a>
          <a class="dropdown-item" href="{{ route('permissions.index') }}">Manage Accounts</a>
          <a class="dropdown-item" href="#">Change Password</a>
          <a class="dropdown-item" href="#">Check Inbox</a>
          <a class="dropdown-item" href="{{ route('logout') }}" onclick="event.preventDefault();document.getElementById('logout-form').submit();">Sign Out</a>
          <form id="logout-form" action="{{ route('logout') }}" method="POST" style="display: none;">@csrf</form>
        </div>
      </li>

    </ul>
  </div>
</nav>
