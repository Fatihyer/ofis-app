<!DOCTYPE html>
<html lang="{{ app()->getLocale() }}">
<head>
  @include('layouts.partials.head')
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
  @yield('style')
</head>
<body>

@if (!Auth::guest())
  @include('layouts.partials.nav')
@endif

@if (session('success'))
  <div class="alert alert-success">{{ session('success') }}</div>
@endif
@if (session('error'))
  <div class="alert alert-danger">{{ session('error') }}</div>
@endif

<!-- SAYFA GENELİ FLEX -->
<div class="d-flex" style="min-height: 100vh;">

  <!-- Sidebar (sadece ikonlar) -->
  <div class="d-none d-md-flex flex-column align-items-center bg-light border-end" style="width: 50px;">
      @include('layouts.partials.sidebar')
  </div>

  <!-- İçerik alanı -->
  <div class="flex-grow-1 p-3">
      @if(Session::has('flash_message'))
          <div class="alert alert-success"><em> {!! session('flash_message') !!}</em></div>
      @endif

      @include('errors.list')
      @yield('content')
  </div>
</div>

<!-- Footer -->
@include('layouts.partials.footer')

<!-- JS -->
<script src="{{ mix('js/app.js') }}"></script>
<script src="{{ asset('js/main.js') }}"></script>

<script>
  function yazdir() {
      window.print();
  }

  $(document).ready(function () {
      $.get('/last-attendance', function (response) {
          if (response.data) {
              $('#attendance-name, #attendance-names').text(response.data.permanence_name);
          }
      });

      $.get('/last-operation', function (response) {
          if (response.data) {
              $('#operation-name, #operation-names').text(response.data.permanence_name);
          }
      });

      $.get('/last-parisgezgini', function (response) {
          if (response.data) {
              $('#parisgezgini-name, #parisgezgini-names').text(response.data.permanence_name);
          }
      });

      $("#languageswicher").change(function () {
          var locale = $(this).val();
          var _token = $("input[name=_token]").val();
          $.post("/language", { locale: locale, _token: _token }, function () {
              window.location.reload(true);
          });
      });

      $('[data-toggle="tooltip"]').tooltip();
  });
</script>

@yield('footer')
@yield('scripts')
</body>
</html>
