@extends('layouts.app')


@section('style')
<link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" />
@endsection

@section('content')
<form action="{{ route('fuel.bank.import') }}" method="POST" enctype="multipart/form-data" class="mb-4">
    @csrf
    <div class="form-group">
        <label for="acente_id">Choisir La compte Bancaire</label>
        <select name="acente_id" class="form-control" required>
            <option value="">Choisir</option>
            @foreach($acenteler as $id => $name)
                <option value="{{ $id }}">{{ $name }}</option>
            @endforeach
        </select>
    </div>

    <div class="form-group">
        <label for="file">Importer le dossier</label>
        <input type="file" class="form-control" name="file" required>
    </div>

    <button type="submit" class="btn btn-primary">Importer</button>
</form>
@if(session('success'))
    <div class="alert alert-success mt-3">
        {{ session('success') }}
    </div>
@endif
@if(session('error'))
    <div class="alert alert-danger mt-3">
        {{ session('error') }}
    </div>
@endif

<div class="container">
    <h3 class="mb-4">Banka Hareket Listesi</h3>

    <table class="table table-bordered table-striped table-sm">
        <thead class="thead-dark">
            <tr>
                <th>Tarih</th>
                <th>Açıklama</th>
                <th>Borç (€)</th>
                <th>Alacak (€)</th>
                <th>Debit</th>
                <th>Kur</th>
                <th>Bankalar Arası</th>
                <th>Acente</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
            @if($veriler->isEmpty())
                <tr>
                    <td colspan="8" class="text-center">Aucune donnée disponible</td>
                </tr>
            @endif
            @foreach($veriler as $row)
            <form method="POST" action="{{ route('fuel.bank.addoffset', $row->id) }}">
                @csrf
            
                
            @php
                    // Operation içinden eşleşen acente bul
                    $found = null;
                    foreach($acentes as $acente) {
                        if (stripos($row->operation, $acente->name) !== false) {
                            $found = $acente->id;
                            break;
                        }
                    }
                @endphp

                <tr>
                    <td>{{ \Carbon\Carbon::parse($row->date)->format('d.m.Y') }}</td>
                    <td><textarea name="aciklama" class="form-control" rows="5" required>{{ $row->operation }}</textarea>
                    </td>
                 
                    <td class="text-danger">{{ $row->debit }}</td>
                    <td class="text-success">{{ $row->credit }}</td>
                    <td>
    <div class="d-flex align-items-center">
        <input type="text" name="amount" class="form-control" 
               value="{{ $row->debit ?? $row->credit ?? 0 }}" required>

        @php
            $amountValue = $row->debit ?? $row->credit ?? 0;
        @endphp

        @if($amountValue != 0)
            <span class="ml-2 {{ $amountValue < 0 ? 'text-danger' : 'text-success' }}">
                {{ $amountValue < 0 ? '-' : '+' }}
            </span>
        @endif
    </div>
</td>
                    <td>{{ $row->currency }}</td>
                    <td>{{ $row->interbank_label }}</td>
                    <td>
                    <select name="b_acente_id" class="form-control form-control-sm select-acente" required>
    @foreach($acentes as $acente)
        <option value="{{ $acente->id }}" @if($found == $acente->id) selected @endif>
            {{ $acente->name }}
        </option>
    @endforeach
</select>


                    </td>
                    <td>
             <input type="hidden" name="a_acente_id" value="{{ $row->acente_id }}" hidden>   
             <input type="hidden" name="tarih" value="{{ $row->date }}">
             <input type="hidden" name="kur_id" value="1"> {{-- varsayılan kur --}}

            <button type="submit" class="btn btn-sm btn-success">Add Offset</button>
        </form>
        <form action="{{ route('fuel.bank.delete', $row->id) }}" method="POST" onsubmit="return confirm('Are you sure to delete?');" style="display:inline;">
            @csrf
            @method('DELETE')
            <button class="btn btn-sm btn-danger">✘</button>
        </form>
        </td>


                </tr>
            @endforeach
        </tbody>
    </table>

    {{ $veriler->links() }}
</div>
@endsection


@section('scripts')
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>
<script>
    $(document).ready(function() {
        $('.select-acente').select2({
            placeholder: "Choisir l'acente",
            allowClear: true,
            width: '100%'
        });
    });
</script>
@endsection