@hasanyrole('Admin|ofis')
<div class="row">
    <div>
        <a href="{{ route('acente.excellist', $acente->id) }}?daterange={{ request('daterange') }}">Excel <i class="fa fa-file-excel-o"></i></a>
    </div>
    <div class="table-responsive">
        <table class="table table-bordered" id="AcentesTable">
            <thead>
                <tr>
                    <th scope="col">@lang('app.date')</th>
                    <th>@lang('app.file')</th>
                    <th scope="col">@lang('app.service')</th>
                    <th scope="col">@lang('app.payment')</th>
                    <th scope="col">Borç</th>
                    <th scope="col">Alacak</th>
                    <th scope="col">@lang('app.amount')</th>
                    <th scope="col">Toplam Borç</th>
                    <th scope="col">Toplam Alacak</th>
                    <th scope="col">@lang('app.title')</th>
                    <th scope="col">@lang('app.detail')</th>
                </tr>
            </thead>
            <tbody>
                <?php $tborc = 0; $talacak = 0; $bakiye = 0; ?>
                @foreach ($harekets as $hareket)
                    <tr>
                        <td>{{ date('d-m-Y H:i', strtotime($hareket->tarih)) }}</td>
                        <td>
                            @if ($hareket->post)
                                <a href="{{ route('posts.show', $hareket->post->id) }}">{{ $hareket->post->id }}</a>
                            @else
                                N/A
                            @endif
                        </td>
                        <td>
                            @switch(substr($hareket->hareketable_type, 4))
                                @case('Offset')
                                    <a href="{{ route('offsets.edit', $hareket->hareketable->id) }}">{{ substr($hareket->hareketable_type, 4) }}</a>
                                    @if (isset($hareket->hareketable->alacakli->id))
                                        <a href="{{ route('acentes.show', $hareket->hareketable->alacakli->id) }}?src=balance">{{ $hareket->hareketable->alacakli->name }}</a>
                                    @endif
                                    -> 
                                    @if (isset($hareket->hareketable->borclu->id))
                                        <a href="{{ route('acentes.show', $hareket->hareketable->borclu->id) }}?src=balance">{{ $hareket->hareketable->borclu->name }}</a>
                                    @endif
                                    @break
                                @case('Stock')
                                    <a href="{{ route('stocks.edit', $hareket->hareketable->id) }}">{{ substr($hareket->hareketable_type, 4) }}</a>
                                    @if (isset($hareket->hareketable->alacakli->id))
                                        <a href="{{ route('acentes.show', $hareket->hareketable->alacakli->id) }}?src=balance">{{ $hareket->hareketable->alacakli->name }}</a>
                                    @endif
                                    -> 
                                    @if (isset($hareket->hareketable->borclu->id))
                                        <a href="{{ route('acentes.show', $hareket->hareketable->borclu->id) }}?src=balance">{{ $hareket->hareketable->borclu->name }}</a>
                                    @endif
                                    @break
                                @case('Invoice')
                                    @if ($hareket->post)
                                        <a href="{{ route('posts.show', $hareket->post->id) }}">{{ $hareket->post->id }}</a>
                                    @endif
                                    {{ substr($hareket->hareketable_type, 4) }} 
                                    @if (optional($hareket->hareketable->id))
                                        <a href="{{ route('invoices.edit', $hareket->hareketable->id) }}">{{ $hareket->hareketable->id }}</a>
                                            {{ $hareket->hareketable->resmi }}
                                    @endif
                                    @break
                                @default
                                    @if ($hareket->post)
                                        <a href="{{ route('posts.show', $hareket->post->id) }}">{{ $hareket->post->id }}</a>
                                    @else
                                        N/A
                                    @endif
                            @endswitch
                        </td>
                        <td>{{ $hareket->payment->name ?? '' }}</td>
                        <td>{{ $hareket->ab == 1 ? $hareket->amount : '00' }} <i class="fas fa-{{ $hareket->kur->icon }}-sign" aria-hidden="true"></i></td>
                        <td>{{ $hareket->ab == 2 ? $hareket->amount : '00' }} <i class="fas fa-{{ $hareket->kur->icon }}-sign" aria-hidden="true"></i></td>
                        <td>{{ number_format($bakiye += $hareket->amount, 2) }}</td>
                        <?php 
                            if ($hareket->ab == 2) $talacak += $hareket->amount;
                            if ($hareket->ab == 1) $tborc += $hareket->amount;
                        ?>
                        <td>{{ number_format($tborc, 2) }}</td>
                        <td>{{ number_format($talacak, 2) }}</td>
                        <td>
                            @if ($hareket->post_id > 0 && $hareket->post)
                                <a tabindex="0" class="btn" role="button" data-toggle="popover" data-trigger="focus" title="{{ $hareket->post->title }}" data-content="{{ $hareket->post->body }}">
                                    {{ \Illuminate\Support\Str::limit($hareket->post->title, 15) }}
                                </a>
                            @endif
                            {{ $hareket->aciklama }}
                        </td>
                        <td></td>
                    </tr>
                @endforeach
            </tbody>
            <tfoot>
                @foreach ($sum as $topla)
                    <tr class="table-success">
                        <td colspan="4">TOTAL <strong>BORC/ALACAK {{ abs($bakiye) }} @if ($bakiye >= 0) BORCLU @else ALACAKLI @endif</strong></td>
                        <td><strong>{{ $tborc }}</strong></td>
                        <td><strong>{{ $talacak }}</strong></td>
                        <td>{{ $bakiye }}</td>
                        <td></td>
                        <td></td>
                        <td colspan="2">TUM ZAMANLAR BORC/ALACAK {{ abs($topla->tpl) }} {{ $topla->kur->name }} @if ($topla->tpl >= 0) BORCLU @else ALACAKLI @endif
                            <a href="{{ route('offsets.create') }}?rakam={{ abs($topla->tpl) }}&acente={{ $acente->id }}"><i class="fas fa-arrows-alt-h"></i></a>
                        </td>
                    </tr>
                @endforeach
            </tfoot>
        </table>
    </div>
    <div class="row"> 
        <div class="col-sm">   
        <button id="exportButton" class="btn btn-primary">
        <i class="fas fa-file-excel"></i> Export to Excel
    </button>
  </div>
    </div>
    {!! $harekets->appends(request()->except('page'))->links('vendor/pagination/bootstrap-4') !!}
</div>
@endhasrole