<div class="row">
    <div class="table-responsive">
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th scope="col">Id</th>
                    <th scope="col">Date</th>
                    <th>Urun</th>
                    <th scope="col">From->To</th>
                    <th scope="col">Qty</th>
                    <th scope="col">Cash /Credit<a href="#" data-toggle="tooltip" title="Cash ise Offset ile Girildi! Bir daha eklemeyin">****</a></th>
                    <th scope="col">Komisyon</th>
                    <th scope="col">Açıklama</th>
                </tr>
            </thead>
            <tbody>
                <?php $cashs = 0; $digers = 0; ?>
                @foreach ($stocks as $stock)
                    <tr>
                        <td><a href="{{ route('stocks.edit', $stock->id) }}">{{ $stock->id }}</a></td>
                        <td>{{ date('d/m/Y H:i', strtotime($stock->tarih)) }}</td>
                        <td><a href="{{ route('acentes.show', $stock->urun->id) }}?src=stock">{{ $stock->urun->name }}</a></td>
                        <td><a href="{{ route('acentes.show', $stock->alacakli->id) }}?src=stock">{{ $stock->alacakli->name }}</a>-><a href="{{ route('acentes.show', $stock->borclu->id) }}?src=stock">{{ $stock->borclu->name }}</a></td>
                        <td>{{ $stock->adet }}</td>
                        <td>{{ $stock->credit == 1 ? 'Cash' : 'Credit' }}</td>
                        <td>{{ $cash = $stock->harekets[1]->amount ?? 'NO COM.' }} {{ $stock->harekets[1]->kur->name ?? '' }}</td>
                        <td>{{ $stock->harekets[0]->amount }}{{ $stock->harekets[0]->kur->name }} {{ $stock->aciklama }}</td>
                    </tr>
                    <?php $cashs += $cash; ?>
                @endforeach
            </tbody>
            <tfoot>
                <tr>
                    <td colspan="3">TOPLAM</td>
                    <td></td>
                    <td></td>
                    <td>{{ $digers }}</td>
                    <td>{{ $cashs }}</td>
                    <td>TOPLAM: {{ $cashs + $digers }}</td>
                    <td></td>
                </tr>
            </tfoot>
        </table>
    </div>
</div>
