@hasanyrole('Admin|ofis')
<a href="{{ route('groupinvoices.create', 'acente=' . $acente->id) }}" class="btn btn-success">New Group Invoices</a>
<div class="row">
    <div class="table-responsive">
        <table class="table table-striped">
            <thead>
                <tr>
                    <th scope="col">@lang('app.file_no')</th>
                    <th scope="col">@lang('app.invoice')</th>
                    <th>Group Invoice</th>
                    <th scope="col">@lang('app.date')</th>
                    <th scope="col">@lang('app.exchange')</th>
                    <th scope="col">@lang('app.amount')</th>
                    <th scope="col">@lang('app.legal')</th>
                    <th>Amount</th>
                </tr>
            </thead>
            <tbody>
                <?php $itop = 0; ?>
                @foreach ($invoices as $invoice)
                    <tr>
                        <th scope="row"><a href="{{ route('posts.show', $invoice->post->id) }}"><b>FP{{ $invoice->post->id }} </b></a></th>
                        <?php $detail = unserialize($invoice->detail); ?>
                        <td>{{ $invoice->id }}</td>
                        <td><a href="{{ route('groupinvoices.edit', $invoice->groupinvoice[0]->id ?? '') }}">{{ $invoice->groupinvoice[0]->id ?? '' }}</a></td>
                        <td>{{ date('d-m-Y', strtotime($invoice->tarih)) }}</td>
                        <td>{{ $invoice->kur->name }}</td>
                        <td>{{ $invoice->amount }} {{ $invoice->kur->short_name }}</td>
                        <td>{{ $invoice->resmi }}</td>
                        <td>
                            <a href="{{ route('invoices.edit', $invoice->id) }}" class="btn btn-primary btn-block">Edit</a>
                            <a href="{{route('invoicetopdf',[$invoice->id,'pdf'] )}}" class="btn btn-danger btn-block">PDF</a>
                        </td>
                    </tr>
                    <?php $itop += $invoice->amount; ?>
                @endforeach
            </tbody>
            <tfoot>
                <tr>
                    <td colspan="5"></td>
                    <td>{{ $itop }}</td>
                </tr>
            </tfoot>
        </table>
    </div>
    <div class="panel-heading">Page {{ $invoices->currentPage() }} of {{ $invoices->lastPage() }}</div>
    <div class="text-center">
        {!! $invoices->links() !!}
    </div>
</div>
@endhasrole