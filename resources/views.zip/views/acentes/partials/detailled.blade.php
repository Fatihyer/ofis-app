<div class="container mt-4">
    @foreach ($posts as $post)
        <div class="card mb-4">
            <div class="card-header">
                <h3 class="card-title">
                    {{ $post->id }} - {{ $post->title }}
                    <small class="text-muted">{{ date('d-m-Y', strtotime($post->start_date)) }} - {{ date('d-m-Y', strtotime($post->end_date)) }}</small>
                </h3>
            </div>
            <div class="card-body">
                @foreach ($post->transfer as $transferts)
                    <div class="row mb-3">
                        <div class="col-md-2">
                            <strong>ID:</strong> {{ $transferts->id }}
                        </div>
                        <div class="col-md-3">
                            <strong>Start:</strong> {{ date('d-m-Y H:i', strtotime($transferts->start_date)) }}
                        </div>
                        <div class="col-md-3">
                            <strong>End:</strong> {{ date('d-m-Y H:i', strtotime($transferts->end_date)) }}
                        </div>
                        <div class="col-md-2">
                            <strong>From:</strong> {{ $transferts->from }}
                        </div>
                        <div class="col-md-2">
                            <strong>To:</strong> {{ $transferts->target }}
                        </div>
                        <div class="col-md-2">
                            <strong>Vehicle:</strong> {{ $transferts->vehicule->name }}
                        </div>
                        <div class="col-md-2">
                            <strong>Driver:</strong> {{ $transferts->driver->name }}
                        </div>
                        <div class="col-md-2">
                            <strong>Amount:</strong>
                            @foreach ($transferts->harekets as $hareket) 
                                {{ $hareket->amount }} euros
                            @endforeach
                        </div>
                    </div>
                @endforeach
            </div>
        </div>
    @endforeach
</div>
