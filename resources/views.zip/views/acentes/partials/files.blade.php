<div class="row">
    <div class="table-responsive">
        <table class="table table-striped">
            <thead>
                <tr>
                    <th scope="col">@sortablelink('id', __('app.file'))</th>
                    <th scope="col">Name</th>
                    <th scope="col">@sortablelink('start_date', __('app.from'))</th>
                    <th scope="col">To</th>
                    <th scope="col">Comment</th>
                    <th scope="col">Status</th>
                    <th scope="col">Resmi</th>
                    <th scope="col">Pax</th>
                    <th scope="col">Child</th>
                    <th scope="col">#</th>
                </tr>
            </thead>
            <tbody>
                @foreach ($posts as $post)
                    <tr>
                        <th scope="row"><a href="{{ route('posts.show', $post->id) }}"><b>FP{{ $post->id }} </b></a></th>
                        <td>{{ $post->title }}</td>
                        <td>{{ date('d/m/Y', strtotime($post->start_date)) }}</td>
                        <td>{{ date('d/m/Y', strtotime($post->end_date)) }}</td>
                        <td><p class="teaser">{{  \Illuminate\Support\Str::limit($post->body, 100) }}</p></td>
                        <td><p class="text-{{ $post->status->color->name }}">{{ $post->status->name }}</p></td>
                        <td>{{ $post->resmi }}</td>
                        <td>{{ $post->pax }}</td>
                        <td>{{ $post->child }}</td>
                        <td>
                            <a href="{{ route('posts.edit', $post->id) }}" class="btn btn-primary btn-block">Edit</a>
                        </td>
                    </tr>
                @endforeach
            </tbody>
        </table>
    </div>
    <div class="panel-heading">Page {{ $posts->currentPage() }} of {{ $posts->lastPage() }}</div>
    <div class="text-center">
        {!! $posts->links() !!}
    </div>
</div>
