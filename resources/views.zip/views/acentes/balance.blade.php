@extends('layouts.app')
@section('style')
 

@endsection
@section('content')
 
        <div class="container">
             <div class="card">
                <div class="card-body">
                   <h4 class="card-title">Providers Balance </h4>
                 
                     <div>
              
               </div>
                    
                 
                </div>
               <form method="get" name='tarih'>
                 <label>@lang('app.providers_type'):  </label>
                       {{Form::select('firma',['0'=>'sec']+$firma,'',['class'=>'form-control','onchange'=>'this.form.submit()'])}}
               </form>
                     <div class="table-responsive">
                       <table class="table table-bordered">
                              <thead>
                                <tr>
                                  <th scope="col">{{__('app.agency')}}</th>
                                
                                 
                                  <th scope="col">#</th>
                                    <th scope="col">Balance</th>
                                    <th scope="col">İnfo</th>
                                </tr>
                              </thead>
                              <tbody>
                          <?php $total=0;?>      
                    @foreach ($sums as $sum=>$al)
                                @if (($al['sum']>1) || ($al['sum']<-1))
                                  <tr>
                                     <td><a href="{{ route('acentes.show', $al['acente_id']) }}?src=balance"><b>{{$acente[$al['acente_id']]}}</b></a></td>
                                     
                                     <td bgcolor="@if ($al['sum']>0)red @else green @endif">@if ($al['sum']>0)Borclu @else Alacaklı @endif </td>
                        <td>{{$al['sum']}}</td>
                        <td>{{isset($msg[$al['acente_id']])?$msg[$al['acente_id']]:''}}</td>
                                  </tr>
                                @endif
                       <?php $total+=$sum?>
                    @endforeach
                            
                           </tbody>
                  </table>
                    </div>
                    <div class="text-center">
                      {{$total}}€
                      
                    </div>
                </div>
            </div>
          
@endsection
@section('footer')

@endsection