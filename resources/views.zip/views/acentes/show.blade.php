@extends('layouts.app')

@section('style')
<link href="{{ asset('css/daterangepicker.css') }}" rel="stylesheet">
<style>
    table.auto {
        table-layout: auto;
    }
    .table th, .table td { 
        padding: 2px 5px; 
    }
</style>
@endsection

@section('title', '| View Post')

@section('content')
<div class="alert alert-dark" role="alert">
    {{ $acente->name }} <a href="{{ route('acentes.index') }}">Provider List</a>
</div>

<div class="col-12 grid-margin">
    <div class="card">
        <form method="get" name="tarih">
            <label>@lang('app.start_date'):</label>
            <input type="text" name="daterange" class="form-control" value="{{ request('daterange') }}" /> 
            <input type="hidden" name="start_date" id="hiddenStartDate" />
            <input type="hidden" name="end_date" id="hiddenEndDate" />
            <input type="hidden" name="src" value="{{ request('src') }}" />
        </form>

        <div class="card-header">
            <ul class="nav nav-tabs card-header-tabs">
                <li class="nav-item">
                    <a class="nav-link {{ request('src') == false ? 'active' : '' }}" href="?">@lang('app.info')</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link {{ request('src') == 'file' ? 'active' : '' }}" href="?src=file&daterange={{ request('daterange') }}">@lang('app.file')</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link {{ request('src') == 'invoice' ? 'active' : '' }}" href="?src=invoice&daterange={{ request('daterange') }}">@lang('app.invoice')</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link {{ request('src') == 'service' ? 'active' : '' }}" href="?src=service&daterange={{ request('daterange') }}">@lang('app.service')</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link {{ request('src') == 'offset' ? 'active' : '' }}" href="?src=offset&daterange={{ request('daterange') }}">Offset</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link {{ request('src') == 'stock' ? 'active' : '' }}" href="?src=stock&daterange={{ request('daterange') }}">Stock</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link {{ request('src') == 'balance' ? 'active' : '' }}" href="?src=balance&daterange={{ request('daterange') }}">@lang('app.balance')</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link {{ request('src') == 'message' ? 'active' : '' }}" href="?src=message&daterange={{ request('daterange') }}">@lang('app.message')</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link {{ request('src') == 'detailled' ? 'active' : '' }}" href="?src=detailled&daterange={{ request('daterange') }}">File Detailed</a>
                </li>
            </ul>
        </div>

        <div class="card-body">
            @if (request('src') == 'file')
                @include('acentes.partials.files', ['posts' => $posts])
            @elseif (request('src') == 'invoice')
                @include('acentes.partials.invoices', ['invoices' => $invoices, 'acente' => $acente])
            @elseif (request('src') == 'service')
                @include('acentes.partials.services', ['transfers' => $transfers])
            @elseif (request('src') == 'balance')
                @include('acentes.partials.balance', ['harekets' => $harekets, 'sum' => $sum, 'acente' => $acente])
            @elseif (request('src') == 'message')
                @include('acentes.partials.messages', ['acente' => $acente])
            @elseif (request('src') == 'offset')
                @include('acentes.partials.offsets', ['offsets' => $offsets])
            @elseif (request('src') == 'stock')
                @include('acentes.partials.stocks', ['stocks' => $stocks])
            @elseif (request('src') == 'detailled')
                @include('acentes.partials.detailled', ['posts' => $posts])
            @else
                @include('acentes.partials.info', ['acente' => $acente, 'files' => $files, 'storeFile' => $storeFile])
            @endif
        </div>
    </div>
</div>
@endsection

@section('footer')
<script src="{{ asset('/js/moment.min.js') }}"></script>
<script src="{{ asset('/js/daterangepicker.js') }}"></script>
<script>
    $('input[name="daterange"]').daterangepicker({
        locale: {
            format: 'DD/MM/YYYY'
        }
    }).on('apply.daterangepicker', function(ev, picker) {
        $('#hiddenStartDate').val(picker.startDate.format('YYYY-MM-DD'));
        $('#hiddenEndDate').val(picker.endDate.format('YYYY-MM-DD'));
        document.forms['tarih'].submit();
    });

    $(function () {
        $('[data-toggle="popover"]').popover();
        $('[data-toggle="tooltip"]').tooltip();
    });
</script>
<script>
    document.getElementById('exportButton').addEventListener('click', function() {
        var table = document.getElementById('AcentesTable');
        var html = table.outerHTML;
        var url = 'data:application/vnd.ms-excel,' + encodeURIComponent(html);
        var downloadLink = document.createElement("a");
        downloadLink.href = url;
        downloadLink.download = 'acentes.xls';
        document.body.appendChild(downloadLink);
        downloadLink.click();
        document.body.removeChild(downloadLink);
    });
  </script>
  
@endsection
