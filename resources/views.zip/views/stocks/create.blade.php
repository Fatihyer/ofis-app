@extends('layouts.app')


@section('content')

<div class="container">
    <div class="row justify-content-md-center mt-5">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">@lang('app.products')</div>
                <div class="card-body">
     {{ Form::open(array('route' => 'stocks.store')) }}
       <div  class="form-row">
          
       {{ Form::label('tarih',__('app.date') , array('for' => 'validationDefault01')) }}
        {{ Form::date('tarih',date('Y-m-d'), array('class' => 'form-control')) }}
     </div>   
                  
       <div  class="form-row">
          
       {{ Form::label('post_id',__('app.file') , array('for' => 'validationDefault01')) }}
        {{ Form::text('post_id',$file, array('class' => 'form-control','readonly'=>'readonly')) }}
     </div>            
        <!--  <div  class="form-row">
          
       {{ Form::label('acentes',__('app.buy')." /".__('app.sale') , array('for' => 'validationDefault01')) }}
       {{ Form::select('ab',[__('app.sale'),__('app.buy')],"", array('class' => 'form-control')) }}
     </div> -->
        <div  class="form-row">
          
       {{ Form::label('acentes',__('app.kimden') , array('for' => 'validationDefault01')) }}
       {{ Form::select('a_acente_id',$acentes,"", array('class' => 'form-control')) }}
     </div> 
       <div  class="form-row">
          
       {{ Form::label('acentes',__('app.kime') , array('for' => 'validationDefault01')) }}
        @if ($acente) 
       {{ Form::select('b_acente_id',$acentes,$acente, array('class' => 'form-control', 'disabled'=>true)) }}
           {{ Form::hidden('b_acente_id',$acente) }}
     
        @else
         {{ Form::select('b_acente_id',$acentes,"", array('class' => 'form-control')) }}
       @endif
       </div>             
            <div  class="form-row">
       {{ Form::label('uruns',__('app.products') , array('for' => 'validationDefault01')) }}
       {{ Form::select('urun_id',$uruns,"", array('class' => 'form-control')) }}
     </div>   
            <div  class="form-row">
       {{ Form::label('number',__('app.pieces') , array('for' => 'validationDefault01')) }}
       {{ Form::number('adet',"", array('class' => 'form-control')) }}
     </div>   
          <div  class="form-row">
       {{ Form::label('aciklama',__('app.detail') , array('for' => 'validationDefault01')) }}
       {{ Form::text('aciklama',"", array('class' => 'form-control')) }}
     </div>  
         <div  class="form-row">
       {{ Form::label('price',__('app.price') , array('for' => 'validationDefault01')) }}
       {{ Form::text('price',0, array('class' => 'form-control')) }}
     </div> 
       <div  class="form-row">
       {{ Form::label('exchange',__('app.exchange') , array('for' => 'validationDefault01')) }}
       {{ Form::select('kur_id',$kurs,1, array('class' => 'form-control')) }}
     </div>               
               
    <a class="btn btn-secondary" data-toggle="collapse" href="#collapsekomisyon" role="button" aria-expanded="false" aria-controls="collapsekomisyon">
    Add komisyon
  </a>  <br/> 
                  
      <div class="collapse" id="collapsekomisyon">
       <div  class="form-row">
          
       {{ Form::label('acentes',__('app.kime') , array('for' => 'validationDefault01')) }}
       {{ Form::select('kom_acente_id',$acentes,"", array('class' => 'form-control')) }}
     </div>    
         <div  class="form-row">
       {{ Form::label('price',__('app.price') , array('for' => 'validationDefault01')) }}
       {{ Form::number('komprice',"", array('class' => 'form-control')) }}
     </div> 
       <div  class="form-row">
       {{ Form::label('exchange',__('app.exchange') , array('for' => 'validationDefault01')) }}
       {{ Form::select('komkur_id',$kurs,1, array('class' => 'form-control')) }}
     </div>       
        
        
        
      </div> 
      
        <div class="radio"><label> {{ Form::radio('credit', 1 , true) }} Paid on cach to Broker (komisyon alana veya teslim edene) )</label></div>
        <div class="radio"><label>{{ Form::radio('credit', 0 , false) }} Credit </label></div> 
                 
        <br/>           
   
  <button class="btn btn-primary" type="submit">@lang('app.save')</button>
{{form::close()}}

   </div>
            </div>
        </div>
    </div>
</div>

@endsection
