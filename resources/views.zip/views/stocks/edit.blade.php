@extends('layouts.app')


@section('content')

<div class="container">
    <div class="row justify-content-md-center mt-5">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">@lang('app.products')</div>
                <div class="card-body">
  
      {{ Form::model($stocks, array('route' => array('stocks.update', $stocks->id), 'method' => 'PUT')) }}
             
     <div  class="form-row">
          
       {{ Form::label('tarih',__('app.date') , array('for' => 'validationDefault01')) }}
        {{ Form::date('tarih',date('Y-m-d',strtotime($stocks->tarih)), array('class' => 'form-control')) }}
     </div>   
                  
       <div  class="form-row">
          
       {{ Form::label('post_id',__('app.file') , array('for' => 'validationDefault01')) }}
        {{ Form::text('post_id',$file, array('class' => 'form-control','readonly'=>'readonly')) }}
     </div>            
        <!-- <div  class="form-row">
          
       {{ Form::label('acentes',__('app.buy')." /".__('app.sale') , array('for' => 'validationDefault01')) }}
       {{ Form::select('ab',[__('app.sale'),__('app.buy')],$stocks->ab, array('class' => 'form-control')) }}
     </div> -->
        <div  class="form-row">
          
            {{ Form::label('acentes',__('app.kimden') , array('for' => 'validationDefault01')) }}
       {{ Form::select('a_acente_id',$acentes,$stocks->a_acente_id, array('class' => 'form-control')) }}
     </div> 
       <div  class="form-row">
          
       {{ Form::label('acentes',__('app.kime') , array('for' => 'validationDefault01')) }}
      
       {{ Form::select('b_acente_id',$acentes,$acente, array('class' => 'form-control', 'disabled'=>true)) }}
           {{ Form::hidden('b_acente_id',$acente) }}
     
     
       </div>             
            <div  class="form-row">
       {{ Form::label('uruns',__('app.products') , array('for' => 'validationDefault01')) }}
       {{ Form::select('urun_id',$uruns,$stocks->urun_id, array('class' => 'form-control')) }}
     </div>   
            <div  class="form-row">
       {{ Form::label('number',__('app.pieces') , array('for' => 'validationDefault01')) }}
       {{ Form::number('adet',$stocks->adet, array('class' => 'form-control')) }}
     </div>   
                  
        <div  class="form-row">
       {{ Form::label('aciklama',__('app.detail') , array('for' => 'validationDefault01')) }}
       {{ Form::text('aciklama',$stocks->aciklama, array('class' => 'form-control')) }}
     </div>
                  <div  class="form-row">
       {{ Form::label('price',__('app.price') , array('for' => 'validationDefault01')) }}
       {{ Form::text('price',abs($stocks->harekets[0]->amount), array('class' => 'form-control')) }}
     </div> 
                   <div  class="form-row">
       {{ Form::label('exchange',__('app.exchange') , array('for' => 'validationDefault01')) }}
       {{ Form::select('kur_id',$kurs,$stocks->harekets[0]->kur_id, array('class' => 'form-control')) }}
     </div>  
     
                 
                  
                  
                  
                     <a class="btn btn-secondary" data-toggle="collapse" href="#collapsekomisyon" role="button"
      aria-controls="collapsekomisyon">
    Add komisyon
  </a>  <br/> 
                  
      <div class="collapse  {{isset($stocks->harekets[1])?"show":""}}"  id="collapsekomisyon" >
       <div  class="form-row">
          
       {{ Form::label('acentes',__('app.kime') , array('for' => 'validationDefault01')) }}
       {{ Form::select('kom_acente_id',$acentes,isset($stocks->harekets[1]->acente_id)?$stocks->harekets[1]->acente_id:"", array('class' => 'form-control')) }}
     </div>    
         <div  class="form-row">
       {{ Form::label('price',__('app.price') , array('for' => 'validationDefault01')) }}
       {{ Form::text('komprice',isset($stocks->harekets[1]->amount)?abs($stocks->harekets[1]->amount):"", array('class' => 'form-control')) }}
     </div> 
       <div  class="form-row">
       {{ Form::label('exchange',__('app.exchange') , array('for' => 'validationDefault01')) }}
       {{ Form::select('komkur_id',$kurs,isset($stocks->harekets[1]->kur_id)?$stocks->harekets[1]->kur_id:"", array('class' => 'form-control')) }}
     </div>       
        
        
        
      </div> 
      
        <div class="radio"><label> {{ Form::radio('credit', 1 ,($stocks->credit==true)?true:false ) }} Paid on cach to Broker (komisyon alana veya teslim edene) )</label></div>
        <div class="radio"><label>{{ Form::radio('credit', 0 , ($stocks->credit==false)?true:false) }} Credit </label></div> 
                 
        <br/>           
   
  <button class="btn btn-primary" type="submit">@lang('app.save')</button>
             @if ($stocks->post_id)     <a href="{{route('posts.show',$stocks->post_id)}}" class="btn btn-warning ">To File</a>    @endif 
                  <a href="{{route('stocks.index')}}" class="btn btn-secondary ">Stocks</a>
{{form::close()}}

   </div>
            </div>
        </div>
    </div>
</div>

@endsection
