@extends('layouts.app')
@section('content')

 <div class="row">
             <div class="card">
                <div class="card-body">
                   <h4 class="card-title">Stoks  <a class="btn btn-success" href="{{ route('stocks.create') }}">New Stocks</a> </h4>
                 
                     <div>
                    <form method="get" name='tarih' class="form-inline">
                    <label >@lang('app.start_date'): </label>
                    <input type="text" name="daterange" class="form-control" value="{{ app('request')->input('daterange') }}"/> 
                    <input type="hidden" name="start_date" id="hiddenStartDate"/>
                    <input type="hidden" name="end_date" id="hiddenEndDate"/>
                  </form>  
               </div>
                    
                 
                     {!! $stocks->appends(\Request::except('page'))->links('vendor/pagination/bootstrap-4') !!} </div>
             
                     <div class="table-responsive">
                       <table class="table table-bordered">
                              <thead>
                                <tr>
                                  <th scope="col">@sortablelink('id',__('app.file'))</th>
                                    <th scope="col">@sortablelink('tarih',__('app.date'))</th>
                                  <th scope="col">@sortablelink('a_acente_id','From')</th>
                                  <th scope="col">@sortablelink('b_acente_id','To')</th>
                                
                                   <th scope="col">Product</th>
                                   <th scope="col">Qty</th>
                          
                                  <th scope="col">Cash/Credit</th>
                                      <th scope="col">Sale Price</th>
                                  <th scope="col">Komisyon</th>
                                            <th scope="col">Comment</th>
                               
                                    <th scope="col">#</th>
                                </tr>
                              </thead>
                              <tbody>
                    @foreach ($stocks as $stock)
                     <tr>
                                    <th scope="row">@if (isset($stock->post_id))<a href="{{ route('posts.show', $stock->post_id ) }}"><b>{{ $stock->post_id}} </b></a></th>
                                     @endif <td>{{ date("d/m/Y", strtotime($stock->tarih))}}</td>
                                    <td>
                                       <a href="{{ route('acentes.show', $stock->a_acente_id ) }}"><b>{{ $stock->alacakli->name}}</b></a>
                                    </td>
                                    <td>
                                   <a href="{{ route('acentes.show', $stock->b_acente_id ) }}"><b>{{ $stock->borclu->name}}</b></a>
                                    </td>
                         <td>{{ $stock->urun->name}}</td>
                       <td>{{ $stock->adet}}</td>
                         <td>{{($stock->credit)?"cash":"credit"}}</td>
                        <td> {{isset($stock->harekets[0])?$stock->harekets[0]->amount:"No"}}</td>
                         <td> {{isset($stock->harekets[1])?$stock->harekets[1]->amount:"No"}}</td>
                                     <td>{{$stock->aciklama}}</td>  
                                   
                                   
                                   
                                    <td scope="col">
                                      
                                      <form  class="deleteinvoice" action="{{ route('stocks.destroy', $stock->id) }}" method="POST">
                                          {{ method_field('DELETE') }}
                                          {{ csrf_field() }}
                                          <a href="{{ route('stocks.edit', $stock->id) }}" class="btn btn-primary btn-block">Edit</a>
   
                                          <button class="btn btn-danger" ><i class="fas fa-trash-alt"></i></button>
                                          
                                        </form>
                                    </td>
                                   
                                  </tr>
                       
                       
                    @endforeach
                           </tbody>
                  </table>
                    </div>
                    <div class="text-center">
                     {!! $stocks->appends(\Request::except('page'))->links('vendor/pagination/bootstrap-4') !!}
                    </div>
                </div>
            </div>
      
  
       
@endsection
