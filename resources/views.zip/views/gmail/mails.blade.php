@extends('layouts.app')
@php
use Illuminate\Support\Str;
@endphp
@section('content')
<div class="container">
<form method="GET" action="{{ route('gmail.mails') }}" class="form-inline mb-3">
    <label class="mr-2">Mail Kutusu Seç:</label>
    <select name="account" class="form-control mr-2">
    <option value="resparis" {{ request('account') == 'resparis' ? 'selected' : '' }}>Reservation Paris Via</option>
        <option value="contact" {{ request('account') == 'contact' ? 'selected' : '' }}>Contact Paris Via</option>
       
        <option value="contactfrance" {{ request('account') == 'contactfrance' ? 'selected' : '' }}>Contact France Via</option>
        <option value="resfrance" {{ request('account') == 'resfrance' ? 'selected' : '' }}>Reservation France Via</option>
    </select>
    <button type="submit" class="btn btn-primary">Göster</button>
</form>
    <!-- Gelen Mailler Tablosu -->
   
    <!-- Mailler Tablosu -->
    <table class="table table-striped table-bordered" id="gmailMailsTable">
        <thead>
            <tr>
                <th>Gönderen</th>
                <th>Konu</th>
                <th>İçerik (Özet)</th>
                <th>Ekler</th>
               
                <th>Geliş Tarihi</th>
                <th>İşlem</th>
            </tr>
        </thead>
        <tbody>
            @foreach($mails as $mail)
            <tr>
                <td>{{ $mail['from'] }}
                @if(!empty($mail['acente']) && $mail['acente'] !== 'Yok')
                        <span class="badge badge-success">{{ $mail['acente'] }}</span>
                    @else
                        <span class="badge badge-danger">Yok</span>
                    @endif


                </td>
                <td>{{ Str::limit($mail['subject'], 80) }}</td>
                <td>{{ Str::limit(strip_tags($mail['body']), 100) }}</td>
                <td>
                    @if(!empty($mail['attachments']))
                        @foreach($mail['attachments'] as $attachment)
                            <a href="data:application/octet-stream;base64,{{ $attachment['content'] }}" 
                               download="{{ $attachment['name'] }}" 
                               class="btn btn-sm btn-outline-primary mb-1">
                               {{ $attachment['name'] }}
                            </a><br>
                        @endforeach
                    @else
                        Yok
                    @endif
                </td>
             
                <td>{{ $mail['date'] }}</td>
                <td>
                    <button class="btn btn-info btn-sm viewMailButton mb-1"
                        data-subject="{{ $mail['subject'] }}"
                        data-body="{{ strip_tags($mail['body']) }}"
                        data-attachments='@json($mail['attachments'])'>
                        Görüntüle
                    </button>
                    <button class="btn btn-primary btn-sm createTalepButton"
                        data-subject="{{ $mail['subject'] }}"
                        data-body="{{ strip_tags($mail['body']) }}"
                        data-from="{{ $mail['from'] }}"
                        data-acente-id="{{ $mail['acente_id'] }}"
                        data-message-id="{{ $mail['message_id'] }}"
                        data-date="{{ $mail['date'] }}" 
                        data-attachments='@json($mail['attachments'])'> <!-- ⭐ Bunu ekle -->
                        Talep Yarat
                    </button>
                </td>
            </tr>
            @endforeach
        </tbody>
    </table>

    <!-- Mail Detay Modal -->
    <div class="modal fade" id="mailDetailModal" tabindex="-1" role="dialog" aria-labelledby="mailDetailModalLabel">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title" id="mailDetailModalLabel">Mail Detayı</h5>
            <button type="button" class="close" data-dismiss="modal" aria-label="Kapat">
              <span aria-hidden="true">&times;</span>
            </button>
          </div>
          <div class="modal-body">
            <h5 id="mailSubject"></h5>
            <p id="mailBody"></p>
            <div id="mailAttachments" class="mt-3"></div>
          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-dismiss="modal">Kapat</button>
          </div>
        </div>
      </div>
    </div>

</div>
@endsection

@section('scripts')
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
<script src="https://cdn.datatables.net/1.10.21/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/1.10.21/js/dataTables.bootstrap4.min.js"></script>

<script>
$(function () {
    $('#gmailMailsTable').DataTable({
        pageLength: 10,
        order: [[5, 'desc']]
    });

    // Talep Yarat
    $(document).on('click', '.createTalepButton', function () {
    let subject = $(this).data('subject');
    let body = $(this).data('body');
    let from = $(this).data('from');
    let acenteId = $(this).data('acente-id');
    let messageId = $(this).data('message-id');
    let attachments = $(this).data('attachments'); 
    let date = $(this).data('date'); // ⭐ Burada alıyoruz

    if (confirm("Bu mailden talep oluşturmak istiyor musun?\n\nKonu: " + subject)) {
        $.ajax({
            url: '{{ route("gmail.create.talep") }}',
            method: 'POST',
            data: {
                _token: '{{ csrf_token() }}',
                subject: subject,
                body: body,
                from: from,
                acente_id: acenteId,
                message_id: messageId,
                date: date,
                attachments: attachments // ⭐
            },
            success: function (response) {
                alert(response.success);
            },
            error: function (xhr) {
                if (xhr.status === 409) {
                    // Laravel'in döndürdüğü hata mesajını al
                    let errorMessage = xhr.responseJSON?.error || 'Bu mailden zaten talep oluşturulmuş.';
                    alert(errorMessage);
                } else {
                    alert('Bilinmeyen bir hata oluştu.');
                }
            }
        });
    }
});

    // Mail Detayı Göster
    $(document).on('click', '.viewMailButton', function () {
        let subject = $(this).data('subject');
        let body = $(this).data('body');
        let attachments = $(this).data('attachments');

        $('#mailSubject').text(subject);
        $('#mailBody').html(body.replace(/\n/g, '<br>'));


        let attachmentHtml = '';
        if (attachments.length > 0) {
            attachmentHtml = '<h6>Ekler:</h6>';
            attachments.forEach(function (attachment) {
                attachmentHtml += `
                    <a href="data:application/octet-stream;base64,${attachment.content}" 
                       download="${attachment.name}" 
                       class="btn btn-sm btn-outline-primary mb-1">
                       ${attachment.name}
                    </a><br>`;
            });
        } else {
            attachmentHtml = '<p>Ek bulunamadı.</p>';
        }
        $('#mailAttachments').html(attachmentHtml);

        $('#mailDetailModal').modal('show');
    });
});
</script>


@endsection