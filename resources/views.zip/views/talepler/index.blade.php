@extends('layouts.app')
@section('style')
<link rel="stylesheet" href="https://cdn.datatables.net/1.13.5/css/jquery.dataTables.min.css">
@endsection

@section('content')
<div class="container">
    <div class="d-flex justify-content-between mb-3">
        <h2>Talep Listesi</h2>
      
        <button class="btn btn-success" data-toggle="modal" data-target="#talepEkleModal">+ Yeni Talep Ekle</button>
        <a href="{{ route('gmail.mails') }}" class="btn btn-primary">Mail den Talep Ekle</a>
    </div>

    <table class="table table-bordered" id="taleplerTable">
        <thead>
            <tr>
                <th>ID</th>
                <th>Tarih</th>
                <th>Kanal</th>
                <th>Acente</th>
                <th>Talep Sorumlusu</th>
                <th>Fiyat</th>
                <th>Relance</th>
                <th>Konfirme</th>
                <th>Talep Mesajı Mesaj</th>
                <th>Ekler</th>  
                <th>İşlemler</th>
            </tr>
        </thead>
    </table>
</div>
<!-- Talep Görüntüle Modal -->
<div class="modal fade" id="talepGoruntuleModal" tabindex="-1" role="dialog" aria-labelledby="talepGoruntuleModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-lg" role="document"> <!-- modal-lg burada -->
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="talepGoruntuleModalLabel">Talep Detayları</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Kapat">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body" id="talepGoruntuleIcerik">
        <!-- Ajax ile buraya içerik doldurulacak -->
      </div>
    </div>
  </div>
</div>
<!-- Uzun Mesaj Modal -->
<div class="modal fade" id="uzunMesajModal" tabindex="-1" role="dialog" aria-labelledby="uzunMesajModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-lg" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title">Mesaj</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Kapat">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <textarea id="uzunMesajTextarea" class="form-control" rows="22"></textarea>
        <input type="hidden" id="uzunMesajTalepId">
      </div>
      <div class="modal-footer">
    
        <button type="button" id="uzunMesajKaydet" class="btn btn-danger">Save</button>
        <button type="button" class="btn btn-primary" data-dismiss="modal">Exit</button>
      </div>
    </div>
  </div>
</div>

<!-- Talep Ekle Modal -->
<div class="modal fade" id="talepEkleModal" tabindex="-1" role="dialog" aria-labelledby="talepEkleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
      <h5 class="modal-title" id="talepEkleModalLabel">Yeni Talep Ekle</h5>

        <button type="button" class="close" data-dismiss="modal" aria-label="Kapat">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <form id="talepForm">
            @csrf

            <div class="form-group">
                <label>Talep Tarihi</label>
                <input type="datetime-local" name="talep_tarihi" class="form-control" required>
                <input type="hidden" name="id" id="talep_id">

            </div>

            <div class="form-group">
                <label>Talep Kanalı</label>
                <select name="talep_kanali" class="form-control" required>
                    <option value="WhatsApp">WhatsApp</option>
                    <option value="Mail">Mail</option>
                    <option value="Telefon">Telefon</option>
                </select>
            </div>

            <div class="form-group">
                <label>Acente</label>
                <select name="acente_id" class="form-control">
                    <option value="">Seçiniz</option>
                    @foreach($acenteler as $acente)
                        <option value="{{ $acente->id }}">{{ $acente->name }}</option>
                    @endforeach
                </select>
            </div>

            <div class="form-group">
                <label>Talep Sorumlusu</label>
                <select name="user_id" class="form-control" required>
                    <option value="">Seçiniz</option>
                    @foreach($kullanicilar as $kullanici)
                        <option value="{{ $kullanici->id }}" {{ auth()->id() == $kullanici->id ? 'selected' : '' }}>
                            {{ $kullanici->name }}
                        </option>
                    @endforeach
                </select>
            </div>

            <div class="form-group">
                <label>Verilen Fiyat (€)</label>
                <input type="number" name="verilen_fiyat" class="form-control">
            </div>

            <div class="form-group">
                <label>Relance Yapıldı mı?</label>
                <select name="relance_yapildi" class="form-control">
                    <option value="0">Hayır</option>
                    <option value="1">Evet</option>
                </select>
            </div>

            <div class="form-group">
                <label>Konfirme Durumu</label>
                <select name="konfirme_durumu" class="form-control">
                    <option value="Waiting Price">Waiting Price</option>
                    <option value="Quoted">Quoted</option>
                    <option value="Waiting">Waiting</option>
                    <option value="Relanced">Relanced</option>
                    <option value="Confirmed">Confirmed</option>
                    <option value="Canceled">Canceled</option>
                </select>
            </div>

            <div class="form-group">
                <label>Uzun Mesaj</label>
                <textarea name="uzun_mesaj" class="form-control" rows="4"></textarea>
            </div>

            <button type="submit" class="btn btn-primary">Kaydet</button>
        </form>
      </div>
    </div>
  </div>
</div>
@endsection

@section('scripts')
<script src="https://cdn.datatables.net/1.13.5/js/jquery.dataTables.min.js"></script>

<script src="/js/tinymce/tinymce.min.js"></script>


<!-- Place the following <script> and <textarea> tags your HTML's <body> -->
<script>$(function () {
    let table = $('#taleplerTable').DataTable({
        processing: true,
        serverSide: true,
        ajax: '{{ route("talepler.index") }}',
        columns: [
            {data: 'id'},
            {data: 'talep_tarihi'},
            {data: 'talep_kanali'},
            {
                data: 'name',
                render: function(data, type, row) {
                    return `<span class="editable-acente" data-id="${row.id}" data-current="${row.acente_id}">${data ?? '-'}</span>`;
                }
            },

            {
                data: 'user_adi',
                render: function(data, type, row) {
                    return `<span class="editable-user" data-id="${row.id}" data-current="${row.user_id}">${data}</span>`;
                }
            },

            {
                data: 'verilen_fiyat',
                render: function(data, type, row) {
                    return `<span class="editable-fiyat" data-id="${row.id}" data-current="${data ?? ''}">${data ?? '-'}</span>`;
                }
            },

            {
                    data: 'relance_yapildi',
                    render: function(data, type, row) {
                        const label = data ? 'Evet' : 'Hayır';
                        return `<span class="editable-relance" data-id="${row.id}" data-current="${data}">${label}</span>`;
                    }
                },

            {data: 'konfirme_durumu',
                render: function(data, type, row) {
                        let color = 'secondary';
                        switch (data) {
                            case 'Waiting Price': color = 'warning'; break;
                            case 'Quoted': color = 'secondary'; break;
                            case 'Waiting': color = 'dark'; break;
                            case 'Relanced': color = 'primary'; break;
                            case 'Confirmed': color = 'success'; break;
                            case 'Canceled': color = 'danger'; break;
                        }
                        return `<span class="editable-konfirme badge badge-${color}" data-id="${row.id}" data-current="${data}">${data}</span>`;
                    }
            },
            {
                    data: 'uzun_mesaj',
                    render: function(data, type, row) {
                        if (data) {
                            return `<button class="btn btn-sm btn-info view-uzun-mesaj" data-msg="${data.replace(/"/g, '&quot;')}" data-id="${row.id}">Göster</button>`;
                        }
                        return `<button class="btn btn-sm btn-info view-uzun-mesaj" data-msg="" data-id="${row.id}">Göster</button>`;
                    }
                },
            {data: 'attachments', orderable: false, searchable: false},

            {data: 'action', orderable: false, searchable: false},
        ]
    });

    // Talep formu gönderimi
    $('#talepForm').on('submit', function (e) {
        e.preventDefault();
        let formData = $(this).serialize();
        let talepId = $('#talep_id').val(); // id inputtan alıyoruz

        let url = '';
        let method = 'POST';

        if (talepId) {
            url = '/talepler/' + talepId;
            formData += '&_method=PUT'; // PUT override ediyoruz
        } else {
            url = '{{ route("talepler.store") }}';
        }

        $.ajax({
            url: url,
            method: 'POST', // her zaman POST gönderiyoruz (Laravel _method kontrol ediyor)
            data: formData,
            success: function (response) {
                $('#talepEkleModal').modal('hide');
                $('#talepForm')[0].reset();
                $('#talep_id').val(''); // id sıfırla
                table.ajax.reload();
                alert(response.success);
            },
            error: function (xhr) {
                alert('Hata oluştu. Lütfen alanları kontrol edin.');
            }
        });
    });

    // Talep Silme
    $(document).on('click', '.deleteTalep', function () {
        let id = $(this).data('id');

        if (confirm('Bu talebi silmek istediğinize emin misiniz?')) {
            $.ajax({
                url: '/talepler/' + id,
                method: 'DELETE',
                data: {_token: '{{ csrf_token() }}'},
                success: function (response) {
                    $('#taleplerTable').DataTable().ajax.reload();
                    alert(response.success);
                },
                error: function (xhr) {
                    alert('Silme sırasında hata oluştu.');
                }
            });
        }
    });

    // Talep Görüntüleme
    $(document).on('click', '.viewTalep', function () {
        let id = $(this).data('id');

        $.ajax({
            url: '/talepler/' + id,
            method: 'GET',
            success: function (response) {
    let detay = 
        "<p><strong>Acente:</strong> " + (response.acente ? response.acente.name : '-') + "</p>" +
        "<p><strong>Talep Kanalı:</strong> " + (response.talep_kanali ?? '-') + "</p>" +
        "<p><strong>Talep Sorumlusu:</strong> " + (response.user ? response.user.name : '-') + "</p>" +
        "<p><strong>Fiyat:</strong> " + (response.verilen_fiyat ? response.verilen_fiyat + " €" : '-') + "</p>" +
        "<p><strong>Relance:</strong> " + (response.relance_yapildi ? 'Evet' : 'Hayır') + "</p>" +
        "<p><strong>Konfirme:</strong> " + (response.konfirme_durumu ?? '-') + "</p>" +
        "<p><strong>Uzun Mesaj:</strong><br>" + (response.uzun_mesaj ?? '-') + "</p>";

    $('#talepGoruntuleIcerik').html(detay);
    $('#talepGoruntuleModal').modal('show');
            },
            error: function (xhr) {
                alert('Talep bilgisi alınamadı!');
            }
        });
    });

    // Talep Düzenleme
    $(document).on('click', '.editTalep', function () {
        let id = $(this).data('id');

        $.ajax({
            url: '/talepler/' + id,
            method: 'GET',
            success: function (response) {
                $('#talepEkleModal').modal('show');
                $('#talepEkleModalLabel').text('Talebi Düzenle');
                $('[name="talep_tarihi"]').val(response.talep_tarihi.slice(0, 16));

                $('[name="talep_kanali"]').val(response.talep_kanali);
                $('[name="acente_id"]').val(response.acente_id);
                $('[name="user_id"]').val(response.user_id);
                $('[name="verilen_fiyat"]').val(response.verilen_fiyat);
                $('[name="relance_yapildi"]').val(response.relance_yapildi);
                $('[name="konfirme_durumu"]').val(response.konfirme_durumu);
                $('[name="uzun_mesaj"]').val(response.uzun_mesaj);
                $('#talep_id').val(response.id); // gizli inputa id koy
            },
            error: function (xhr) {
                alert('Talep bilgisi alınamadı!');
            }
        });
    });
});
$('#talepEkleModal').on('hidden.bs.modal', function () {
    $(this).find('form')[0].reset();
    $('#talep_id').val('');
    $('#talepEkleModalLabel').text('Yeni Talep Ekle'); 
});

$(document).on('click', '.editable-konfirme', function () {
    const currentSpan = $(this);
    const id = currentSpan.data('id');
    const currentValue = currentSpan.data('current');
    const options = ['Waiting Price', 'Quoted', 'Waiting', 'Relanced', 'Confirmed', 'Canceled'];

    // Eğer zaten bir select açıksa işlem yapma
    if (currentSpan.find('select').length) return;

    const select = $('<select class="form-control form-control-sm"></select>');
    options.forEach(option => {
        select.append(`<option value="${option}" ${option === currentValue ? 'selected' : ''}>${option}</option>`);
    });

    currentSpan.html(select);

    // Otomatik odaklan
    select.focus();

    // Seçim değiştiğinde güncelle
    select.on('change blur', function () {
        const newValue = $(this).val();

        // Ajax ile güncelle
        $.ajax({
            url: `/talepler/${id}/konfirme-durumu`, // örnek route
            method: 'POST',
            data: {
                _token: '{{ csrf_token() }}',
                konfirme_durumu: newValue
            },
            success: function () {
                // Eski yazıya dön, renklendirerek
                let color = 'secondary';
                switch (newValue) {
                    case 'Waiting Price': color = 'warning'; break;
                    case 'Waiting': color = 'dark'; break;
                    case 'Relanced': color = 'primary'; break;
                    case 'Confirmed': color = 'success'; break;
                    case 'Canceled': color = 'danger'; break;
                }
                currentSpan
                    .removeClass()
                    .addClass(`editable-konfirme badge badge-${color}`)
                    .data('current', newValue)
                    .text(newValue);
            },
            error: function () {
                alert("Güncelleme başarısız!");
                currentSpan.text(currentValue);
            }
        });
    });
});
$(document).on('click', '.editable-user', function (e) {
    e.stopPropagation();
    const span = $(this);
    const id = span.data('id');
    const current = span.data('current');

    if (span.find('select').length > 0) return;

    const select = $('<select class="form-control form-control-sm"></select>');
    const kullanicilar = @json($kullanicilar);
    kullanicilar.forEach(kullanici => {
        const selected = kullanici.id == current ? 'selected' : '';
        select.append(`<option value="${kullanici.id}" ${selected}>${kullanici.name}</option>`);
    });

    span.text('');
    span.append(select);
    setTimeout(() => { select.focus(); }, 10);

    select.on('change', function () {
        const value = $(this).val();
        const selectedText = select.find("option:selected").text();

        $.post(`/talepler/${id}/update-user`, {
            _token: '{{ csrf_token() }}',
            user_id: value
        }, function () {
            span.text(selectedText).data('current', value);
        }).fail(function () {
            span.text('Hata');
        });
    });

    $(document).one('click', function () {
        if (!span.is(':hover')) {
            span.text(span.data('label'));
        }
    });
});

$(document).on('click', '.editable-acente', function (e) {
    e.stopPropagation();
    const span = $(this);
    const id = span.data('id');
    const current = span.data('current');

    if (span.find('select').length > 0) return;

    const select = $('<select class="form-control form-control-sm"></select>');
    const acenteler = @json($acenteler);
    acenteler.forEach(acente => {
        const selected = acente.id == current ? 'selected' : '';
        select.append(`<option value="${acente.id}" ${selected}>${acente.name}</option>`);
    });

    span.text('');
    span.append(select);
    setTimeout(() => { select.focus(); }, 10);

    select.on('change', function () {
        const value = $(this).val();
        const selectedText = select.find("option:selected").text();

        $.post(`/talepler/${id}/update-acente`, {
            _token: '{{ csrf_token() }}',
            acente_id: value
        }, function () {
            span.text(selectedText).data('current', value);
        }).fail(function () {
            span.text('Hata');
        });
    });

    $(document).one('click', function () {
        if (!span.is(':hover')) {
            span.text(span.data('label'));
        }
    });
});

$(document).on('click', '.editable-fiyat', function (e) {
    e.stopPropagation();
    const span = $(this);
    const id = span.data('id');
    const current = span.data('current');

    if (span.find('input').length > 0) return;

    const input = $('<input type="number" class="form-control form-control-sm" />').val(current);
    span.text('').append(input);
    setTimeout(() => { input.focus(); }, 10);

    input.on('blur', function () {
        const value = $(this).val();
        $.post(`/talepler/${id}/update-fiyat`, {
            _token: '{{ csrf_token() }}',
            verilen_fiyat: value
        }, function () {
            span.text(value).data('current', value);
        }).fail(function () {
            span.text('Hata');
        });
    });
});

$(document).on('click', '.editable-relance', function (e) {
    e.stopPropagation();
    const span = $(this);
    const id = span.data('id');
    const current = span.data('current');

    if (span.find('select').length > 0) return;

    const select = $('<select class="form-control form-control-sm"></select>');
    select.append('<option value="0">Hayır</option>');
    select.append('<option value="1">Evet</option>');

    select.val(current);
    span.text('').append(select);
    setTimeout(() => { select.focus(); }, 10);

    select.on('change', function () {
        const value = $(this).val();
        const label = value == '1' ? 'Evet' : 'Hayır';
        $.post(`/talepler/${id}/update-relance`, {
            _token: '{{ csrf_token() }}',
            relance_yapildi: value
        }, function () {
            span.text(label).data('current', value);
        }).fail(function () {
            span.text('Hata');
        });
    });

    $(document).one('click', function () {
        if (!span.is(':hover')) {
            span.text(span.data('label'));
        }
    });
});

// Uzun Mesaj Görüntüleme ve Modal Açma
$(document).on('click', '.view-uzun-mesaj', function () {
    const mesaj = $(this).data('msg') || '';
    const id = $(this).data('id');

    // TinyMCE içine mesajı doğru şekilde yerleştir
    if (tinymce.get('uzunMesajTextarea')) {
        tinymce.get('uzunMesajTextarea').setContent(mesaj);
    }

    $('#uzunMesajTalepId').val(id);
    $('#uzunMesajModal').modal('show');
});



  tinymce.init({
    selector: '#uzunMesajTextarea',
    plugins: 'lists link image code textcolor color',
    toolbar: 'undo redo | styleselect | bold italic | forecolor backcolor | alignleft aligncenter alignright alignjustify | bullist numlist outdent indent | code',
     menubar: false,
    height: 300,
    setup: function (editor) {
        editor.on('change', function () {
            editor.save();
        });
    }
  });

  $('#uzunMesajKaydet').on('click', function () {
    const id = $('#uzunMesajTalepId').val();
    const mesaj = tinymce.get('uzunMesajTextarea').getContent();

    $.post(`/talepler/${id}/update-uzun-mesaj`, {
        _token: '{{ csrf_token() }}',
        uzun_mesaj: mesaj
    }, function () {
        $('#uzunMesajModal').modal('hide');
        $('#taleplerTable').DataTable().ajax.reload(null, false);
    }).fail(function () {
        alert('Mesaj kaydedilirken hata oluştu.');
    });
});


</script>


@endsection
