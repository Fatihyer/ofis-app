@extends('layouts.app')
@section('content')
<div class="row">
    <div class="col-md-6 offset-md-3">
        <div class="row">
            <div class="col-md-4">
                <button class="btn btn-secondary" id="day-before">Hier</button>
                <button class="btn btn-primary" id="today">Aujourd'hui</button>
                <button class="btn btn-secondary" id="day-after">Demain</button>
            </div>
        </div>
        <form method="POST" action="{{ route('missions.byDate') }}">
            @csrf
            <div class="form-group">
                <label for="datepicker">Select Date:</label>
                <div class="input-group">
                    <input type="date" class="form-control" id="datepicker" name="selected_date" placeholder="Select Date" value="{{ isset($selectedDate) ? $selectedDate : now()->format('Y-m-d') }}">
                </div>
            </div>
            <button type="submit" class="btn btn-primary">Show Missions</button>
        </form>
    </div>
</div>
<div class="row">
    <div class="col-md-12">
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>Transfer/File</th>
                    <th>Chauffeur</th>
                    <th>Vehicule</th>
                    <th>En route</th>
                    <th>En route Reel</th>
                    <th>Surplace</th>
                    <th>PEC Prevu</th>
                    <th>PEC Reel</th>
                    <th>Finish Prevu</th>
                    <th>Finish Reel</th>
                    <th>Duree de Missions</th>
                    <th>Permanence</th>
                </tr>
            </thead>
            <tbody>
            @foreach ($missions as $mission)
                <tr>
                    <td>
                        <a href="{{ route('transfers.show', $mission->transfer_id) }}">{{ $mission->transfer_id }}</a>
                        <br>
                        <a href="{{ route('posts.show', $mission->transfer->post_id) }}">{{ $mission->transfer->post_id }}</a>
                        <br>
                        Mission id <a href="{{ route('mission', $mission->transfer_id) }}" >{{ $mission->id }} </a>
                    </td>
                    <td>{{ $mission->transfer->driver->name }}</td>
                    <td>{{ $mission->transfer->vehicule->plaka }}</td>
                    <td>{{ date('H:i', strtotime($mission->transfer->ofis_start)) }}</td>
                    <td>{{ $mission->hareket ? date('H:i', strtotime($mission->hareket)) : 'null' }}</td>
                    <td>{{ $mission->surplace ? date('H:i', strtotime($mission->surplace)) : 'null' }}</td>
                    <td style="color: red;">{{ date('H:i', strtotime($mission->transfer->start_date)) }}</td>
                    <td>{{ $mission->taked ? date('H:i', strtotime($mission->taked)) : 'null' }}</td>
                    <td style="color: red;">{{ date('H:i', strtotime($mission->transfer->end_date)) }}</td>
                    <td>{{ $mission->finish ? date('H:i', strtotime($mission->finish)) : 'null' }}</td>
                    <td style="color: green;">
                        @if($mission->finish)
                            <?php
                                $startTime = $mission->hareket ? strtotime($mission->hareket) : strtotime($mission->transfer->ofis_start);
                                $finishTime = strtotime($mission->finish);
                                $difference = $finishTime - $startTime;
                                $timeDifference = gmdate("H:i", $difference);
                            ?>
                            {{ $timeDifference }}
                        @else
                            null
                        @endif
                    </td>
                    <td>
                        @if ($mission->start_user_id)
                            Start: {{ $mission->startuser->name }}
                            @if (!$mission->confirmed_at)
                                En route: <button class="btn btn-primary confirmButton" data-mission-id="{{ $mission->id }}" data-button-type="start">Confirm</button>
                            @else
                                {{ date('H:i', strtotime($mission->confirmed_at)) }}
                            @endif
                        @endif
                        <br>
                        @if ($mission->user_id)
                            Finish: {{ $mission->user->name }}
                            @if (!$mission->finish_confirmed_at)
                                Finish: <button class="btn btn-danger confirmButton" data-mission-id="{{ $mission->id }}" data-button-type="end">Confirm</button>
                            @else
                                {{ date('H:i', strtotime($mission->finish_confirmed_at)) }}
                            @endif         
                        @endif
                        @if (($mission->start_user_id)&& (!$mission->user_id))
                       <span class="text-danger"> La Mission n'est as pas terminee</span>
                        @endif
                    </td>
                </tr>
            @endforeach
            </tbody>
        </table>
    </div>
</div>
<div class="row">
    <div class="col-md-4">
        <button class="btn btn-secondary" id="day-before">Hier</button>
        <button class="btn btn-primary" id="today">Aujourd'hui</button>
        <button class="btn btn-secondary" id="day-after">Demain</button>
    </div>
</div>
@endsection

@section('footer')
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
<script>
    document.getElementById('today').addEventListener('click', function() {
        window.location.href = "{{ route('missionlist') }}";
    });

    document.getElementById('day-before').addEventListener('click', function() {
        changeDate(-1);
    });

    document.getElementById('day-after').addEventListener('click', function() {
        changeDate(1);
    });

    function changeDate(dayDifference) {
        var dateInput = document.getElementById('datepicker');
        var selectedDate = new Date(dateInput.value);
        selectedDate.setDate(selectedDate.getDate() + dayDifference);
        var newDate = selectedDate.toISOString().split('T')[0];
        dateInput.value = newDate;
        dateInput.form.submit();
    }

    $(document).ready(function() {
        $('.confirmButton').click(function() {
            var button = $(this);
            var missionId = button.data('mission-id');
            var buttonType = button.data('button-type');
            var userId = '{{ auth()->id() }}';
            $.ajax({
                url: buttonType === 'start' ? '{{ route("registerTime") }}' : '{{ route("registerTimeend") }}',
                type: 'POST',
                data: {
                    mission_id: missionId,
                    user_id: userId,
                    _token: '{{ csrf_token() }}'
                },
                success: function(response) {
                    alert('Teşekkür ederiz, emeğe saygı.');
                    button.hide();
                },
                error: function(xhr) {
                    var errorMessage = xhr.responseJSON.error;
                    alert(errorMessage);
                }
            });
        });
    });
</script>
@endsection
