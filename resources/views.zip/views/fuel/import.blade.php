
@extends('layouts.app')

@section('style')
<!-- Select2 CSS -->
<link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" />

@endsection
@section('content')
<div class="container">

@if(session('success'))
        <div style="color: green;">{{ session('success') }}</div>
    @endif
    <h1>Fuel Import</h1>
    <form action="{{ route('fuel.import') }}" method="POST" enctype="multipart/form-data">
        @csrf
        <div class="mb-3">
            <label for="file" class="form-label">Upload Excel File</label>
            <input type="file" class="form-control" id="file" name="file"  required>
        </div>
        <button type="submit" class="btn btn-primary">Import</button>

    
    </form>
    <div class="table-responsive">
    <table class="table table-bordered table-striped">
    <thead class="thead-dark">
                <tr>
                <th>Date</th>
<th>Immatriculation</th>
<th>Numéro de carte</th>
<th>Litres</th>
<th>Montant (€)</th>
<th>Type de carburant</th>
<th>kilometer</th>
<th>Driver</th>
<th>Vehicule</th>
<th>Enregistrer</th>
<th>Effacer</th>

                </tr>
            </thead>
            <tbody>
    @php
        if (!function_exists('normalizeCard')) {
            function normalizeCard($num) {
                return preg_replace('/\D/', '', ltrim($num, '0'));
            }
        }
    @endphp

    @foreach($rows as $row)
        @php
            $selectedCard = normalizeCard($row->card_raw);
        @endphp

        <tr>
            <form action="{{ route('fuel.import.save', $row->id) }}" method="POST" class="form-inline">
                @csrf

                <td>{{ $row->authorized_at }}</td>
                <td>{{ $row->vehicule_raw }}</td>
                <td>
                    {{ $selectedCard }}
                    <select name="fuel_card_id" class="form-control form-control-sm select2">
                        @php
                            $matched = false;
                        @endphp
                        @foreach($fuelCards as $card)
                            @php
                                $normalizedCard = normalizeCard($card->card_number);
                                $isSelected = $selectedCard === $normalizedCard;
                                if ($isSelected) $matched = true;
                            @endphp
                            <option value="{{ $card->id }}" {{ $isSelected ? 'selected' : '' }}>
                                {{ $card->card_number }} - {{ $card->acente->name }}
                            </option>
                        @endforeach

                        @unless($matched)
                            <option disabled selected>La carte n'est pas Enregistrer</option>
                        @endunless
                    </select>
                </td>

                <td>{{ $row->volume }}</td>
                <td>{{ $row->amount }}</td>
                <td>{{ $row->fuel_type }}</td>
            
                <td> <input type='number' name='kilometrage' required value="{{ $row->kilometrage }}"></td>
                <td>
                    <select name="acente_id" class="form-control form-control-sm select2" required>
                        <option value="">Select</option>
                        @foreach($acenteler as $acente)
                            <option value="{{ $acente->id }}">{{ $acente->name }}</option>
                        @endforeach
                    </select>

                 
                </td>

                <td>
                    <select name="vehicule_id" class="form-control form-control-sm select2" required>
                        <option value="">Select</option>
                        @foreach($vehicules as $vehicule)
                            <option value="{{ $vehicule->id }}">{{ $vehicule->name }}</option>
                        @endforeach
                    </select>
                </td>

                <td><button type="submit" class="btn btn-success btn-sm">Save</button></td>
            </form>
            <td>
    <form action="{{ route('fuel.import.delete', $row->id) }}" method="POST" onsubmit="return confirm('Bu satırı silmek istediğinize emin misiniz?');">
        @csrf
        @method('DELETE')
        <button type="submit" class="btn btn-danger btn-sm">Delete</button>
    </form>
</td>
        </tr>
    @endforeach
</tbody>

        </table>
   
</div>
@endsection
@section('scripts')

<!-- jQuery -->
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

<!-- Select2 JS -->
<script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>

<script>
    $(document).ready(function() {
        $('.select2').select2({
            width: '100%',
            placeholder: 'Select an option',
            allowClear: true
        });
    });
</script>
@endsection