@extends('layouts.app')
@section('style')
  <link href="{{ asset('css/daterangepicker.css') }}" rel="stylesheet">

@endsection
@section('content')
 
        <div class="row">
             <div class="card">
                <div class="card-body">
                   <h4 class="card-title">Files  <a class="btn btn-success" href="{{ route('posts.create') }}">New File</a> </h4>
                 
                     <div>
                    <form method="get" name='tarih' class="form-inline">
                      <label for="per_page">Combien de ligne par page</label>
                <select name="per_page" id="per_page" class="form-control mx-2" onchange="this.form.submit()">
                  <option value="5" {{ $per_page == 5 ? 'selected' : '' }}>5</option>
                    <option value="50" {{ $per_page == 50 ? 'selected' : '' }}>50</option>
                    <option value="100" {{ $per_page == 100 ? 'selected' : '' }}>100</option>
                    <option value="200" {{ $per_page == 200 ? 'selected' : '' }}>200</option>
                </select>
                    <label >@lang('app.start_date'): </label>
                    <input type="text" name="daterange" class="form-control" value="{{ app('request')->input('daterange') }}"/> 
                    <input type="hidden" name="start_date" id="hiddenStartDate"/>
                    <input type="hidden" name="end_date" id="hiddenEndDate"/>
                  </form>  
               </div>
                   
                 
                     {!! $posts->appends(\Request::except('page'))->links('vendor/pagination/bootstrap-4') !!} </div>
             
                     <div class="table-responsive">
                       <table class="table table-bordered">
                              <thead>
                                <tr>
                                  <th width="80px">@sortablelink('post_id', __('app.file'))</th>
                                   <th scope="col">Provider Type</th>
                                  <th scope="col">@sortablelink('acente_id',__('app.acente'))</th>
                                  <th scope="col">Name</th>
                                  <th scope="col">@sortablelink('start_date',__('app.from'))</th>
                                    <th scope="col">To</th>
                                  <th scope="col">Comment</th>
                                  <th scope="col">Statue</th>
                                  <th scope="col">Resmi</th>
                                  <th scope="col">Pax</th>
                                  <th scope="col">Child</th>
                                  <th scope="col">#</th>
                                </tr>
                              </thead>
                              <tbody>
                    @foreach ($posts as $post)
                     <tr>
                                    <th scope="row"><a href="{{ route('posts.show', $post->id ) }}"><b>FP{{ $post->id}} </b></a></th>
                                    <td>@foreach ($post->acente->firmas as $name){{ $name->name}}@endforeach</td>
                                     <td><a href="{{ route('acentes.show', $post->acente_id ) }}"><b>{{ $post->acente->name}}</b></a></td>
                                    <td>{{ $post->title}}</td>
                                     <td>{{ date("d/m/Y", strtotime($post->start_date))}}</td>
                                    <td>{{date("d/m/Y", strtotime($post->end_date))}}</td>  
                                    <td> <p class="teaser">{{   \Illuminate\Support\Str::limit($post->body, 100) }} {{-- Limit teaser to 100 characters --}}</p></td>
                                   <td><p class="text-{{ $post->status->color->name}}">{{ $post->status->name}} </p></td>
                                    <td>{{ $post->resmi}}</td> 
                                    <td>{{ $post->pax}}</td>
                                    <td>{{ $post->child}}</td>
                                    <th scope="col">
                                      <a href="{{ route('posts.edit', $post->id) }}" class="btn btn-primary btn-block">Edit</a>
         
                                       
                                  </tr>
                       
                       
                    @endforeach
                           </tbody>
                  </table>
                    </div>
                    <div class="text-center">
                     {!! $posts->appends(\Request::except('page'))->links('vendor/pagination/bootstrap-4') !!}
                    </div>
                </div>
            </div>
      
@endsection
@section('footer')
<script src="{{ asset('/js/moment.min.js') }}"></script>
  <script src="{{ asset('/js/daterangepicker.js') }}"></script>
<script>

  $('input[name="daterange"]').daterangepicker({
 
    locale: {
      format: 'DD/MM/YYYY'
    }
  });

  $('input[name="daterange"]').on('apply.daterangepicker', function(ev, picker) {
 
    $('#hiddenStartDate').val(picker.startDate.format('YYYY-MM-DD'));
  $('#hiddenEndDate').val(picker.endDate.format('YYYY-MM-DD'));
    var x = document.getElementsByName('tarih');
    x[0].submit(); // Form submission
});
</script>
@endsection
