@extends('layouts.app')

@section('title', '| Create New Post')

@section('content')
   <div class="container">
    <div class="row justify-content-md-center mt-5">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">Add File from Transfert</div>
                <div class="card-body">

    {{-- Using the Laravel HTML Form Collective to create our form --}}
        {{ Form::open(array('route' => 'posts.storefromtransfert')) }}
         <div class="form-group">
            {{ Form::label('Acente', 'Acente') }}
            {{ Form::select('acente_id', $acente , null, ['class' => 'form-control']) }}
          
          
           
               
            
            </div>
        <div class="form-group">
            {{ Form::label('title', 'Title') }}
            {{ Form::text('title', null, array('class' => 'form-control')) }}
            <br>
         
            {{ Form::label('body', 'File Description') }}
            {{ Form::textarea('body', null, array('class' => 'form-control')) }}
           </div>
          
           <div class="form-row">
                <div class="form-group col-md-6">
           {{ Form::label('pax', 'Pax') }}
            {{ Form::selectRange('pax',1,100,null, array('class' => 'form-control')) }}
            </div>
               <div class="form-group col-md-6">
              {{ Form::label('child', 'Child') }}
              {{ Form::selectRange('child', 0,10,null, array('class' => 'form-control')) }}
             </div>
               </div>       
          <div class="card border-primary">         
          <div class="form-row">
               <div class="form-group col-md-3">
                  {{ Form::label('servicetype_id', 'Service Types') }}
                  {{Form::select('servicetype_id[]',$servicetypes['transfer'],"", array('class' => 'form-control')) }}
                </div> 
                <div class="form-group col-md-3">
                 {{ Form::label('start_date', 'Date') }}
                 {{ Form::date('start_date[]', date("Y-m-d"), array('class' => 'form-control')) }}
                </div>
                <div class="form-group col-md-3">
                  {{ Form::label('start_date', 'Start Time') }}
                  {{ Form::time('start_time[]',"", array('class' => 'form-control',"required"=>"required")) }}
                </div>
                <div class="form-group col-md-3">
                  {{ Form::label('start_date', 'Finish Time') }}
                  {{ Form::time('end_time[]',"", array('class' => 'form-control',"required"=>"required")) }}
                </div>
          </div>
              
          <div class="form-row">    
            <div class="form-group col-md-6">
                     {{ Form::label('from', 'From') }}
                     {{ Form::text('from[]',"", array('class' => 'form-control',"required"=>"required")) }}
            </div>
            <div class="form-group col-md-6">
      {{ Form::label('target', 'To') }}
      {{ Form::text('target[]',"", array('class' => 'form-control',"required"=>"required")) }}
              </div>       
                  
            </div> 
            <div class="form-row">    
            <div class="form-group col-md-8">
               {{ Form::label('aciklama','Notes') }}
               {{ Form::text('aciklama[]',"", array('class' => 'form-control')) }}
            </div>
             <div class="form-group col-md-4">
               {{ Form::label('vehicule_id','Vehicules') }}
               {{ Form::select('vehicule_id[]',$vehicules,"", array('class' => 'form-control')) }}
            </div> 
            </div> 
      </div>        
           <div id="satirekleme">
             
                  </div>       
         <a class="btn btn-success btn-sm" href="#" role="button" id="addRow">
                       <i class="fa fa-plus" aria-hidden="true"></i>Add More Service
                      </a>           
         
             <div class="form-group">
             
             <br>
            {{ Form::submit('Create File', array('class' => 'btn btn-success btn-lg btn-block')) }}
            {{ Form::close() }}
           
            </div>
        </div>
    </div>
</div>
 

@endsection
@section('footer')
<script>
  
$(function(){  
var sayiekleme=1;  
 $('#addRow').click(function($e){  
     $e.preventDefault();

    var div = document.createElement('div');
    sayi=sayiekleme;
    div.className = '';
   
    strtext=  '<div class="card border-primary" id="sayi'+sayi+'">  '+
            '<div class="form-row">'+
             '  <div class="form-group col-md-3">'+
                 ' {{ Form::label("servicetype_id", "Service Types") }}'+
                 ' {{Form::select("servicetype_id[]",$servicetypes["transfer"],"", array("class" => "form-control")) }}'+
              '  </div> '+
             '   <div class="form-group col-md-3">'+
               '  {{ Form::label("start_date", "Date") }}'+
                 '{{ Form::date("start_date[]", date("Y-m-d"), array("class" => "form-control")) }}'+
               ' </div>'+
               ' <div class="form-group col-md-3">'+
                '  {{ Form::label("start_date", "Start Time") }}'+
                 ' {{ Form::time("start_time[]","", array("class" => "form-control","required"=>"required")) }}'+
                '</div>'+
              '  <div class="form-group col-md-3">'+
                 ' {{ Form::label("start_date", "Finish Time") }}'+
                 ' {{ Form::time("end_time[]","", array("class" => "form-control","required"=>"required")) }}'+
              '  </div>'+
         ' </div>'+
         ' <div class="form-row">  '  +
          '  <div class="form-group col-md-6">'+
                   '  {{ Form::label("from", "From") }}'+
                  '   {{ Form::text("from[]","", array("class" => "form-control","required"=>"required")) }}'+
          '  </div>'+
           ' <div class="form-group col-md-6">'+
     ' {{ Form::label("target", "To") }}'+
     ' {{ Form::text("target[]","", array("class" => "form-control","required"=>"required")) }}'+
            '  </div>   '   + 
            '  </div>'+
         '  <div class="form-row">  '  +
          '  <div class="form-group col-md-8">'+
           '    {{ Form::label("aciklama","Notes") }}'+
            '   {{ Form::text("aciklama[]","", array("class" => "form-control")) }}'+
           ' </div>'+
             '<div class="form-group col-md-4">'+
             '  {{ Form::label("vehicule_id","Vehicules") }}'+
            '   {{ Form::select("vehicule_id[]",$vehicules,"", array("class" => "form-control")) }}'+
         '   </div>' +
          '  </div> '+
          ' <a class="btn btn-danger btn-sm" href="#" role="button" onclick="removeRow('+sayi+')"> <i class="fa fa-trash" aria-hidden="true"></i></a>'+
           ' </div>';
        
      div.innerHTML =strtext;     
    
        
      
    document.getElementById('satirekleme').appendChild(div);
    sayiekleme++;
});
});  

function removeRow(div) {
  
     document.getElementById('sayi'+div).remove();
    return false;
}




</script>
@endsection      
      