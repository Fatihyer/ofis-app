@extends('layouts.app')

@section('title', '| View Post')

@section('style')
<style>
.mce-notification-warning {display: none;}

.pac-container {
            z-index: 1051 !important; /* Modalın üzerinde görünecek şekilde z-index değeri ayarla */
        }
</style>
@endsection
@section('content')


      <div class="alert alert-{{$post->status->color->name}}" role="alert">
      {{ $post->status->name }} 
      </div>
        <div class="row">
            <div class="col-xl-3 col-lg-3 col-md-3 col-sm-6 grid-margin stretch-card">
              <div class="card card-statistics">
                <div class="card-body">
                  <div class="clearfix">
                    <div class="float-left">
                      
                       <p class="mb-0 text-right">  @lang('app.file_no') </a></p>
                      <div class="fluid-container">
                        <h3 class="font-weight-medium text-right mb-0">{{ $post->id }}</h3>
                      </div>
                   </div>
                    <div class="float-right">
                      <p class="mb-0 text-right">{{ $post->title }} </p>
                      <div class="fluid-container">
                        <p><a href="{{ route('acentes.show', $post->acente_id ) }}">{{ $post->acente->name}}</a>
                          <br>
                        @if ($post->user) 
                        <span class="text-warning">    {{$post->user->name}} </span>
                             @endif
                        </p>
                      </div>
                    </div>
                  </div>
                  <p class="text-muted mt-3 mb-0">
                    <i class="mdi mdi-alert-octagon mr-1" aria-hidden="true"></i> <a href="/logActivity/{{$post->id}}">History</a>
                    @lang('app.legal') @if ($post->resmi)<i class="fas fa-check" aria-hidden="true"></i>
                         @else <i class="far fa-square" aria-hidden="true"></i>
                         @endif
                        

                  </p>                </div>
              </div>
            </div>

             <div class="col-xl-3 col-lg-3 col-md-3 col-sm-6 grid-margin stretch-card">
              <div class="card card-statistics">
                <div class="card-body">
                  <div class="clearfix">
                    <div class="float-left">
                     
                      <div class="fluid-container">
                        <h4 class="font-weight-medium text-right mb-0">@lang('app.fromdate')</h4>
                        </div>
                       <p class="mb-0 text-right">{{ date("d-m-Y", strtotime($post->start_date))}}</p>
                    </div>
                    <div class="float-right">
                     
                      <div class="fluid-container">
                        <h4 class="font-weight-medium text-right mb-0">@lang('app.todate')</h4>
                      </div>
                       <p class="mb-0 text-right">{{date("d-m-Y", strtotime($post->end_date))}}</p>
                    </div>
                  </div>
                  <p class="mt-3 mb-0">
                    <i class="mdi mdi-calendar mr-1" aria-hidden="true"></i> Adlt:{{ $post->pax }} <br/>
                     <i class="mdi mdi-calendar mr-1" aria-hidden="true"></i>Child:{{ $post->child }}
                  </p>
                </div>
              </div>
            </div>
            <div class="col-xl-3 col-lg-3 col-md-3 col-sm-6 grid-margin stretch-card">
              <div class="card card-statistics">
                <div class="card-body">
                  <div class="clearfix">
                       <div class="fluid-container">
                      <button type="button" class="btn btn-danger btn-sm" data-toggle="modal" data-target="#exampleModalLong">Message <span class="badge badge-info" >{{count($messages)}}</span></button>
                         </div>
                  </div>
                 
                     <p class="text-muted mt-3 mb-0">Message:
                           @foreach ($messages as $message)
                          <a href="" data-toggle="modal" 
                          data-id="{{ $message->id }}"
                          data-title="{{ $message->tittle}}"
                          data-body="{{ $message->body}}"  
                          data-user_id="{{$message->user_id}}"   
                          data-user_name="{{$message->user_id?$message->user->name:""}}"   
                          data-tarih="{{date("Y-m-d",strtotime($message->tarih))}}"  
                          data-target="#editmessage">  {{$message->tittle}}</a>,
                           @endforeach
                        </p>
              </div>
            </div>
          </div>
            <div class="col-xl-3 col-lg-3 col-md-3 col-sm-6 grid-margin stretch-card">
              <div class="card card-statistics">
                <div class="card-body">
                  <div class="clearfix">
                         <div class="fluid-container">
                              <button type="button" class="btn btn-info btn-sm" data-toggle="collapse" data-target="#documents">Documents<span class="badge badge-warning" >{{count($files)}}</span></button>
                         </div>
                    
                  </div>
                  <p class="text-muted mt-3 mb-0">
                     Documents:
                       
                        @foreach ($files as $file)
                             <a href="/{{$stroreFile}}/{{$post->id}}/{{basename($file)}}">{{basename($file)}}</a>,
                          @endforeach
                  </p>
                </div>
              </div>
            </div>
    </div>

                      <div id="documents" class="collapse">
                         {{ Form::open(array('route' => 'image.upload.post','files'=>true)) }}
                         {{ Form::file('image') }}
                         {{Form::submit('Upload')}}
                         {{Form::hidden('id',$post->id)}}
                          {{ Form::close() }}
                       </div>
                    
              <div class="row">
                <div class="col-md-8 grid-margin stretch-card">
                  <div class="card">
                    <div class="card-body">
                      <h4 class="card-title">Comments</h4>
                      <p class="card-description">
                      {{$post->body}}
                      </p>
                     
                    </div>
                  </div>
                </div>    
                
                <div class="col-md-4 grid-margin stretch-card">
                  <div class="card">
                    <div class="card-body">
                        {!! Form::open(['method' => 'DELETE', 'route' => ['posts.destroy', $post->id] ]) !!}
                    <a href="{{ url()->previous() }}" class="btn btn-primary">Back</a>

                    <a href="{{ route('posts.edit', $post->id) }}" class="btn btn-success" role="button">Edit</a>
                    <a class="btn btn-primary btn-sm" href="{{ URL::to( 'posts/' . $previous ) }}"> <i class="fas fa-arrow-left"></i></a>
                   File
                                   <a class="btn btn-primary btn-sm" href="{{ URL::to( 'posts/' . $next ) }}">  <i class="fas fa-arrow-right"></i></a>
                    @can('Delete Post')
                    {!! Form::submit('Delete', ['class' => 'btn btn-danger']) !!}
                    @endcan
                    {!! Form::close() !!}

                    </div>
                  </div>
                </div>     
      </div>
  
 <div class="row">
   <div class="col-md-12 grid-margin"> 
                      <div class="card">
                           <div class="card-body">
                      
                         <a class="btn btn-success card-title" href="#"  data-toggle="modal" data-target="#addclient">Add Client Name</a>
                      
                    <div class="table-responsive">
                     <table class="table table-sm ">
                                          <thead>
                                            <tr>
                                              <th scope="col">Tittle</th>
                                              <th scope="col">Name</th>
                                              <th scope="col">Surname</th>
                                              <th scope="col">Email</th>
                                              <th scope="col">Phone</th>
                                              <th scope="col">Comments</th>

                                              <th>#</th>
                                            </tr>
                                          </thead>
                                          <tbody>
                                             @foreach ($post->client as $clients )
                                            <tr>

                                              <td>{{$clients->title}}</td>
                                              <td>{{$clients->name}}</td>
                                              <td>{{$clients->surname}}</td>
                                              <td>{{$clients->email}}</td>
                                              <td>{{$clients->tel}}</td>
                                              <td>{{$clients->comments}}</td>
                                               <td>{{ Form::open(['route' => ['clients.destroy', $clients->id], 'method' => 'delete']) }}
                                                   <a href="{{route('clients.edit',$clients->id)}}"  class="btn btn-success">Edit</a>
                                                   {{ Form::submit('Delete',array('class'=>'btn btn-danger')) }}
                                                   {{ Form::close() }}
                                              </td>


                                            </tr>
                                             @endforeach
                                          </tbody>

                      </table>  
                             </div>
                          </div>
            </div>
     </div> 
</div>   
<div class="row">
    <div class="col-md-12 grid-margin"> 
              <div class="card">
                <div class="card-body">

                      <a class="btn btn-success card-title" href="{{route('createWithTrajets',$post->id)}}" >Add Transfert</a>
                                      
                      <button id="exportButton" class="btn btn-primary"><i class="fas fa-file-excel"></i></button>
 
<a class="btn btn-warning" href="{{route('addconge',$post->id)}}">add congé</a>
      <div class="table-responsive">
      
   
        <table id="transfersTable" class="table table-sm">
                      <thead>
                        <tr>
                          <th width="8%">A/R</th>
                          <th width="13%">Start Date & Time</th>
                          <th width="10%">Finish  Date & Time</th>
                          <th width="23%">From ->To</th>
                          <th width="7%">Vehicule</th>
                          <th width="9%">Driver</th>
                          <th width="5%">Pax</th>
                          <th width="5%"><i class="fas fa-comment-dots"></i></th>
                           <th width="12%">#</th>
                           <th width="3%"><i class="fa fa-trash" aria-hidden="true"></i></th>
                        </tr>
                      </thead>
                      <tbody>
                         @foreach ($post->transfer as $transfert)
                        <tr>
                          <td class="text-{{$transfert->servicetype->color->name}}">
                          <a href="{{ route('transfers.show', $transfert->id ) }}"><i class="fa fa-eye" aria-hidden="true"></i></a>
                            {{$transfert->servicetype->name}}
                              </td>
                          <td class="table-{{(isset($transfert->status->color->name)?$transfert->status->color->name:"")}}">
                            <?php $datestart = \Carbon\Carbon::parse($transfert->start_date);
                                $dateend = \Carbon\Carbon::parse($transfert->end_date);
                                $ofisstart = $transfert->ofis_start ? \Carbon\Carbon::parse($transfert->ofis_start) : NULL;    ?>
                            {{$datestart->format('d-m-Y')}} {{$datestart->format('H:i')}}
                           
                               </td>
                           <td class="table-{{(isset($transfert->status->color->name)?$transfert->status->color->name:"")}}">
                            @if ($transfert->servicetype->hizmet)  {{$dateend->format('d-m-Y')}}@endif {{$dateend->format('H:i')}} </td>
                           <td class="table-{{(isset($transfert->status->color->name)?$transfert->status->color->name:"")}}">{{\Illuminate\Support\Str::limit($transfert->from, 50) }}->{{\Illuminate\Support\Str::limit($transfert->target,50) }}
                            @if ($transfert->trajets->count() == 0)
                            <div class="alert alert-danger">
                                <strong>Warning!</strong> No trajets found. Please enter new information below.
                            </div>
                        @else
                          
                            <ul class="list-group">
                                @foreach ($transfert->trajets as $index => $trajet)
                                    <li class="list-group-item d-flex justify-content-between align-items-center">
                                        <div>
                                            <strong class="text-primary">#{{ $index + 1 }}</strong>
                                            <span class="ml-2">{{ $trajet->datetime->format('d-m-Y H:i') }}</span>
                                    
                                            <span class="ml-2 text-muted">[{{ $trajet->type }}]</span>
                                            <span class="ml-2"> {{ $trajet->from }}</span>
                                            @if($trajet->google_address)
                                                <span class="ml-2"><strong>Address:</strong> {{ $trajet->google_address }}</span>
                                            @endif
                                             </div>
                                    </li>
                                @endforeach
                            </ul>
                        @endif
                        Total KM:{{$transfert->km}}
                        


                           </td>
                           <td>{{$transfert->vehicule?$transfert->vehicule->name:'' }}</td>
                          <td> @if (isset($transfert->driver->name)) {{$transfert->driver->name}} @else <p class="text-danger"><i class="fas fa-exclamation-triangle"></i>No driver</p> @endif</td> 
                           <td>{{$transfert->pax }}</td>
                           <td>@if ($transfert->comments)  <a data-toggle="popover" title="Comments" data-content="{{$transfert->comments}}">
                             <i class="fas fa-comment-dots"></i></a>
                             @else <i class="fal fa-comment"></i> @endif</td>
                           
                           <td>
                             
                
                             @if ($transfert->servicetype->hizmet!=0)
                             <a class="btn btn-primary btn-sm" href="#"  data-toggle="modal" 
                                               data-id="{{$transfert->id}}"
                                               data-servicetype="{{$transfert->servicetype->id}}"

                                               data-date="{{$datestart->format('Y-m-d')}}"
                                               data-dateend="{{$dateend->format('Y-m-d')}}"
                                               
                                               data-time="{{$datestart->format('H:i')}}"
                                               data-endtime="{{$dateend->format('H:i')}}"

                                               data-ofisdate="{{$ofisstart ->format('Y-m-d')}}"
                                               data-ofistime="{{$ofisstart ->format('H:i')}}"

                                               data-from="{{$transfert->from}}"
                                               data-to="{{$transfert->target}}"
                                               data-vehicule="{{$transfert->vehicule?$transfert->vehicule->id:''}}"
                                               data-driver="{{isset($transfert->driver->id)?$transfert->driver->id:""}}" 
                                               data-pax="{{$transfert->pax}}"
                                               data-comments="{{$transfert->comments}}"
                                               data-mission="{{$transfert->mission}}"
                                                
                                               data-firma="{{(isset($transfert->driver->firmas[0])?$transfert->driver->firmas[0]->id:0)}}"
                                               data-status="{{$transfert->status_id}}"
                                               data-target="#editdispo">Edit Dispo</a>
                      
                             @else 
                             @hasanyrole('Admin|ofis')  
                             <a class="btn btn-primary btn-sm" href="{{route('transfers.edit',$transfert->id)}}" >Edit Transfert</a>
                             @endhasanyrole
                             <a class="btn btn-primary btn-sm" href="#"  data-toggle="modal" 
                             data-id="{{$transfert->id}}"
                             data-servicetype="{{$transfert->servicetype->id}}"
                             
                             
                             data-vehicule="{{$transfert->vehicule?$transfert->vehicule->id:''}}"
                             data-driver="{{isset($transfert->driver->id)?$transfert->driver->id:""}}" 
                             data-pax="{{$transfert->pax}}"
                             data-comments="{{$transfert->comments}}"
                             data-mission="{{$transfert->mission}}"
                             data-firma="{{(isset($transfert->driver->firmas[0])?$transfert->driver->firmas[0]->id:0)}}"
                             data-status="{{$transfert->status_id}}"
                             data-target="#edittransfert">Edit</a>
                             
                          @endif
                              @if ($transfert->status_id!=3)
                              <a href="{{ route('transfers.clone', $transfert->id, false ) }}" class="btn btn-danger btn-sm">  <i class="far fa-clone"></i>clone</a>
                              
                              @endif
                             
                          </td>
                          <td>
                           <form action="{{ route('transfers.destroy',$transfert->id) }}" method="POST" class="form-inline">
                                            {{ method_field('DELETE') }}
                                            {{ csrf_field() }}
                                            <button class="btn btn-warning btn-sm"><i class="fas fa-trash-alt"></i></button>
                                        </form></td>
                         </tr>
                      
                        @endforeach
                        </tbody>
                </table> 
         </div>
      </div> </div>
                
                </div>
</div>       
  


  
<div class="row"> 
  <div class="col-md-12 grid-margin"> 
<div class="card">
   <div class="card-body">
    
        <a class="btn btn-success card-title" href="{{route('stocks.create')}}?file={{$post->id}}&acente={{$post->acente_id}}" >Add Product</a>
    
             <div class="table-responsive">
      
  
          <table class="table table-sm ">
                      <thead>
                        <tr>
                          <th width="8%">Product Cath</th>
                          <th width="13%">Product</th>
                          <th width="13%">Date</th>
                          <th width="10%">Quantity</th>
                          <th width="10%">Provider</th>
                          <th width="7%">#</th>
                        </tr>
            </thead>
                  <tbody>
                   @foreach ($post->stock as $stocks)
                    <tr>
                   <td>{{$stocks->urun->name}}</td> 
                   <td>{{$stocks->urun->name}}</td> 
                   <td>{{$stocks->tarih}}</td> 
                   <td>{{$stocks->adet}}</td> 
                   <td>{{$stocks->alacakli->name}}</td> 
                      <td><a class="btn btn-success" href="{{route('stocks.edit',$stocks->id)}}">edit</a></td>    
                    </tr>
                  @endforeach
            </tbody>
               </table>
               </div>
               
               </div>
            </div> 
    </div>
</div> 


<div class="row"> 
  <div class="col-md-12 grid-margin"> 
<div class="card">
   <div class="card-body">
    
        <a class="btn btn-success card-title" href="{{route('hotels.create')}}?file={{$post->id}}&acente={{$post->acente_id}}" >Add Hotel</a>
    
             <div class="table-responsive">
      
  
          <table class="table table-sm ">
                      <thead>
                        <tr>
                          <th width="8%">Hotel Name</th>
                          <th width="10%">From</th>
                          <th width="10%">to</th>
                          <th width="5%">Acc</th>
                          <th width="5%">Sng</th>
                          <th width="5%">Dbl</th>
                          <th width="5%">Trp</th>
                           <th width="5%">Qtp</th>
                           <th width="5%">Fam</th>
                          <th width="5%">chd</th>
                          <th width="5%">Chd Age</th>
                          <th width="5%">Pax</th>
                           <th width="5%">Comment</th>
                           <th width="5%">#</th>
                        </tr>
            </thead>
                  <tbody>
                   @foreach ($post->hotels as $hotel)
                    <tr>
                   <td>{{$hotel->acente->name}}</td> 
                   <td>{{date("d-m-Y", strtotime($hotel->from)) }}</td> 
                   <td>{{date("d-m-Y", strtotime($hotel->to)) }}</td> 
                   <td>{{$hotel->servicetype->name}}</td>   
                   <td>{{$hotel->sng}}</td> 
                      <td>{{$hotel->dbl}}</td>
                       <td>{{$hotel->trp}}</td>
                       <td>{{$hotel->qtr}}</td>
                      <td>{{$hotel->fam}}</td>
                      <td>{{$hotel->chd}}</td>
                       <td>{{$hotel->chdyears}}</td>
                      <td>{{$hotel->pax}}</td>
                      <td>{{$hotel->comment}}</td>
                   <td> <form action="{{ route('hotels.destroy',$hotel->id) }}" method="POST" class="form-inline">
                                            {{ method_field('DELETE') }}
                                            {{ csrf_field() }}
                     <a href="{{route('hotels.edit',$hotel->id)}}" class="btn btn-primary btn-sm"><i class="fas fa-edit"></i></a>
                     <a href="mailto:{{$hotel->acente->email}}?subject={{$post->title}} Ref:{{$post->id}}/{{$hotel->id}}&body=Aşağıda detayları olan rezervasyonumuzu konfirme edilmesini rica ederiz,%0D%0A
Hotel: {{$hotel->acente->name}}%0D%0A
File No: {{$post->id}}%0D%0A
Res No:{{$hotel->id}}%0D%0A
In:    {{date("d-m-Y", strtotime($hotel->from)) }}%0D%0A
Out:   {{date("d-m-Y", strtotime($hotel->to)) }}%0D%0A
Room(s):{{$hotel->sng?$hotel->sng.'sng,':""}}{{$hotel->dbl?$hotel->dbl.'dbl,':""}}{{$hotel->trp?$hotel->trp.'trp,':""}}{{$hotel->fam?$hotel->fam.'fam,':""}}{{$hotel->chd?$hotel->chd.'chd,':""}}{{$hotel->chdyears?$hotel->chdyears.'chdyears,':""}}%0D%0A
Pax:   {{$hotel->pax }}%0D%0A
Accomodation:   {{$hotel->servicetype->name }}%0D%0A
Names: @foreach ($post->client as $clients ){{$clients->title }} {{$clients->name }} {{$clients->surname }} , @endforeach%0D%0A
{{$hotel->comment}}%0D%0A
" 
                      
                      
                      
                      class="btn btn-success btn-sm"><i class="fas fa-envelope-open"></i></a>
                    <button class="btn btn-danger btn-sm"><i class="fas fa-trash-alt"></i></button>
                    
                                        </form>
                                        <a  class="btn btn-success btn-sm" href="{{ route('vouchertopdf',[$hotel->id,$hotel->acente->id,'html']) }}"><i class="fa fa-eye" aria-hidden="true"></i></a>
            
                                      </td>    
                    </tr>
                  @endforeach
            </tbody>
               </table>
               </div>
               
               </div>
            </div> 
    </div>
</div> 

<div class="row"> 
  <div class="col-md-12 grid-margin"> 
<div class="card">
   <div class="card-body">
    
        <a class="btn btn-success card-title" href="{{route('others.create')}}?file={{$post->id}}&acente={{$post->acente_id}}" >Add Other Services</a>
    
             <div class="table-responsive">
      
  
          <table class="table table-sm ">
                      <thead>
                        <tr>
                          <th width="8%">Provider</th>
                          <th width="10%">From</th>
                          <th width="10%">to</th>
                          <th width="5%">Pax</th>
                          <th width="5%">Comment</th>
                          <th width="5%">#</th>
                        </tr>
            </thead>
                  <tbody>
                   @foreach ($post->others as $other)
                    <tr>
                   <td>{{$other->acente->name}}</td> 
                   <td>{{date("d-m-Y", strtotime($other->from)) }}</td> 
                   <td>{{date("d-m-Y", strtotime($other->to)) }}</td> 
                   <td>{{$other->pax}}</td>
                   <td>{{$other->comment}}</td>
                   <td> <form action="{{route('others.destroy',$other->id)}}" method="POST" class="form-inline">
                                            {{ method_field('DELETE') }}
                                            {{ csrf_field() }}
                     <a href="{{route('others.edit',$other->id)}}" class="btn btn-success">Edit</a>
                     <a href="{{route('others.clone',$other->id)}}" class="btn btn-danger">Clone</a>
                                            <button class="btn btn-warning btn-sm"><i class="fas fa-trash-alt"></i></button>
                                        </form></td>    
                    </tr>
                  @endforeach
            </tbody>
               </table>
               </div>
               
               </div>
            </div> 
    </div>
</div> 


@hasanyrole('Admin|ofis')                         
<div class="row"> 
              <div class="col-md-12 grid-margin"> 
            <div class="card border-primary" id="whatever">
               <div class="card-body">                          
              <h3 class="card-title">Expenses</h3>
                  <a href="{{ route('post.excellist', $post->id) }}" class="btn btn-success" role="button">excel</a>
            <div class="table-responsive">
                  <table class="table table-sm">
                    <thead>
                    <tr>
                      <th>Service </th>
                      <th>Provider</th>
                      <th>Date</th>
                      <th>Pax</th>  
                    
                      <th>Sale Price</th>
                       <th>Comments</th>
                      <th>Payment</th>
                      <th>Amount</th>
                     <th>Invoice</th>
                      <th>#</th>
                      </tr>
                    </thead>
                    
                    @foreach ($post->hareket as $harekets)
                    @if( (isset($harekets->hareketable->servicetype_id))&&($harekets->hareketable->servicetype_id>0))
                             <tr>{{ Form::model($harekets, array('route' => array('harekets.update', $harekets->id), 'method' => 'PUT','class'=>'hareketupdate' )) }}
                              <td>{{$harekets->hareketable->servicetype->name }} </td>
                               <td>
                               @if(isset($harekets->acente->name))
                               <a href="{{ route('acentes.show', $harekets->acente->id ) }}">
                               {{$harekets->acente->name}}

                               </a>
                               @endif
                                 </td>
                               <td>{{date("d-m-Y", strtotime($harekets->tarih)) }}
                              <td>{{$harekets->hareketable->pax}}</td>  
                               
                               <td>
                               {{Form::text('default_price',$harekets->default_price, array())}}
                                
                               </td>
                               <td>{{Form::text('aciklama',$harekets->aciklama, array())}}
                                @php
                                  $paymentsArray = $payments->toArray();
                       
                              @endphp
                               </td><td>{{Form::select('payment_id',['0'=>'sec']+$paymentsArray,$harekets->payment_id,array('class'=>'payment','id'=>$harekets->id))}}
                               <label  style="{{$harekets->payment_id==2?"":"display:none;"}}" class="lcach{{$harekets->id}}"><i class="fas fa-money-bill-alt"></i>
                                 {{Form::text('cash',($harekets->offset_id>0)?abs($harekets->offset->harekets[0]->amount):"" )}}
                                  {{($harekets->offset_id>0)?$harekets->offset->borclu->name:""}} 
                                  </label>
                               </td><td>{{Form::number('amount',abs($harekets->amount), array('step' => '.01'))}}
                               {{Form::select('kur_id',$kurs,$harekets->kur_id, array())}}
                               {{Form::hidden('user',Auth::user()->name )}}
                          </td>
                            <td>{{Form::number('invoiceno',$harekets->invoiceno)}}</td>
                               <td>
                                 @if(isset($harekets->acente->name)) 
                             <button type="submit"  data-hareket="{{$harekets->id}}" class="btn btn-light guncel" ><i class="fas fa-save" aria-hidden="true"></i></button>
                              <span class="result{{$harekets->id}}"></span>
                                  @endif

                              </td>
                                  {{Form::close()}}
                              
                           
                    
                    </tr>
                      @if (($harekets->offset_id>0)&&($harekets->tarih!=$harekets->offset->harekets[0]->tarih)) 
                    <tr>
                      <td colspan="12"> <div class="alert alert-danger" role="alert">!!!!!Transfer tarihleri değişmiş Kayıt butonuna basarak tarihleri düzeltin!!!!!!</div>
                      
                      </td>
                    </tr>
                    
                    @endif
                     @if (($harekets->offset_id>0)&&($harekets->offset->b_acente_id!=$harekets->acente_id))
                      <tr>
                      <td colspan="12"> <div class="alert alert-danger" role="alert">!!!!!Transfer Yapan değişimiş değişmiş Kayıt butonuna basarak offseti düzeltin düzeltin!!!!!!</div>
                      
                      </td>
                    </tr>
                    
                    @endif
             
                 
                 
                 
                    @endif
                    @if ( (isset($harekets->hareketable->urun_id)) &&($harekets->hareketable->urun_id>0)) 
                  <tr> 
                   <td>{{$harekets->hareketable->urun->name}}</td> 
                      <td> <a href="{{ route('acentes.show', $harekets->acente->id ) }}">
                        {{$harekets->acente->name}}</a></td>
                    <td> {{date("d-m-Y", strtotime($harekets->tarih)) }}</td>
                    <td></td>
                    <td> {{$harekets->adet }}</td>
                    <td> {{$harekets->default_price}}</td>
                    <td> {{$harekets->aciklama }}</td>
                    <td> {{($harekets->hareketable->credit>0)?"Cash":"Credit"}}</td>
                      <td>{{$harekets->amount }}</td>
                      <td>{{$harekets->kur->name }}</td>
                    <td>{{$harekets->invoiceno}}</td>
                  </tr>
                  
                   
                    
                   @endif
                   @if ($harekets->hareketable_type=="App\Other")  
                      <tr> {{ Form::model($harekets, array('route' => array('harekets.update', $harekets->id), 'method' => 'PUT','class'=>'hareketupdate' )) }}
                         <td>other service</td>
                        <td> <a href="{{ route('acentes.show', $harekets->acente->id ) }}">{{$harekets->acente->name}}</a></td>
                        <td>{{ date("d-m-Y", strtotime($harekets->tarih)) }}</td>
<td>{{ $harekets->hareketable->pax }}</td>
<td>{{ Form::text('default_price', $harekets->default_price, []) }}</td>
<td>{{ Form::text('aciklama', $harekets->aciklama, []) }}</td>
<td>
    @php
        $paymentsArray = $payments->toArray();
    @endphp
    {{ Form::select('payment_id', ['0' => 'sec'] + $paymentsArray, $harekets->payment_id, ['class' => 'payment', 'id' => $harekets->id]) }}
    <label style="{{ $harekets->payment_id == 2 ? '' : 'display:none;' }}" class="lcach{{ $harekets->id }}">
        <i class="fas fa-money-bill-alt"></i>
        {{ Form::text('cash', ($harekets->offset_id > 0) ? abs($harekets->offset->harekets[0]->amount) : "") }}
        {{ ($harekets->offset_id > 0) ? $harekets->offset->borclu->name : "" }}
    </label>
</td>
<td>
    {{ Form::number('amount', abs($harekets->amount), ['step' => '.01']) }}
    {{ Form::select('kur_id', $kurs, $harekets->kur_id, []) }}
    {{ Form::hidden('user', Auth::user()->name) }}
</td>
<td>{{ Form::number('invoiceno', $harekets->invoiceno) }}</td>
<td>
    @if(isset($harekets->acente->name))
        <button type="submit" data-hareket="{{ $harekets->id }}" class="btn btn-light guncel">
            <i class="fas fa-save" aria-hidden="true"></i>
        </button>
        <span class="result{{ $harekets->id }}"></span>
    @endif
</td>

                                  {{Form::close()}}
                              
                      </tr>
                   @endif
                 
                    @endforeach
                  </table> 
                </div>
        </div>
                </div>
  </div>
</div>
 
<div class="row"> 
          <div class="col-xl-8 col-lg-8 col-md-8 col-sm-8 grid-margin stretch-card">
            <div class="card border-primary" id="whatever">
               <div class="card-body">                          
              <h3 class="card-title">Invoice</h3>
            

     
                <button type="button" class="btn btn-danger btn-sm" data-toggle="modal" data-target="#addinvoice">Add Invoice</button>
             <a class="btn btn-warning btn-sm" href="{{route('autofacture',$post->id)}}">Auto Proforma</a>
                 
               <div class="table-responsive-sm">
                 <table class="table table-sm">
                 <thead>
                    <tr>
                      <th scope="col">Date</th>
                      <th scope="col">No/Grup</th>
                      <th scope="col">Agency</th>
                      <th scope="col">Title</th>
                           <th scope="col">Price</th>
                       <th scope="col">++</th>
                    </tr>
                  </thead>
                  <tbody>
                    
                 @foreach ($post->invoice as $invoices)
                <tr>
                <td> {{date('d-m-Y',strtotime($invoices->tarih))}}   </td>
                <td>{{$invoices->id}} {{(isset($invoices->groupinvoice[0]->id))?$invoices->groupinvoice[0]->id:"Yok"}} 
                  {{$invoices->resmi}} </td>
                 <td> 
                   <a href="{{route('acentes.show',$invoices->acente->id)}}">{{$invoices->acente->name}} </a></td> 
                  <td>  <?php $detail=unserialize($invoices->detail); ?> {{$detail['tittle']}} </td>
                <td>  {{$invoices->amount}} <i class="fas fa-{{$invoices->kur->icon}}-sign" aria-hidden="true"> </i>
              
  
       <a  title="Bakiye" data-poload="{{ route('hareket.bakiye',$invoices->acente_id) }}">???</a>

                  
                  </td>   
                <td>  <a  href="{{route('invoices.edit',$invoices->id)}}" class="btn btn-primary btn-sm"><i class="fas fa-pencil-alt" aria-hidden="true"></i></a>
                                  
                  <a  class="btn btn-danger btn-sm" href="{{ route('invoicetopdf',[$invoices->id,'pdf']) }}"><i class="fas fa-file-pdf"></i></a>
                  <a  class="btn btn-primary btn-sm" href="{{ route('invoicetopdf',[$invoices->id,'pdf2']) }}"><i class="fas fa-file-pdf"></i></a>
               
                 
                  <a  class="btn btn-success btn-sm" href="{{ route('invoicetopdf',[$invoices->id,'html']) }}"><i class="fa fa-eye" aria-hidden="true"></i></a>
                  </td> 
                    </tr>
                  @endforeach 
                 </table>
                 </div>
                 
                </div>
         </div>
      </div>
      <div class="col-xl-4 col-lg-4 col-md-4 col-sm-4 grid-margin stretch-card">
            <div class="card border-primary" id="whatever">
               <div class="card-body">                          
              <h3 class="card-title">Balance</h3>
            <?php
              $num = $post->hareket->groupBy('kur_id')->map(function ($row) {
             return $row->sum('amount');
                 });
                $karzarar=array();
                $eurocarpan=1;
                $usdcarpan=1; 
                 foreach ($num as $kz=>$key)
                 {
                   echo $key, $kurs[$kz],  " ";
                   $karzarar[$kz]=$key;
                     
                 } 
                 
               echo "<br/>TCMB:<br/>";  
                if(isset($usdkur->value)) {echo $usdkur->kur->short_name,": " , $usdcarpan=$usdkur->value,"<br/>";
                                          
                                          }  
                else { echo "Dolar kuru ekle <a href=\"",route('dovizs.index'),"?start_date=",date('Y-m-d', strtotime($post->start_date)),"\">add</a>"; }  
                 
                 if(isset($eurkur->value)) {echo $eurkur->kur->short_name,": " ,  $eurocarpan=$eurkur->value;
                                          
                                          }  
                else { echo "Eur kuru ekle <a href=\"",route('dovizs.index'),"?start_date=",date('Y-m-d', strtotime($post->start_date)),"\">add</a>"; }    // // 
                
               echo "<p><strong>K/Z=",(array_key_exists($eurid->value,$karzarar)? $karzarar[$eurid->value]:0)+ 
                          (array_key_exists($usdid->value,$karzarar)? $karzarar[$usdid->value]*$usdcarpan/$eurocarpan:0)+
                         (array_key_exists($tlid->value,$karzarar)? $karzarar[$tlid->value]/$eurocarpan:0)
                        ,"</strong></p>"; 
               
                 ?>   
                
                                   
                </div>
         </div>
      </div>
      
  
  
  
  
</div>
     
  
@endhasanyrole
  
  
  


<!-- Modal add message-->
<div class="modal fade" id="exampleModalLong" tabindex="-1" role="dialog" aria-labelledby="exampleModalLongTitle" aria-hidden="true">
  <div class="modal-dialog modal-lg" role="document">
     
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLongTitle">New Message</h5>
        
        
       
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>{{ Form::open(array('route' => 'message.kayit')) }}
      <div class="modal-body">
        {{ Form::label('tittle', 'Title', array('for' => 'validationDefault01')) }}
            {{ Form::text('tittle', null, array('class' => 'form-control','required'=>'required','placeholder'=>'Name')) }}
         {{ Form::label('tarih', 'Date', array('for' => 'validationDefault01')) }}
            {{ Form::date('tarih', \Carbon\Carbon::now(), array('class' => 'form-control','required'=>'required')) }}
       {{ Form::checkbox('user_id', Auth::id())}} Sadece ben değişiklik yapabilirim
      
        {{ Form::label('body', 'Message', array('for' => 'validationDefault00')) }}
            {{ Form::textarea('body',null, array('class' => 'form-control description')) }}
           {{Form::hidden('post_id',$post->id)}}
        
      
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
         {{Form::submit('Add Message',array('class'=>'btn btn-primary'))}}
       
      </div>
       {{form::close()}}
    </div>
    
  </div>
</div>

<!-- Modal Edit message-->
<div class="modal fade" id="editmessage" tabindex="-1" role="dialog" aria-labelledby="exampleModalLongTitle" aria-hidden="true">
  <div class="modal-dialog modal-lg" role="document">
     
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLongTitle">Edit Message</h5>
        
        
       
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>{{ Form::open(array('route' => 'message.edit')) }}
      <div class="modal-body">
        {{ Form::label('tittle', 'Title', array('for' => 'validationDefault01')) }}
            {{ Form::text('tittle', null, ['id' => 'data-title','class'=>'form-control']) }}
        
        {{ Form::label('tarih', 'Date', array('for' => 'validationDefault01')) }}
            {{ Form::date('tarih',null, ['id' => 'data-tarih','class'=>'form-control']) }}
       <span id="gizle2">    {{ Form::checkbox('user_id', Auth::id(),null,['id' => 'data-user'])}} Sadece ben değişiklik yapabilirim</span> 
          
        {{ Form::label('body', 'Message', array('for' => 'validationDefault00')) }}
            {{ Form::textarea('body',null,['id' => 'data-body','class'=>'form-control description','rows'=>'25']) }}
        
        {{Form::hidden('id',"",['id' => 'data-id'])}}
      </div>
      <div class="modal-footer">
         <span id="sadeceuser"></span>
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
         {{Form::submit('Edit Message',array('class'=>'btn btn-primary','id'=>"gizle"))}}
        
      </div>
       {{form::close()}}
    </div>
    
  </div>
</div>
@include ('transfert.create') {{-- Including create blade file --}}
@include ('transfert.edit') {{-- Including create blade file --}}
@include ('invoice.addinvoice') {{-- Including create blade file --}}  
@include ('clients.clients') {{-- Including create blade file --}}  

@endsection
@section('footer')

<script src="https://cdn.tiny.cloud/1/0ndnl4vpulqi0sna0omx0ggs8jtxlwnv5ujlq0n0pvjtgit7/tinymce/6/tinymce.min.js" referrerpolicy="origin"></script>

<script>
tinymce.execCommand('mceRemoveControl', true, '#data-body');
  </script>
<script>
$('.payment').on('change',function(e){
     
      var optionSelected = $("option:selected", this);
     var valueSelected = this.value;
       id =this.id;
     
  
     if(valueSelected == 2){
        
        $('.lcach'+id).show();
     }
     else{
        $('.lcach'+id).hide();
     }
      e.preventDefault()
 })
</script>
 <script>
$('.hareketupdate').on('submit',function(e){
    var form = $(this);
    var submit = form.find("[type=submit]");
    var submitOriginalText = submit.attr("value");
   $('.result').append( "<i class=\"icon-ok\"></i>" );
    e.preventDefault();
    var data = form.serialize();
    var url = form.attr('action');
    var post = form.attr('method');
    $.ajax({
        type : post,
        url : url,
        data :data,
        success:function(data){
           submit.attr("value", "Submitted");
          $('.result'+data.data).append( "<i class=\"fa fa-check\" style=\"color:#008000;\"\></i>"+data.acente);
          
        },
        beforeSend: function(){
           submit.attr("value", "Loading...");
           submit.prop("disabled", true);
          
        },
        error: function(xhr, status, error) {
           // submit.attr("value", submitOriginalText);
         //   submit.prop("disabled", false);
            // Display error message
         //   alert("An error occurred: " + error);
        }
    })
})
   </script>
  <script>  $('#editmessage').on('show.bs.modal', function (event) {
  var button = $(event.relatedTarget) // Button that triggered the modal
  var recipient = button.data('id') // Extract info from data-* attributes
  var recipmname = button.data('title') 
  var recipbody = button.data('body') 
  var reciptarih = button.data('tarih') 
  var recipuser = button.data('user_id') 
  var recipusername = button.data('user_name') 
  // If necessary, you could initiate an AJAX request here (and then do the updating in a callback).
  // Update the modal's content. We'll use jQuery here, but you could use a data binding library or other methods instead.
  var modal = $(this)
  modal.find('.modal-title').text('Edit  ' + recipmname)
  modal.find('.modal-body #data-id').val(recipient)
  modal.find('.modal-body #data-title').val(recipmname)
  modal.find('.modal-body #data-body').val(recipbody)    
  modal.find('.modal-body #data-tarih').val(reciptarih)  

  if (recipuser>=1) 
    {
            if (recipuser=={{Auth::id()}}){    
            modal.find('.modal-body #data-user').prop('checked',true);

            } 
           else{
              modal.find('.modal-body #data-user').prop('checked',false);
            document.getElementById("gizle").style.display='none';
            document.getElementById("gizle2").style.display='none';
             document.getElementById("sadeceuser").innerHTML="Sadece "+recipusername+ " Değişiklik yapabilir veya yeni message açın";
           } 
 }  
else
  {
  modal.find('.modal-body #data-user').prop('checked',false);   
  }
  modal.find('.modal-body #data-user').val({{Auth::id()}});     
  
      
    tinymce.init({
    selector:'textarea.description',
    height: 600
    });   
})

   $('#editmessage').on('hidden.bs.modal', function (event) {
      tinyMCE.remove()
      document.getElementById("gizle").style.display='block';
      document.getElementById("sadeceuser").innerHTML="";
     });
    
    </script>

<script>
 $('#exampleModalLong').on('show.bs.modal', function (event) {
    tinymce.init({
    selector:'textarea.description',
    height: 600,
     plugins: "advcode",
   
    });  
})

</script>
<script>

$('*[data-poload]').click(function() {
    var e=$(this);
    e.off('click');
    $.get(e.data('poload'),function(d) {
        e.popover({content: d}).popover('show');
    });
});
</script>
<script>
  document.getElementById('exportButton').addEventListener('click', function() {
      var table = document.getElementById('transfersTable');
      var html = table.outerHTML;
      var url = 'data:application/vnd.ms-excel,' + encodeURIComponent(html);
      var downloadLink = document.createElement("a");
      downloadLink.href = url;
      downloadLink.download = 'transfers.xls';
      document.body.appendChild(downloadLink);
      downloadLink.click();
      document.body.removeChild(downloadLink);
  });
</script>

@include ('transfert.createEdit-js') {{-- Including create blade file --}}
@include ('clients.clients-js') {{-- Including create blade file --}}
@include ('invoice.invoices-js') {{-- Including create blade file --}}

@endsection