@extends('layouts.app')
@section('style')
  <link href="{{ asset('css/daterangepicker.css') }}" rel="stylesheet">

@endsection

@section('content')

<h3>{{date('d.m.Y',strtotime($tarih))}}</h3>
<a href="{{route('listegunluk',$yesterday)}}"><i class="material-icons" style="font-size:36px">chevron_left</i></a>
<a href="{{route('listegunluk',$today)}}"  class="btn btn-danger">Today</a>
<a href="{{route('listegunluk',$tomorrow)}}"><i class="material-icons" style="font-size:36px">chevron_right</i></a>
<?php
$alis=0;
$satis=0;

?> 
        
    <table class="table-sm table-striped">
        <thead>
            <tr>
              <th>File no</th>
              <th>Driver</th>
              <th>Alış</th>
              <th>Satış</th>
              <th>Total</th>
            </tr>
          </thead>
          <tbody>
            @foreach ($hareket as $key =>  $item)
           <tr>
            <td> <a href="{{route('posts.show',$item->post_id)}}">  {{$item->post_id}}</a></td>
            <td>{{$item->hareketable->driver->name}}</td>
            <td>{{$item->amount}} </td>
            <td>{{$item->default_price}}</td>
            <td>{{$item->amount+$item->default_price}}</td>
           </tr>
           <?php $alis+=$item->amount ?>
           <?php $satis += $item->default_price?>
            @endforeach
        </tbody> 
        <tfoot>
            <tr>
            <td>Total</td>
            <td></td>
            <td>{{ $alis}}</td>
            <td>{{ $satis}}</td>    
            <td>{{ $satis+$alis}}</td>    
            
            </tr>    
        </tfoot>      
    </table>
    <br>

   
@endsection
