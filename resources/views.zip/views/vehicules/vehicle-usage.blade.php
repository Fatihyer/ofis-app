@extends('layouts.app')
@section('style')


<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Vehicles Last Usage Chart</title>
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
@endsection

@section('content')
<div style="width: 90%; margin: auto;">
    <h1>Vehicle Usage by Date</h1>
    <canvas id="vehicleUsageChart"></canvas>
</div>
@endsection
@section('scripts')
<script>
    // JavaScript code for vehicle usage chart
    const vehicleNames = <?php echo json_encode($vehicles->pluck('name')->toArray(), JSON_HEX_TAG | JSON_UNESCAPED_UNICODE); ?>;
    const lastUsedDates = <?php echo json_encode(
        $vehicles->pluck('last_used_date')->map(function ($date) {
            return $date ? date('Y-m-d', strtotime($date)) : null;
        })->toArray(),
        JSON_HEX_TAG | JSON_UNESCAPED_UNICODE
    ); ?>;

    const uniqueDates = Array.from(new Set(lastUsedDates.filter(date => date !== null))).sort();
    const dataPoints = [];

    vehicleNames.forEach((vehicle, index) => {
        const date = lastUsedDates[index];
        if (date) {
            const xIndex = uniqueDates.indexOf(date);
            dataPoints.push({ x: xIndex, y: index });
        }
    });

    const ctx = document.getElementById('vehicleUsageChart').getContext('2d');
    new Chart(ctx, {
        type: 'scatter',
        data: {
            labels: uniqueDates,
            datasets: [{
                label: 'Vehicle Usage',
                data: dataPoints,
                backgroundColor: 'rgba(75, 192, 192, 0.7)',
                borderColor: 'rgba(75, 192, 192, 1)',
                pointRadius: 6
            }]
        },
        options: {
            responsive: true,
            scales: {
                x: {
                    type: 'category',
                    labels: uniqueDates,
                    title: {
                        display: true,
                        text: 'Dates'
                    }
                },
                y: {
                    type: 'category',
                    labels: vehicleNames,
                    title: {
                        display: true,
                        text: 'Vehicles'
                    }
                }
            },
            plugins: {
                tooltip: {
                    callbacks: {
                        title: (tooltipItems) => `Date: ${uniqueDates[tooltipItems[0].parsed.x]}`,
                        label: (tooltipItem) => `Vehicle: ${vehicleNames[tooltipItem.parsed.y]}`
                    }
                }
            }
        }
    });
</script>
@endsection