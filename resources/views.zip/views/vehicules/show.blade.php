@extends('layouts.app')

@section('content')
<div class="container">
   <!-- Tab Nav (Bootstrap 4 uyumlu) -->
   <ul class="nav nav-tabs" id="vehiculeTab" role="tablist">
        <li class="nav-item">
            <a class="nav-link active" id="details-tab" data-toggle="tab" href="#details" role="tab">Vehicule Details</a>
        </li>
        <li class="nav-item">
            <a class="nav-link" id="missions-tab" data-toggle="tab" href="#missions" role="tab">List of Mission</a>
        </li>
        <li class="nav-item">
            <a class="nav-link" id="maintenance-tab" data-toggle="tab" href="#maintenance" role="tab">Maintenance</a>
        </li>
    </ul>

    <!-- Tab Content -->
   <!-- Tab Content -->
   <div class="tab-content border p-3" id="vehiculeTabContent">
        <!-- Vehicule Details -->
        <div class="tab-pane fade show active" id="details" role="tabpanel">
            <form id="vehicleSelec" action="" method="GET">  
                <div class="form-group">
                    <label for="vehicule_id">Select Vehicule:</label>
                    <select class="form-control" id="vehicule_id" name="vehicule_id">
                        <option value="">Select Vehicule</option>
                        @foreach($vehicules as $vehiculeff)
                            <option value="{{ $vehiculeff->id }}" @if($vehicule->id == $vehiculeff->id) selected @endif>{{ $vehiculeff->name }}</option>
                        @endforeach
                    </select>
                </div>
            </form>

            <h1>{{ $vehicule->name }}</h1>
            <p>Plaka: {{ $vehicule->plaka }}</p>
            <p>Model: {{ $vehicule->yil }}</p>
            <p>Capacity: {{ $vehicule->capacity }}</p>
            <p>Control Technique: {{ date('d-m-Y', strtotime($vehicule->control)) }}</p>
            <p>Assurance: {{ date('d-m-Y', strtotime($vehicule->sigorta)) }}</p>
            <p>Sales: {{ $vehicule->sales ? 'Yes' : 'No' }}</p>

            <h3>Kilometers</h3>
            <ul>
                @foreach ($vehicule->kilometers->sortByDesc('created_at') as $kilometer)
                    <li>
                        {{ $kilometer->kilometer }} km ({{ $kilometer->created_at->format('d-m-Y') }})
                        <form action="{{ route('kilometers.destroy', $kilometer->id) }}" method="POST" class="delete-kilometer-form d-inline">
                            @csrf
                            @method('DELETE')
                            <button type="submit" class="btn btn-danger btn-sm">Delete</button>
                        </form>
                    </li>
                @endforeach
            </ul>
            <a href="{{ route('vehicules.index') }}" class="btn btn-primary">Back to List</a>
        </div>

        <!-- List of Mission Tab -->
        <div class="tab-pane fade" id="missions" role="tabpanel">
            <form id="vehicleSelectForm" action="" method="GET">
                <div class="form-group">
                    <label for="start_date">Start Date:</label>
                    <input type="date" class="form-control" id="start_date" name="start_date" value="{{ request('start_date') }}">
                </div>
                <div class="form-group">
                    <label for="end_date">End Date:</label>
                    <input type="date" class="form-control" id="end_date" name="end_date" value="{{ request('end_date') }}">
                </div>
                <button type="submit" class="btn btn-primary">Search</button>
            </form>
            <br>
            <table class="table">
                <thead>
                    <tr>
                        <th>Dosya</th>
                        <th>Transfer</th>
                        <th>Start</th>
                        <th>End</th>
                        <th>Driver</th>
                    </tr>
                </thead>
                <tbody>
                    @foreach($transfers as $transfer)
                        <tr>
                            <td><a href="{{ route('posts.show', $transfer->post->id) }}">{{ $transfer->post->id }}</a></td>
                            <td><a href="{{ route('transfers.show', $transfer->id) }}">{{ $transfer->id }}</a></td>
                            <td>{{ $transfer->start_date }}</td>
                            <td>{{ $transfer->end_date }}</td>
                            <td>{{ $transfer->driver->name }}</td>
                        </tr>
                    @endforeach
                </tbody>
            </table>
        </div>

        <!-- Maintenance Tab -->
        <div class="tab-pane fade" id="maintenance" role="tabpanel">
            <h4>Maintenance Section</h4>
            @if ($vehicule->maintenances->count() > 0)
        <table class="table table-bordered mt-3">
            <thead>
                <tr>
                    <th>Date</th>
                    <th>Amount (€)</th>
                    <th>Description</th>
                </tr>
            </thead>
            <tbody>
                @foreach ($vehicule->maintenances->sortByDesc('service_date') as $maintenance)
                    <tr>
                        <td>{{ \Carbon\Carbon::parse($maintenance->service_date)->format('d-m-Y') }}</td>
                        <td>{{ number_format($maintenance->amount, 2, ',', ' ') }} €</td>
                        <td>{!! nl2br(e($maintenance->description)) !!}</td>
                    </tr>
                @endforeach
            </tbody>
        </table>
    @else
        <p>No maintenance record found for this vehicule.</p>
    @endif
        </div>

    </div>
</div>
@endsection

@section('footer')
<script>
    function submitForm() {
        const selectElement = document.getElementById('vehicule_id');
        const selectedValue = selectElement.value;
        if (selectedValue) {
            window.location.href = `/vehicules/${selectedValue}`;
        }
    }

    document.addEventListener('DOMContentLoaded', function() {
        document.getElementById('vehicule_id').addEventListener('change', submitForm);

        const deleteForms = document.querySelectorAll('.delete-kilometer-form');
        deleteForms.forEach(function(form) {
            form.addEventListener('submit', function(event) {
                event.preventDefault();
                if (confirm('Are you sure you want to delete this kilometer entry?')) {
                    form.submit();
                }
            });
        });
    });
</script>
@endsection
