@extends('layouts.app')

@section('content')

<div class="row">
    <div class="col-lg-12 grid-margin stretch-card">
        <div class="card">
            <div class="card-body">
                <h3 class="card-title">Vehicule</h3>
                <button id="filterSalesButton" class="btn btn-secondary mb-3">Hide Sales Vehicles</button>
                <input type="text" id="searchInput" class="form-control mb-3" placeholder="Search Vehicule Name">

                <div class="table-responsive">    
                    <table class="table table-striped">
                        <thead>
                            <tr>
                                <th scope="col">Name</th>
                                <th scope="col">Plaka</th>
                                <th scope="col">Model</th>
                                <th scope="col">Capacity</th>
                                <th scope="col">Control technique</th>
                                <th scope="col">Assurance</th>
                                <th scope="col">Sales/Reel</th>
                                <th scope="col">En panne</th>
                                <th scope="col">Hermes id</th>
                                <th>#</th>
                                <th>#</th>
                            </tr>
                        </thead>
                        <tbody>
                            @foreach ($vehicules as $vehicule)
                            <tr class="vehicule-row" data-sales="{{ $vehicule->sales ? 'yes' : 'no' }}">
                                <td><a href="{{ route('vehicules.show', $vehicule->id) }}">{{ $vehicule->name }}</a></td>
                                <td>{{ $vehicule->plaka }}</td>
                                <td>{{ $vehicule->yil }}</td>
                                <td>{{ $vehicule->capacity }}</td>
                                <td>@if ($vehicule->real) {{ date('d-m-Y', strtotime($vehicule->control)) }} @endif</td>
                                <td>@if ($vehicule->real) {{ date('d-m-Y', strtotime($vehicule->sigorta)) }}@endif</td>
                                <td>{{ $vehicule->sales ? 'Yes' : 'No' }}/{{ $vehicule->real ? 'Yes' : 'No' }}</td>
                                <td>
                                    @if ($vehicule->enpanne)
                                        <span class="badge badge-danger">En panne</span>
                                    @else   
                                        <span class="badge badge-success">Non</span>
                                    @endif
                                </td>
                                <td>
                                
                                     
                                    {{ $vehicule->hermes_uid}}</li>
                                  
                                  
                                </td>
                                <td>
                                    <button 
                                        type="button" 
                                        class="btn btn-primary" 
                                        data-toggle="modal"
                                        data-id="{{ $vehicule->id }}"
                                        data-plaka="{{ $vehicule->plaka }}"
                                        data-yil="{{ $vehicule->yil }}"
                                        data-name="{{ $vehicule->name }}"
                                        data-hermes="{{ $vehicule->hermes_uid }}"
                                        data-capacity="{{ $vehicule->capacity }}"
                                        data-enpanne="{{ $vehicule->enpanne }}"
                                        data-control="{{ date('d-m-Y', strtotime($vehicule->control)) }}"
                                        data-sigorta="{{ date('d-m-Y', strtotime($vehicule->sigorta)) }}"
                                        data-sales="{{ $vehicule->sales }}"
                                        data-real="{{ $vehicule->real }}"
                                        data-target="#editModal">
                                        Edit 
                                    </button>
                                </td>
                                <td>
                                    <form class="deleteinvoice" action="{{ route('vehicules.destroy', $vehicule->id) }}" method="POST">
                                        {{ method_field('DELETE') }}
                                        {{ csrf_field() }}
                                        <button class="btn btn-danger"><i class="fas fa-trash"></i></button>
                                    </form>
                                </td> 
                            </tr>
                            @endforeach
                        </tbody>
                    </table>
                    <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#exampleModalLong">
                        Add New Vehicule
                    </button>
                    <a href="{{ route('vehicle_maintenance.index') }}" class="btn btn-secondary mb-3">Maintenance Record</a>
                </div>
            </div>
        </div>
    </div> 
</div>

<!-- Modal for adding new vehicle -->
<div class="modal fade" id="exampleModalLong" tabindex="-1" role="dialog" aria-labelledby="exampleModalLongTitle" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLongTitle">New Vehicule</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            {{ Form::open(array('route' => 'vehicules.store')) }}
            <div class="modal-body">
                {{ Form::label('name', 'Name', array('for' => 'validationDefault01')) }}
                {{ Form::text('name', null, array('class' => 'form-control', 'required' => 'required', 'placeholder' => 'Name')) }}
                {{ Form::label('plaka', 'Plaka', array('for' => 'validationDefault00')) }}
                {{ Form::text('plaka', null, array('class' => 'form-control', 'placeholder' => 'immatriculaiton')) }}
                {{ Form::label('yil', 'Model', array('for' => 'validationDefault00')) }}
                {{ Form::text('yil', null, array('class' => 'form-control', 'placeholder' => 'model yil')) }}
                {{ Form::label('capacity', 'Capacity', array('for' => 'validationDefault00')) }}
                {{ Form::selectRange('capacity', 1, 60, '', array('class' => 'form-control')) }}
                {{ Form::label('sigorta', 'sigorta', array('for' => 'validationDefault00')) }}
                {{ Form::date('sigorta', null, array('class' => 'form-control')) }}
                {{ Form::label('control', 'control', array('for' => 'validationDefault00')) }}
                {{ Form::date('control', null, array('class' => 'form-control')) }}
                {{Form::label('hermes_uid', 'Hermes ID', array('for' => 'validationDefault00')) }}
                {{ Form::text('hermes_uid', null, array('class' => 'form-control', 'placeholder' => 'Hermes ID')) }}
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                {{ Form::submit('Add Vehicule', array('class' => 'btn btn-primary')) }}
            </div>
            {{ Form::close() }}
        </div>
    </div>
</div>

<!-- Modal for editing vehicle -->
<div class="modal fade" id="editModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Edit Vehicule</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            {{ Form::open(array('route' => 'vehicule.guncel', 'class' => 'form', 'name' => 'edit')) }}
            <div class="modal-body">
                <div class="form-group">
                    <label for="recipient-name" class="col-form-label">Name:</label>
                    {{ Form::text('name', '', ['id' => 'data-name', 'class' => 'form-control']) }}
                    {{ Form::hidden('id', '', ['id' => 'data-id', 'class' => 'form-control']) }}
                    {{ Form::label('plaka', 'Plaka', array('for' => 'recipient-plaka')) }}
                    {{ Form::text('plaka', '', array('class' => 'form-control', 'id' => 'data-plaka')) }}
                    {{ Form::label('yil', 'Model', array('for' => 'recipient-yil')) }}
                    {{ Form::text('yil', '', array('class' => 'form-control', 'id' => 'data-yil')) }}
                    {{ Form::label('capacity', 'Capacity', array('for' => 'recipient-capacity')) }}
                    {{ Form::selectRange('capacity', 1, 60, '', array('class' => 'form-control', 'id' => 'data-capacity')) }}
                    {{ Form::label('sigorta', 'sigorta', array('for' => 'validationDefault00')) }}
                    {{ Form::date('sigorta', '', array('class' => 'form-control', 'id' => 'data-sigorta')) }}
                    {{ Form::label('control', 'control', array('for' => 'validationDefault00')) }}
                    {{ Form::date('control', '', array('class' => 'form-control', 'id' => 'data-control')) }}
                    {{ Form::label('hermes_uid', 'Hermes ID', array('for' => 'validationDefault00')) }}
                    {{ Form::text('hermes_uid', '', array('class' => 'form-control', 'id' => 'data-hermes')) }}
                      <!-- Add sales field as a checkbox -->
                      <div class="form-check">
                        {{ Form::checkbox('real', '1', false, array('class' => 'form-check-input', 'id' => 'data-real')) }}
                        {{ Form::label('real', 'real', array('class' => 'form-check-label', 'for' => 'data-real')) }}
                    </div>
                      <div class="form-check">
                        {{ Form::checkbox('sales', '1', false, array('class' => 'form-check-input', 'id' => 'data-sales')) }}
                        {{ Form::label('sales', 'Sales', array('class' => 'form-check-label', 'for' => 'data-sales')) }}
                    </div>
                    <div class="form-check">
                        {{ Form::checkbox('enpanne', '1', false, array('class' => 'form-check-input', 'id' => 'data-enpanne')) }}
                        {{ Form::label('enpanne', 'En panne', array('class' => 'form-check-label', 'for' => 'data-enpanne')) }}

                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                {{ Form::submit('Edit Vehicule', array('class' => 'btn btn-primary')) }}
            </div>
            {{ Form::close() }}
        </div>
    </div>
</div>

@endsection

@section('footer')
<script>
    $('#editModal').on('show.bs.modal', function (event) {
        var button = $(event.relatedTarget) // Button that triggered the modal
        var recipient = button.data('id') // Extract info from data-* attributes
        var recipmname = button.data('name')
        var recipcapacity = button.data('capacity')
        var recipyil = button.data('yil')
        var recipplaka = button.data('plaka')
        var recipsigorta = button.data('sigorta')
        var recipcontrol = button.data('control')
        var reciphermes = button.data('hermes')
        var recipsales = button.data('sales')
        var recipenpanne = button.data('enpanne')
        var recipreal = button.data('real')
        var parts = recipcontrol.split('-');
        var formattedDate = parts[2] + '-' + parts[1] + '-' + parts[0]; //
        var pasigorta = recipsigorta.split('-');
        var formattedDatesig = pasigorta[2] + '-' + pasigorta[1] + '-' + pasigorta[0]; //
        
        var modal = $(this)
        modal.find('.modal-title').text('Edit ' + recipmname)
        modal.find('.modal-body #data-id').val(recipient)
        modal.find('.modal-body #data-name').val(recipmname)
        modal.find('.modal-body #data-capacity').val(recipcapacity)
        modal.find('.modal-body #data-plaka').val(recipplaka)
        modal.find('.modal-body #data-yil').val(recipyil)
        modal.find('.modal-body #data-hermes').val(reciphermes)
        modal.find('.modal-body #data-sigorta').val(recipsigorta)
        modal.find('.modal-body #data-sigorta').val(formattedDatesig)
        modal.find('.modal-body #data-control').val(formattedDate)
        modal.find('.modal-body #data-sales').prop('checked', recipsales)
        modal.find('.modal-body #data-real').prop('checked', recipreal)
        modal.find('.modal-body #data-enpanne').prop('checked', recipenpanne)
        
    });

    document.getElementById('filterSalesButton').addEventListener('click', function() {
        var rows = document.querySelectorAll('.vehicule-row');
        rows.forEach(function(row) {
            if (row.dataset.sales === 'yes') {
                row.style.display = (row.style.display === 'none') ? '' : 'none';
            }
        });
    });

    document.getElementById('searchInput').addEventListener('keyup', function() {
    var input = this.value.toLowerCase();
    var rows = document.querySelectorAll('.vehicule-row');

    rows.forEach(function(row) {
        var name = row.querySelector('td a').textContent.toLowerCase();
        if (name.includes(input)) {
            row.style.display = '';
        } else {
            row.style.display = 'none';
        }
    });
});

</script>
@endsection
