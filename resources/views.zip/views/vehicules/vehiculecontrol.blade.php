@extends('layouts.app')



    <style>
        table {
            width: 100%;
            border-collapse: collapse;
        }
        table, th, td {
            border: 1px solid black;
        }
        th, td {
            padding: 5px;
            text-align: center;
        }
        .in-use {
            background-color: red;
            color: white;
        }
    </style>

    @section('content')
<div class="container">
    <h1 class="mt-4">Vehicle Usage Timeline for {{ $date->format('F j, Y') }}</h1>
    
    <div class="mb-3">
        <form method="POST" action="{{ route('vehiculescontrolviewByDate') }}">
            @csrf
            <div class="form-group">
                <label for="date">Select Date:</label>
                <input type="date" id="date" name="date" class="form-control" value="{{ $date->format('Y-m-d') }}" required>
            </div>
            <button type="submit" class="btn btn-primary">View Vehicle Usage</button>
        </form>
    </div>

    <div class="mb-3">
        <a href="{{ route('vehiculescontrolviewBySpecificDate', ['date' => $date->copy()->subDay()->format('Y-m-d')]) }}" class="btn btn-secondary">Day Before</a>
        <a class="btn btn-primary" href="{{route('vehiculescontrol')}}">Today</a>
        <a href="{{ route('vehiculescontrolviewBySpecificDate', ['date' => $date->copy()->addDay()->format('Y-m-d')]) }}" class="btn btn-secondary">Day After</a>
      
        <a class="btn btn-danger" href="{{route('driverUsage.index')}}">Driver Usage</a>
        <a href="{{ route('day') }}" class="btn btn-warning"> Shuttle</a>
    </div>

    <table class="table table-bordered">
        <thead class="thead-dark">
            <tr>
                <th>Vehicle</th>
                <th>Start Time</th>
                <th>End Time</th>
            </tr>
        </thead>
        <tbody>
            @foreach($vehicles as $vehicle_name => $transfers)
                @foreach($transfers as $index => $transfer)
                    <tr>
                        @if ($index === 0)
                            <td rowspan="{{ $transfers->count() }}">
                            <a href="{{ route('vehicules.show',$transfer->vehicule_id) }}">    
                            
                            {{ $vehicle_name }}</td>
                        @endif
                        <td>{{ \Carbon\Carbon::parse($transfer->start_date)->format('H:i') }}</td>
                        <td>{{ \Carbon\Carbon::parse($transfer->end_date)->format('H:i') }}</td>
                    </tr>
                @endforeach
            @endforeach
        </tbody>
    </table>
    @if($unusedVehiclesWithLastUsage->isNotEmpty())
    <h2>Vehicles Not Used</h2>
    <ul>
        @foreach($unusedVehiclesWithLastUsage as $vehicleName => $lastUsedDate)
            <li>
                {{ $vehicleName }} 
                @if ($lastUsedDate)
                 <small class="text-primary">  - Last Used: {{ \Carbon\Carbon::parse($lastUsedDate)->format('j F , Y H:i') }}</small> 
                <span class="text-danger"> ({{ \Carbon\Carbon::parse($lastUsedDate)->diffInDays(\Carbon\Carbon::today()) }} days ago)</span>
                @else
                <span class="text-danger">  - Never Used</span>
                @endif
            </li>
        @endforeach
    </ul>
@endif
</div>

@endsection