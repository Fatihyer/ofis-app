<!DOCTYPE html>
<html>
<head>
    <title>Mission Roadmap</title>
    <style>
        body {
            font-family: 'Calibri', sans-serif;
            font-size: 12px;
        }
        h4 {
            font-size: 12px;
            text-align: center; /* Center-align the h4 text */
        }
        table {
            width: 100%;
            border-collapse: collapse;
        }
        .border1 {
            border: 1px solid black;
        }
        th, td {
           
            text-align: left;
       
        }
        .header-table td {
            border: none;
            vertical-align: top;
        }
        .header-table img {
            max-width: 150px;
            height: auto;
        }
        hr {
            margin: 10px 0;
        }
        .nested-table {
            width: 100%;
           border: none;
           
        }
        .nested-table th, .nested-table td {
           
            text-align: left;
          
        }
    </style>
</head>
<body>
    <table class="header-table">
        <tr>
            <td>
                <p><strong>Paris Via SARL</strong></p>
                <p>3 Rue de la Butte<br>
                   93700 Drancy<br>
                   SIRET: 750 473 902 00021<br>
                   TVA: FR17 750 473 902<br>
                   Tlf: +33(0) 6 46 43 01 48
                </p>
            </td>
            <td style="text-align: right;">
                <img src="{{ asset('images/'.$sirket->logo) }}" alt="Company Logo"/>
            </td>
        </tr>
    </table>  
    <hr>
    <h4>
        SERVICE OCCASIONNEL COLLECTIF DE TRANSPORT PUBLIC ROUTIER DE VOYAGEURS <br>
        <small>BILLET COLLECTIF valant ORDRE DE MISSION : Arrêté ministériel du 28/12/2011 (Art. 1-2)</small>
    </h4>
    <hr>
    <table>
        <tr>
            <td style="width: 50%; border-right: 1px solid black; padding-right: 10px;vertical-align: top;">
                <h3>N° BILLET: {{ $transfer->id }}</h3>
              
                @if (date('d/m/Y', strtotime($transfer->start_date)) == date('d/m/Y', strtotime($transfer->end_date)))
              Date:   {{ date('d/m/Y', strtotime($transfer->end_date)) }}
               @else
               Du: {{ date('d/m/Y', strtotime($transfer->start_date)) }} au  {{ date('d/m/Y', strtotime($transfer->end_date)) }}
                @endif
                <br>
                <strong>Rdv depot   {{ date('H:i', strtotime($transfer->ofis_start))}}</strong>
                <table class="nested-table">

                    <tr>
                        <th style="font-size: 12px; padding: 4px; width: 30%;">Début</th>
                        <th style="font-size: 12px; padding: 4px; width: 30%;">Fin Prévue</th>
                        <th style="font-size: 12px; padding: 4px; width: 30%;">Fin Réelle</th>
                    </tr>
                    <tr>
                        <td style="font-size: 12px; padding: 4px;">
                            <div style="border: 1px solid black; padding: 2px; display: inline-block; width: 100%; box-sizing: border-box;">
                                {{ date('H:i', strtotime($transfer->start_date) - $surplaceMinBefore->value * 60);}}
                            </div>
                        </td>
                        <td style="font-size: 12px; padding: 4px;">
                            <div style="border: 1px solid black; padding: 2px; display: inline-block; width: 100%; box-sizing: border-box;">
                                {{ date('H:i', strtotime($transfer->end_date)) }}
                            </div>
                        </td>
                        <td style="font-size: 12px; padding: 4px;">
                            <div style="border: 1px solid black; padding: 2px; display: inline-block; width: 100%; box-sizing: border-box;">
                                @if (isset($transfer->missionr->finish))
                                    {{ date('H:i', strtotime($transfer->missionr->finish)) }}
                                @else
                                    &nbsp;
                                @endif
                            </div>
                        </td>
                    </tr>
                </table>
                
            </td>

            <td style="width: 50%;">
                
                VEHICULE: {{ $transfer->vehicule->name }} <br>
                CHAUFFEUR: <strong>{{ $transfer->driver->tittle }}</strong><br>
                TELEPHONE: {{ $transfer->driver->tel }}<br>
                Transport : du {{ date('d/m/Y', strtotime($transfer->start_date)) }} au {{ date('d/m/Y', strtotime($transfer->end_date)) }}
                <br>
                Convoc: <strong> {{ date('d/m/Y H:i', strtotime($transfer->ofis_start)) }} </strong> <br>

                <table class="nested-table">
                   
                    <tr>
                        <td style="font-size: 12px; padding: 4px;">
                            Parking:
                            <div style="border: 1px solid black; padding: 2px; display: inline-block; width: 100%; box-sizing: border-box;">
                                &nbsp;
                            </div>
                        </td>
                        <td style="font-size: 12px; padding: 4px;">
                            Repas:
                            <div style="border: 1px solid black; padding: 2px; display: inline-block; width: 100%; box-sizing: border-box;">
                                &nbsp;
                            </div>
                        </td>
                       
                    </tr>
                    <tr>
                        <td style="font-size: 12px; padding: 4px;">
                           Autres:
                            <div style="border: 1px solid black; padding: 2px; display: inline-block; width: 100%; box-sizing: border-box;">
                                &nbsp;
                            </div>
                        </td>
                        <td style="font-size: 12px; padding: 4px;">
                           Peage:
                            <div style="border: 1px solid black; padding: 2px; display: inline-block; width: 100%; box-sizing: border-box;">
                                &nbsp;
                            </div>
                        </td>
                       
                    </tr>
                </table>
            </td>    
        </tr>
    </table>          
   <hr>
    <table>
        <tr> <th colspan="2"> <h2>Itinéraire / Service</h2>
            Motif du déplacement : Occasionnel</th></tr>
        <tr>
            <td style="width: 50%; border-right: 1px solid black; padding-right: 10px;vertical-align: top;">

    <p> Depart a   {{ date('H:i', strtotime($transfer->start_date)) }} de  {{ $transfer->from }}</p>
    <p>Destination:  {{ $transfer->target }}</p>
    @foreach ($transfer->trajets as $index => $trajet)
                                  <li class="list-group-item"> 
                                    
                                    @if (date("Y-m-d") == date('Y-m-d', strtotime($trajet->datetime)))
    {{ date('H:i', strtotime($trajet->datetime)) }}
@else
    {{ date('d/m/Y H:i', strtotime($trajet->datetime)) }}
@endif
                                            {{$trajet->type}}:
                                            {{$trajet->from}}
                                            {{$trajet->google_address}}
                                            
                                  </li> 
                                    @endforeach
    </ul>
            </td>
            <td> 
    <p>
    @foreach($transfer->post->client as $clients) 
           {{$clients->name." ".$clients->surname." ".$clients->tel}}</p>
          @endforeach
        @if (strlen($transfer->comments) > 120)
        {!! nl2br(e(substr($transfer->comments, 0, 120))) !!}... <br>
        <small style="color: red;">voir page 2</small>
    @else
        {!! nl2br(e($transfer->comments)) !!}
    @endif
</p>
</td>
        </tr>
    
    </table>
    <hr>
<table>
<tr>
<td width="50%">
        <table  class="header-table" border="1" >
            <thead>
                <tr>
                    <th  width="30%">
                    Kilometrage    
                    </th>    
                    <th  width="40%">
                    Garage
                    </th  width="40%">    
                    <th>
                    Client
                    </th>    
                </tr>    
            
           
                <tr>
                    <th>
                        Arrivee
                    </th>
                    <th>
                        &nbsp;
                    </th>
                    <th>
                        &nbsp;
                    </th>

                </tr>
                <tr>
                    <th>
                       Depart
                    </th>
                    
                    <th>
                        &nbsp;
                    </th>
                    <th>
                        &nbsp; 
                    </th>

                </tr>
                <tr border='2'>
                    <th>
                      SORTIE FRANCE
                    </th>
                    
                    <th>
                      
                    </th>
                    <th>
                        &nbsp; 
                    </th>

                </tr>
                <tr border='2'>
                    <th>
                       <small> ENTREE FRANCE  </small>
                    </th>
                    
                    <th>
                        <small>  </small>
                    </th>
                    <th>
                        &nbsp; 
                    </th>

                </tr>
            </thead>
        </table>    

</td>    
<td width="50%">
    Personne, Etablissement, Association ou Groupement pour le compte duquel le transport est exécuté : <br>
    NOM: <strong>{{ $transfer->post->acente->tittle }}</strong><br>
    ADR: {{ $transfer->post->acente->address }} {{ $transfer->post->acente->city }}<br>
    TEL:   {{ $transfer->post->acente->tel }} <br>
    <table>
        <tr>
    <td style="font-size: 12px; padding: 4px;">
        Passagers prévus:
         <div style="border: 1px solid black; padding: 2px; display: inline-block; width: 100%; box-sizing: border-box;">
            {{ $transfer->pax }} 
         </div>
     </td>
     <td style="font-size: 12px; padding: 4px;">
        Passagers réels:
         <div style="border: 1px solid black; padding: 2px; display: inline-block; width: 100%; box-sizing: border-box;">
             &nbsp;
         </div>
     </td>
    </tr>
    </table>
</td>

</tr>    
</table>  
<hr>
<table>
    <thead>
        <tr>
        <th>
             Heure Fin de Service:_____    

        </th>
        <th>
            Heure Fin de Garage:_____    

       </th> <th>
       Temps Suppl:_____    

   </th>
   <th>
    Signature: 
    <br>
    <br>
   </th>

    </tr>
    </thead>


</table>

<small>
    Prix du transport selon facture (Dossier n° {{$transfer->post_id}}). Les horaires mentionnes ci dessous sont donnes a titre indicatif et en toute circonstance
    le conducteur de l'autocar devra respecter le code de la route et la rÈglementation du temps de travail. LA DIRECTION/


</small>

@if (strlen($transfer->comments) > 120)
<h3>
Mission Detaillee



</h3>
<p>
    {!! nl2br(e($transfer->comments)) !!}

</p>
@endif
</body>
</html>
