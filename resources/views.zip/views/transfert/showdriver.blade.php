@extends('layouts.kaptan')

@section('title', '| View Post')

@section('content')


    <div class="card border-{{(isset($transfers->status->color->name)?$transfers->status->color->name:"")}} text-center">
  <div class="card-header"><a class="btn btn-success" href="{{ url()->previous() }}">back<i class="fa fa-arrow-circle-left"></i>
</a>
 
                  
  </div>
  <div class="card-body">
    <h5 class="card-title">{{$transfers->servicetype->name}}</h5>
    <h2> {{date('d-m-Y ', strtotime($transfers->start_date))}}</h2>
    @if($transfers->servicetype->hizmet)
    to
    <h4> {{date('d-m-Y D H:i', strtotime($transfers->end_date))}}</h4>
    @endif
    <H5 >Driver:{{(isset($transfers->driver->name)?$transfers->driver->name:'NO DRIVER')}}</H5>
    
    Transfer: {{$transfers->status->name}}
          @if(($transfers->status_id==2) || ($transfers->status_id==4) )
           {{ Form::model($transfers, array('route' => array('transfers.update', $transfers->id), 'method' => 'PUT')) }}
              {{Form::hidden('dcomments',$transfers->dcomments)}}
              {{Form::hidden('status_id',3)}}
           <button class="btn btn-primary">
          Confirm
        </button>
          {{Form::close()}}
          @endif
        
 
     <span class="result"></span>
  </div>
      
      
      
  <div class="card-footer text-muted">
    <?php $datestart = \Carbon\Carbon::parse($transfers->start_date);
          $dateend = \Carbon\Carbon::parse($transfers->end_date);
          $totalDuration = $dateend->diffInHours($datestart);
         echo  $totalDuration, ' Heure';
    ?>
  </div>
</div>
<div class="container">
  <div class="card border-{{(isset($transfers->status->color->name)?$transfers->status->color->name:"")}}">
    <h4 class="card-header">PRISE DE SERVICE</h4>
    <div class="card-body">
  
     
    </div>
  </div>
</div>


  <div class="container">
    <div class="card border-{{(isset($transfers->status->color->name)?$transfers->status->color->name:"")}}">
      <h4 class="card-header">SUR PLACE </h4>
      <div class="card-body">
      <strong>  {{ date('H:i', strtotime($transfers->start_date . ' -15 minutes')) }} </strong>
            
      </div>
    </div>
  </div>  
    <div class="container">
      <div class="card border-{{(isset($transfers->status->color->name)?$transfers->status->color->name:"")}}">
        <h4 class="card-header">PRISE EN CHARGE</h4>
        <div class="card-body">
          {{ date('H:i', strtotime($transfers->start_date )) }}
              
        </div>
      </div>   
    </div>  
      <div class="container">
        <div class="card border-{{(isset($transfers->status->color->name)?$transfers->status->color->name:"")}}">
          <h4 class="card-header">FIN DE SERVICE PREVU </h4>
          <div class="card-body">
            {{ date('H:i', strtotime($transfers->end_date )) }}
                
          </div>
        </div>  
      </div>  
        <div class="container">
          <div class="card border-{{(isset($transfers->status->color->name)?$transfers->status->color->name:"")}}">
            <h5 class="card-header">Nombre de  Pax Prevu </h5>
            <div class="card-body">
              <p class="card-text">Pax: {{$transfers->pax}}.</p>
                  
            </div>
          </div> 

    <div class="row">
  <div class="col-sm-12">
    <div class="card border-{{(isset($transfers->status->color->name)?$transfers->status->color->name:"")}}">
      <div class="card-body">
        <h5 class="card-title">From ->To</h5>
        <p class="card-text"> {{$transfers->from}} -> {{$transfers->target}}</p>
        @if ($transfers->trajets->count() == 0)
                                    <span class="text-danger"> !!!!!!bunlar eski yeniden bilgiler  girin</span><br>
                                    @else
                                    <ul class="list-group">                                    @foreach ($transfers->trajets as $index => $trajet)
                                  <li class="list-group-item"> 
                                    <span class="badge badge-primary badge-pill">{{$index+1 }}</span>
                                    {{$trajet->datetime->format('d-m-Y H:i') }}
                                            {{$trajet->type}}:
                                            {{$trajet->from}}
                                            {{$trajet->google_address}}
                                         
                                  </li> 
                                    @endforeach
                                </ul>

                                        @endif
      
      </div>
    </div>
  </div>


 <s></s>
</div>
  
  
  <div class="row">
  <div class="col-sm-6">
    <div class="card border-{{(isset($transfers->status->color->name)?$transfers->status->color->name:"")}}">
      <div class="card-body">
        <h5 class="card-title">Clients</h5>
        <p class="card-text">Pax: {{$transfers->pax}}.</p>
         <p class="card-text">Names: 
           <?php $misafir=false;?>
           @foreach($transfers->post->client as $clients) 
           {{$misafir =$clients->name." ".$clients->surname." ".$clients->tel}}</p>
          @endforeach
      
      </div>
    </div>
  </div>
  <div class="col-sm-6">
    <div class="card border-{{(isset($transfers->status->color->name)?$transfers->status->color->name:"")}}">
      <div class="card-body">
        <h5 class="card-title">Vehicule</h5>
        <p class="card-text">Vehicule:{{$transfers->vehicule->name}}
         </p>
         @hasanyrole('Admin|ofis')   
        <p class="text-danger"><strong>Payment:</strong> {{(isset($transfers->harekets[0]->payment->name)?$transfers->harekets[0]->payment->name:"")}}
      <strong> {{(isset($transfers->harekets[0]->offset_id))&&$transfers->harekets[0]->offset_id>0?abs(($transfers->harekets[0]->offset->harekets[0]->amount)).$transfers->harekets[0]->offset->harekets[0]->kur->name:""}}
     </strong>   </p>
     @endhasanyrole
      </div>
    </div>
  </div>
</div>

  <div class="card border-danger">
    <h5 class="card-header">Mission</h5>
    <div class="card-body">
      <p class="card-text">
        @if ($transfers->mission==true)
                    <a href='{{route('mission',$transfers->id)}}'><button class="btn btn-danger">Start Mission</button></a>
                    @endif


        @if (isset($transfers->missionr->hareket))
       <em> Prise de Service </em> <strong><span id="hareket_time">{{ date('H:i', strtotime($transfers->missionr->hareket)) }}</span></strong>,
        <em> Sur Place </em> <strong><span id="surplace_time">{{ date('H:i', strtotime($transfers->missionr->surplace)) }}</span></strong>,
          <em> Prise en charge </em><strong> <span id="taked_time">{{ date('H:i', strtotime($transfers->missionr->taked)) }}</span></strong>,
            <em>  Fin de Mission </em><strong> <span id="finish_time">{{ date('H:i', strtotime($transfers->missionr->finish)) }}</span></strong>
        <br>
        <form id="time_form" method="POST" action="{{ route('update_times') }}">
          @csrf <!-- Add CSRF token for security -->
          @if ($transfers->missionr->hareket)
          <div class="form-group">
              <label for="new_hareket"> PRISE DE SERVİCE REEL:</label>
              <input type="datetime-local" class="form-control" id="new_hareket" name="new_hareket" value="{{ date('Y-m-d\TH:i', strtotime($transfers->missionr->hareket)) }}">
          </div>
          @endif
          @if ($transfers->missionr->surplace)
          <div class="form-group">
              <label for="new_surplace">SUR PLACE REEL:</label>
              <input type="datetime-local" class="form-control" id="new_surplace" name="new_surplace" value="{{ date('Y-m-d\TH:i', strtotime($transfers->missionr->surplace)) }}">
          </div>
          @endif
          @if ($transfers->missionr->taked)
          <div class="form-group">
              <label for="new_taked">PRISE EN CHARGE REEL:</label>
              <input type="datetime-local" class="form-control" id="new_taked" name="new_taked" value="{{ date('Y-m-d\TH:i', strtotime($transfers->missionr->taked)) }}">
          </div>
          @endif
          @if ($transfers->missionr->finish)
          <div class="form-group">
              <label for="new_finish">FIN DE MISSION REEL:</label>
              <input type="datetime-local" class="form-control" id="new_finish" name="new_finish" value="{{ date('Y-m-d\TH:i', strtotime($transfers->missionr->finish)) }}">
          </div>
          @endif
          <input type="hidden" name="transfers_id" value="{{ $transfers->id }}">
          <button type="submit" class="btn btn-primary">Update Times</button> <!-- Change button type to submit -->
      </form>
        @else
        No mission assigned
        @endif

      </p>
    </div>
  </div> 
  
  <div class="card border-{{(isset($transfers->status->color->name)?$transfers->status->color->name:"")}}">
  <h5 class="card-header">Details</h5>
  <div class="card-body">
   
    <p class="card-text">{{$transfers->comments}}</p>
<button onclick="yazdir()" class="btn btn-primary"><i class="fa fa-print" aria-hidden="true"></i></button>
  <?php
  if ($transfers->ofis_start==null)
{
  $ofis=date('Y-m-d H:i:s', strtotime($transfers->start_date . ' -1 hour'));
}
else {
  $ofis=$transfers->ofis_start;
}
 ?>
  
 <?php
 $whatsappText = '';
 if (isset($transfers->status->id) && $transfers->status->id > 1) {
     $whatsappText = '<<SERVICE DE TRANSPORT PUBLIC DE PERSONNES - BILLET COLLECTIF>>' . PHP_EOL . '(Arrêté du 14 février 1986 – Article.5) et ordre de mission (Arrêté du 6 janvier 1993 – Article 3)' . PHP_EOL . PHP_EOL . 'Date: ' . date('d-m-Y D', strtotime($transfers->start_date)) . PHP_EOL . '*En Route:' . date('H:i', strtotime($ofis)) . '*' . PHP_EOL . '*Heure prise en charge:' . date('H:i', strtotime($transfers->start_date)) . '*' . PHP_EOL . 'Heure de dépose:' . date('H:i', strtotime($transfers->end_date)) . PHP_EOL . 'Service:' . $transfers->servicetype->name . PHP_EOL . 'Passagers:' . $transfers->pax . ' pax' . PHP_EOL . '*Lieu de Prise en Charge: ' . $transfers->from . '*' . PHP_EOL . 'Lieux de depose: ' . $transfers->target . PHP_EOL . 'Vehicule: ' . $transfers->vehicule->name . PHP_EOL . 'Chauffeur: ' . $transfers->driver->name . PHP_EOL . 'Comments:' . $transfers->comments . PHP_EOL . 'Contact:' . PHP_EOL . $misafir;
 } else {
     $whatsappText = $transfers->servicetype->name . '!!!!!!CANCELED!!!!!!!' . PHP_EOL . '*Date:* ' . date('d-m-Y D H:i', strtotime($transfers->start_date)) . PHP_EOL . '*From*: ' . $transfers->from . PHP_EOL . '*Comments*' . $transfers->comments;
 }
 ?>

@if ((Auth::user()->hasPermissionTo('Administer roles & permissions')||(Auth::user()->hasPermissionTo('ofis'))||(Auth::user()->hasPermissionTo('transport'))))
  @if  ((isset($transfers->status->id))&&($transfers->status->id>1))  
       @if (isset($transfers->driver->whatsapp))
       <a  target="blank" href="{{$transfers->driver->whatsapp}}" class="btn btn-success"><i class="fab fa-whatsapp"></i>
    </a>
       @else 
  <a  target="blank" href="https://api.whatsapp.com/send?{{(isset($transfers->driver->tel)?'phone='.$transfers->driver->tel.'&':'')}}text={{rawurlencode($whatsappText)}}"
   class="btn btn-success"><i class="fab fa-whatsapp"></i>
    </a>
      @endif
    <a href='{{route('transfers.sms',$transfers->id)}}' class="btn btn-success">sms</a>
    <a href='{{route('transfershowpdf',$transfers->id)}}' class="btn btn-danger">PDF for Confirmation</a>
    <a href='{{route('transferMissionshowpdf',$transfers->id)}}' class="btn btn-danger">FDR PDF</a>
  @else  
    <a  target="blank" href="https://api.whatsapp.com/send?{{(isset($transfers->driver->tel)?'phone='.$transfers->driver->tel.'&':'')}}text={{rawurlencode($whatsappText)}}"
   class="btn btn-danger"><i class="fab fa-whatsapp"></i>
    </a>
 @endif
 <div class="container mt-5">
  <div class="form-group">
      <label for="textArea" class="text-white">WhatsApp Text:</label>
      <textarea id="textArea" class="form-control" rows="5">{{$whatsappText}}</textarea>
  </div>
  <button id="copyButton" class="btn btn-primary">Copy</button>
</div>
  </div>
</div>
@endif 
  
  <div class="card border-{{(isset($transfers->status->color->name)?$transfers->status->color->name:"")}}">
  <h5 class="card-header">Driver/Guide Comments</h5>
  <div class="card-body">
      {{ Form::model($transfers, array('route' => array('transfers.update', $transfers->id), 'method' => 'PUT')) }}
    {{Form::text('dcomments',$transfers->dcomments,array('class'=>'form-control'))}}     
       {{Form::hidden('status_id',$transfers->status_id)}}
    <button class="btn btn-primary">
      Save
    </button>
       {{Form::close()}}     
 
  </div>
</div>

 
<div class="card border-{{(isset($transfers->status->color->name)?$transfers->status->color->name:"")}}">
  <h5 class="card-header">Upload Voucher</h5>
  <div class="card-body">
    <form action="{{route('transfers.voucherupload')}}" method="POST" role="form"  enctype="multipart/form-data">
      @csrf
      <div class="custom-file">
        <input type="file" name="image" class="custom-file-input" id="customFile" >
        <input type="hidden" name="id" value="{{$transfers->id}}">
        <input type="hidden" name="post_id" value="{{$transfers->post_id}}">
        <label class="custom-file-label" for="customFile">Choose Image</label>
      </div>
      <button type="submit" class="btn btn-primary">
        Upload
      </button>
  </form>
  <p class="text-muted mt-3 mb-0">
   Vouchers:
      
       @foreach ($files as $file)
            <a href="/voucher/{{$transfers->id}}/{{basename($file)}}">{{basename($file)}}</a>,
         @endforeach
 </p>
 
 
  </div>
</div>
  
</div>
@endsection
@section('footer')
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
   
<script>
$('.transferupdate').on('submit',function(e){
    var form = $(this);
    var submit = form.find("[type=submit]");
    var submitOriginalText = submit.attr("value");
   $('.result').append( "<i class=\"icon-ok\"></i>" );
    e.preventDefault();
    var data = form.serialize();
    var url = form.attr('action');
    var post = form.attr('method');
    $.ajax({
        type : post,
        url : url,
        data :data,
        success:function(data){
           submit.attr("value", "Submitted");
          $('.result').append( "<i class=\"fa fa-check\" style=\"color:#008000;\"\></i>");

        },
        beforeSend: function(){
           submit.attr("value", "Loading...");
           submit.prop("disabled", true);
          
        },
        error: function() {
            submit.attr("value", submitOriginalText);
            submit.prop("disabled", false);
         // show error to end user
        }
    })
})



// voucher upload 
$(".custom-file-input").on("change", function() {
  var fileName = $(this).val().split("\\").pop();
  $(this).siblings(".custom-file-label").addClass("selected").html(fileName);
});

</script>

<script>
  document.addEventListener('DOMContentLoaded', function() {
      var updateTimesButton = document.getElementById('update_times');
      if (updateTimesButton) {
          updateTimesButton.addEventListener('click', function() {
              var formData = new FormData(document.getElementById('time_form'));

              // Send AJAX request
              fetch('/update_times', {
                  method: 'POST',
                  body: formData
              })
              .then(response => response.json())
              .then(data => {
                  // Update the displayed times on the page
                  document.getElementById('hareket_time').innerText = data.new_hareket;
                  document.getElementById('surplace_time').innerText = data.new_surplace;
                  document.getElementById('taked_time').innerText = data.new_taked;
                  document.getElementById('finish_time').innerText = data.new_finish;
              })
              .catch(error => console.error('Error:', error));
          });
      }

      var copyButton = document.getElementById('copyButton');
    if (copyButton) {
        copyButton.addEventListener('click', function() {
            var textArea = document.getElementById('textArea');
            textArea.select();
            document.execCommand('copy');
            copyButton.textContent = 'Copied';
        });
      }
  });
</script>  
@endsection
