
@extends('layouts.kaptan')
@section('content')
@if ($errors->any())
    <div class="alert alert-danger">
        <ul>
            @foreach ($errors->all() as $error)
                <li>{{ $error }}</li>
            @endforeach
        </ul>
    </div>
@endif
  <div class="container py-4">
    <div class="row justify-content-center">
      <div class="col-12">
     
        <p class="text-dark mt-0 mb-3">Bonjour {{ $transfer->driver->name }}.</p>
        <h2 class="text-uppercase my-0 text-primary font-weight-bold"></h2>
             <h3 class="mt-0 mb-3 text-dark font-weight-bold">
             {{ $transfer->servicetype->name }}:  {{ date('d-m Y H:i', strtotime($transfer->start_date)) }}
             </h3>
            {{ $transfer->vehicule->name }}
        
            <h5>
           {{ $transfer->pax }} personnes <br>
           @foreach($transfer->post->client as $clients) 
            {{$misafir =$clients->name." ".$clients->surname." ".$clients->tel}}<br/>
             @endforeach   </h5>
          {{ $transfer->comments }} <br/>
         
          
        @if ($mission)
            <span class="text-success">Départ du Depot a {{ date('H:i', strtotime($mission->hareket)) }}</span>
            <small>Kilometrage  {{$mission->depart_km}}</small>
        @else
        @if ($transfer->accueil) <h5><span class="text-danger">N'oublier pas de prendre le panneau d'accueil ou autre papier du bureau!!</span></h5> @endif
            <span>Heure Prévu du départ du depot {{ date('H:i', strtotime($transfer->ofis_start)) }}</span>
          
            <form action="{{ route('startmission', $transfer->id) }}" method="POST" class="d-block">
                 @csrf
                <div class="form-group">
                    <label for="kilometre">Entrez le Kilometre du vehicule:</label>
                    <input type="number" name="depart_km" id="kilometre" class="form-control" required>
                </div>
                <button type="submit" class="btn btn-danger btn-block"> @if ($transfer->accueil)J'ai pris le panneau d'acceuil @endif Commencer la Mission (Depart du Depot)</button>
       
        </form>
        @endif 
  
        @if ($mission)
           
            
            @if ($mission->hareket && !$mission->surplace)
            <br>
            <span class="text-danger">Sur Place Prevu a  {{ date(' H:i', strtotime($transfer->start_date . ' -15 minutes')) }}</span>
            <div class="mt-4">
              <h5 class="text-dark">Maintenant - Aller à la zone de départ: <strong>{{ $transfer->from }}</strong>
</h5>
              <a href="{{ route('onplacemission', $mission->id) }}" class="btn btn-danger btn-block">Sur Place</a>
              </div>

            @elseif ($mission->surplace && !$mission->taked)
              <br/>  
           <span class="text-warning"> Sur Place a  {{date('H:i', strtotime($mission->surplace))}}</span>
              <a href="{{ route('onboardmission', $mission->id) }}" class="btn btn-danger btn-block">Client embarqué?</a>
            @elseif ($mission->taked && !$mission->finish)

              <p class="text-success">Depart de  {{ $transfer->from }} a   {{date('H:i', strtotime($mission->taked))}}</p>
              <span class="text-danger" > Maintenant Suivre : </span><br/>
              
                @foreach ($transfer->trajets as $index => $trajet)
                   @if ($trajet->type!='depot' && $trajet->from!=$transfer->from)
                   -{{$trajet->from}}
                   {{$trajet->google_address}} 
                      </br>
                   @endif
                  
                 @endforeach
             
       

                <a href="{{ route('finishmission', $mission->id) }}" class="btn btn-success btn-block">Client Deposer a  {{ $transfer->target }}</a>
             </p>
            
            @elseif ($mission->finish && !$mission->finish_depot)
            <br>
                <span class="text-warning"> Sur Place a  {{date('H:i', strtotime($mission->surplace))}}</span><br>
              <p class="text-success">Client Deposé a  {{ date('H:i', strtotime($mission->finish)) }} </p>
              Maitenant retour au Depot
              <form onsubmit="return validateForm()" action="{{ route('finishmissiondepot', $mission->id) }}" method="POST" class="d-block">
        @csrf
                <div class="form-group">
                    <label for="kilometre">Une foi arrivé au depot, Entrez le Kilometre du vehicule:</label>
                    <input type="number" name="finish_km" id="kilometre" class="form-control" required>
                </div>
        <h4 >Statut de Nettoyage du Véhicule</h4>
                <div class="form-check form-check-inline">
                        <input class="form-check-input" type="radio" name="cleaningStatus" id="cleanedYes" value="yes">
                        <label class="form-check-label" for="cleanedYes">Oui</label>
                    </div>
                  <div class="form-check form-check-inline">
                      <input class="form-check-input" type="radio" name="cleaningStatus" id="cleanedNo" value="no">
                      <label class="form-check-label" for="cleanedNo">Non</label>
                  </div>
        <button type="submit" class="btn btn-danger btn-block">Mission fini (Arrivee au Depot)</button>
        </form>
        @elseif ($mission->finish_depot)  
        <br>
        <span class="text-success">Fin du Depot a {{ date('H:i', strtotime($mission->finish_depot)) }}</span> <small>Kilometrage  {{$mission->finish_km}}</small>
           <h1>Merci</h1>   
           @php
           $hareket = \Carbon\Carbon::parse($mission->hareket);
    $finishDepot = \Carbon\Carbon::parse($mission->finish_depot);

    // Farkı hesapla
    $diffInHours = $hareket->diffInHours($finishDepot);
    $diffInMinutes = $hareket->diffInMinutes($finishDepot) % 60; // 
@endphp

           Vous avez efectuer : {{$mission->finish_km-$mission->depart_km}} km   /  {{ $diffInHours }} heure(s) et {{ $diffInMinutes }} minute(s)
            @endif

          
           
        @endif
        <br>
        <ul class="list-group">
        <li class="list-group-item list-group-item-primary"> Trajet a Faire :</li>
        @foreach ($transfer->trajets as $index => $trajet)
                                  <li class="list-group-item"> 
                                  <span class="badge badge-primary badge-pill">{{$index+1}}</span>
                                    @if (date("Y-m-d") == date('Y-m-d', strtotime($trajet->datetime)))
    {{ date('H:i', strtotime($trajet->datetime)) }}
@else
    {{ date('d/m/Y H:i', strtotime($trajet->datetime)) }}
@endif
                                            {{$trajet->type}}:
                                            {{$trajet->from}}
                                            {{$trajet->google_address}} 
                                            <a href="https://www.google.com/maps/search/?api=1&query= {{$trajet->google_address}} " target="_blank">Google Map</a> /
              <a href="geo:0,0?q={{$trajet->google_address}}"> Map APP</a>
                                            
                                  </li> 
                                    @endforeach
    </ul>

        <a href="{{ url('/') }}" class="btn btn-secondary ">Home</a>
      </div>
    </div>
  </div>
@endsection
@section('scripts')
<script>
    function validateForm() {
        const cleaningStatus = document.querySelector('input[name="cleaningStatus"]:checked');
        if (!cleaningStatus) {
            alert("Merci de cocher la case de Netttoyage");
            return false; // Form gönderimini durdurur
        }
        return true; // Form gönderimine izin verir
    }
</script>
@endsection