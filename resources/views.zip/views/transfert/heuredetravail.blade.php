@extends('layouts.app')
@section('style')
  <link href="{{ asset('css/daterangepicker.css') }}" rel="stylesheet">
@endsection
@section('content')

<table class="table" id="AcentesTable">
    <tr>
        <th>Driver</th>
        @for($dayNumber = 0; $dayNumber <= $gecmisgun; $dayNumber++)
            <th @if ($dayNumber == 6) class="table-secondary" @endif>
                Jour {{ $dayNumber + 1 }}
                <br>
                {{ $dayNames[$dayNumber] }}
            </th>
        @endfor
        <th>Nombre de jours non travaillés</th>
    </tr>
    @foreach ($totalWorkingTime as $acenteId => $workedHoursPerDay)
        @if (isset($drivername[$acenteId]))
            <tr>
                <td>{{ $drivername[$acenteId] }}</td>
                @for($dayNumber = 0; $dayNumber <= $gecmisgun; $dayNumber++)
                    <?php $workedHour = isset($workedHoursPerDay[$dayNumber]) ? $workedHoursPerDay[$dayNumber] : false; ?>
                    <td>
                        @if ($workedHour)
                            {{ intdiv($workedHour, 60) . ':' . ($workedHour % 60) }} heures
                        @else
                            <span class="text-danger">ne pas travailler</span>
                        @endif
                    </td>
                @endfor
                <td>{{ $notWorkedCounts[$acenteId] }}</td>
            </tr>
        @else
            <tr class="d-none">
                <td></td>
            </tr>
        @endif
    @endforeach
</table>

<button id="exportButton" class="btn btn-secondary">
  <i class="fas fa-file-excel"></i> Exporter vers Excel
</button>
<button id="previousWeekButton" class="btn btn-secondary">
  <i class="fas fa-calendar-week"></i> Semaine précédente
</button>
<button id="thisWeekButton" class="btn btn-primary">
  <i class="fas fa-calendar-week"></i> Cette semaine
</button>
<a class="btn btn-primary" href="{{route('vehiculescontrol')}}">Utilisation des véhicules</a>
<a class="btn btn-primary" href="{{route('driverUsage.index')}}">Utilisation du conducteur</a>
<a href="{{ route('day') }}" class="btn btn-warning"> Shuttle</a>
<a href="{{ route('driver-calendar') }}" class="btn btn-warning"> Driver work time</a>

<small>!! Pour suivre le chauffeur, il faut l'ajouter depuis le suivi de l'acente</small>
@endsection

@section('footer')
<script>
    document.getElementById('exportButton').addEventListener('click', function() {
        var table = document.getElementById('AcentesTable');
        var html = table.outerHTML;
        var url = 'data:application/vnd.ms-excel,' + encodeURIComponent(html);
        var downloadLink = document.createElement("a");
        downloadLink.href = url;
        downloadLink.download = 'acentes.xls';
        document.body.appendChild(downloadLink);
        downloadLink.click();
        document.body.removeChild(downloadLink);
    });

    document.getElementById('previousWeekButton').addEventListener('click', function() {
        var currentUrl = new URL(window.location.href);
        var weekOffset = currentUrl.searchParams.get('weekOffset') || 0;
        weekOffset = parseInt(weekOffset) + 1;
        window.location.href = "{{ route('heuredetravail', '') }}/" + weekOffset;
    });

    document.getElementById('thisWeekButton').addEventListener('click', function() {
        window.location.href = "{{ route('heuredetravail', '') }}/0";
    });
</script>
@endsection
