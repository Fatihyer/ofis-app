@extends('layouts.app')

@section('content')

<div class="container">
    <div class="row justify-content-md-center mt-5">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">Edit Offset</div>
                <div class="card-body">
                    {{ Form::model($offset, array('route' => array('offsets.update', $offset->id), 'method' => 'PUT')) }}
                 <div  class="form-row">
                        <div class="col"> 
                           {{ Form::label('tarih',__('app.date') , array('for' => 'validationDefault01')) }}
                   {{ Form::date('tarih',date('Y-m-d',strtotime($offset->tarih)), array('class' => 'form-control')) }}
                         </div>
                            <div class="col"> 
                           {{ Form::label('time','Time' , array('for' => 'validationDefault01')) }}
                   {{ Form::time('time',date('H:i',strtotime($offset->tarih)), array('class' => 'form-control')) }}
                         </div>
                 
                  
                  </div>            

                 <div  class="form-row">
                  {{ Form::label('from', 'Kimden') }}
                  {{ Form::select('a_acente_id', $acentes, null, ['class' => 'form-control js-example-basic-single']) }}
                </div>   
                  <div  class="form-row">
                  {{ Form::label('to', 'Kime') }}
                  {{ Form::select('b_acente_id', $acentes, null, ['class' => 'form-control js-example-basic-single']) }}
                </div>
                  <div  class="form-row">
                   {{ Form::label('aciklama', 'Acıklama', array('for' => 'validationDefault01')) }}
                   {{ Form::text('aciklama', null, array('class' => 'form-control')) }}
                 </div> 
                  <div  class="form-row">
                   {{ Form::label('amount',__('app.amount'), array('for' => 'validationDefault01')) }}
                   {{ Form::number('amount',abs($offset->harekets->first()['amount']), array('class' => 'form-control','step'=>'.01')) }}
                 </div>
                  <div  class="form-row">
                   {{ Form::label('kur',__('app.exchange_name')) }}
                   {{ Form::select('kur_id',$kurs,$offset->harekets->first()['kur_id'], array('class' => 'form-control')) }}
                 </div>            



              <button class="btn btn-primary" type="submit">@lang('app.save')</button> <a href="{{ url()->previous() }}">Back</a>
            {{form::close()}}

               </div>
                        </div>
                    </div>
                </div>
            </div>

            @endsection

@section('footer')

<link href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.6-rc.0/css/select2.min.css" rel="stylesheet" />
<script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.6-rc.0/js/select2.min.js"></script>


<script>
$(document).ready(function() {
    $('.js-example-basic-single').select2();
});
</script>





@endsection
