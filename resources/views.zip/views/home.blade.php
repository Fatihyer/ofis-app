@extends('layouts.app')

@section('style')
<link href="{{ asset('css/daterangepicker.css') }}" rel="stylesheet">
<style>

/* styles.css */

.toast-container {
    position: fixed;
    top: 20px;
    right: 20px;
    z-index: 1000;
}

.toast {
    display: inline-block;
    padding: 10px 15px;
    margin-bottom: 10px;
    border-radius: 5px;
    color: #fff;
    opacity: 1;
    transition: opacity 0.5s ease-out;
}

.toast-success {
    background-color: #28a745;
}

.toast-error {
    background-color: #dc3545;
}

.toast-info {
    background-color: #17a2b8;
}

.toast-warning {
    background-color: #ffc107;
}


</style>
@endsection

@section('content')
<div class="toast-container">
  @foreach ($toastMessages as $message)
      <div class="toast toast-warning">
          {{ $message }}
      </div>
     


  @endforeach
  @foreach ($arabalar as $araba)
  @if (session('toast-danger-' . $araba->id))
      <div class="alert alert-danger">
          {{ session('toast-danger-' . $araba->id) }}
      </div>
  @endif
@endforeach

</div>
<div class="alert alert-light" role="alert">
    <a class="btn btn-danger btn-sm" href="{{ route('posts.index') }}">@lang('app.filelist')</a>
    <a class="btn btn-dark btn-sm" href="{{ route('acentes.index') }}">@lang('app.acente')</a>
    <a class="btn btn-warning btn-sm" href="{{ route('posts.create') }}">@lang('app.new_file')</a>
    <a class="btn btn-secondary btn-sm" href="{{ route('posts.createfromtransfert') }}">@lang('app.new_file') From @lang('app.transfers')</a>
    <a class="btn btn-danger btn-sm" href="{{ route('listegunluk') }}">Transfer Ciro</a>
    <a class="btn btn-success btn-sm" href="{{ route('heuredetravail') }}">Heure de Travail</a>
    <a class="btn btn-primary btn-sm" href="{{route('vehiculescontrol')}}">Vehicule Usage</a>
    <a class="btn btn-primary btn-sm" href="{{route('driverUsage.index')}}">Driver Usage</a>
    <button class="btn btn-primary">
        {{ Form::select('git', $filelist, "", ['onchange' => "location = 'posts/' + this.value;"]) }}
    </button>
</div>

<div class="alert alert-danger" role="alert">
    Transfer without DRIVER: 
    @foreach ($nodriver as $driver)
        <a href="{{ route('posts.show', $driver->post_id) }}">{{ $driver->post_id }}</a>
    @endforeach 
</div>

<div class="row">
    <div class="col-md-12 grid-margin">
        <div class="card">
            <div class="card-body">
                <h4 class="card-title">Transfer</h4>
                @if (session('status'))
                    <div class="alert alert-success">
                        {{ session('status') }}
                    </div>
                @endif

                <form method="get" name="tarih" class="form-inline">
                    <label>@lang('app.start_date'): </label>
                    <input type="text" name="daterange" class="form-control" value="{{ app('request')->input('daterange') }}" />
                    <input type="hidden" name="start_date" id="hiddenStartDate" />
                    <input type="hidden" name="end_date" id="hiddenEndDate" />
                
                    <!-- Buttons for Yesterday, Today, Tomorrow -->
                    <div class="btn-group" role="group">
                        <button type="submit" name="dateOption" value="yesterday" 
                            class="btn btn-outline-primary {{ app('request')->input('dateOption') === 'yesterday' ? 'btn-primary text-white' : '' }}">
                            Yesterday
                        </button>
                        <button type="submit" name="dateOption" value="today" 
                            class="btn btn-outline-primary {{ app('request')->input('dateOption') === 'today' ? 'btn-primary text-white' : '' }}">
                            Today
                        </button>
                        <button type="submit" name="dateOption" value="tomorrow" 
                            class="btn btn-outline-primary {{ app('request')->input('dateOption') === 'tomorrow' ? 'btn-primary text-white' : '' }}">
                            Tomorrow
                        </button>
                    </div>
                
                    <!-- Dropdowns for Driver and Vehicle -->
                    Driver: 
                    @if (is_array($driver))
                        {{ Form::select('driver', ['0' => 'sec', 'All' => 'All'] + $driver, app('request')->input('driver'), ['class' => 'form-control', 'onchange' => 'this.form.submit()']) }}
                    @endif
                
                    Vehicle: 
                    @if (is_array($vehicules))
                        {{ Form::select('vehicule', ['0' => 'sec', 'All' => 'All'] + $vehicules, app('request')->input('vehicule'), ['class' => 'form-control', 'onchange' => 'this.form.submit()']) }}
                    @endif
                     Acente
                    @if (is_array($acentes))
                        {{ Form::select('acente', ['0' => 'sec', 'All' => 'All'] + $acentes, app('request')->input('acente'), ['class' => 'form-control', 'onchange' => 'this.form.submit()']) }}
                    @endif
                     
                </form>
                
                <div class="table-responsive">
                    <table class="table table-bordered">
                        <thead>
                            <tr>
                                <th width="80px">@sortablelink('post_id', __('app.file'))</th>
                                <th>En route</th>
                                <th>@sortablelink('start_date', __('app.start_date'))</th>
                                <th>@sortablelink('end_date', 'Finish Time')</th>
                                <th>Fin de Mission reel</th>
                                <th>@sortablelink('post_id', __('app.acente'))</th>
                                <th>@sortablelink('servicetype_id', __('app.service'))</th>
                                <th>@sortablelink('driver_id', __('app.driver'))</th>
                                <th>Pax</th>
                                <th>@sortablelink('vehicule_id', 'Vehicule')</th>
                                <th>@lang('app.from')
                                ->@lang('app.to')</th>
                                <th>@lang('app.detail')</th>
                                <th>Client Name</th>
                            </tr>
                        </thead>
                        <tbody>
                            @foreach($transfers as $key => $transfer)

                             @php
                                    $googleAddresses = $transfer->trajets->pluck('google_address');
                                    $origin = $googleAddresses->first(); // İlk değer origin
                                    $destination = $googleAddresses->last(); // Son değer destination
                                    $waypoints = $googleAddresses->slice(1, $googleAddresses->count() - 2)->implode('|'); // Aradakiler waypoints
                                    @endphp
                                <tr>
                                    <td class="align-middle">
                                        <a href="{{ route('transfers.show', $transfer->id ) }}"><i class="fa fa-eye" aria-hidden="true"></i></a>
                                        <a href="{{ route('posts.show', $transfer->post->id ) }}">{{ $transfer->post->id }}</a>
                                        @if ($transfer->mission == true)
                                            <i class="fa fa-bullhorn" aria-hidden="true"></i>
                                        
                                            <a href="{{ route('mission', $transfer->id ) }}"><i class="fa fa-binoculars" aria-hidden="true"></i></a>
                                        @endif
                                        @if ($transfer->post->user)
                                            <small class="text-warning">{{ $transfer->post->user->name }}</small>
                                        @endif
                                        @if ($transfer->called_at == true)
                                            <i class="fa fa-phone" aria-hidden="true"></i> called at {{ date('H:i', strtotime($transfer->called_at)) }}
                                        @endif
                                    </td>
                                    <th>
                                        <small>
                                            @if ($transfer->ofis_start == null)
                                                <span class="text-danger">No time defined</span>
                                            @else
                                                {{ date('d-m H:i',strtotime($transfer->ofis_start ))}}
                                            @endif
                                        </small>
                                    </th>
                                    <td class="align-middle">
                                        @if (date("Y-m-d") == date('Y-m-d', strtotime($transfer->start_date)))
                                            {{ date('H:i', strtotime($transfer->start_date)) }}
                                            @if ($transfer->servicetype->name == 'MAD')
                                                to {{ date('H:i', strtotime($transfer->end_date)) }}
                                            @endif
                                        @else
                                            {{ date('d/m/Y H:i', strtotime($transfer->start_date)) }}
                                        @endif
                                    </td>
                                    <td class="align-middle">
                                        {{ date('H:i', strtotime($transfer->end_date)) }}
                                    </td>
                                    <td class="align-middle">
                                        @if ($transfer->missionr)
                                            @if($transfer->missionr->finish)
                                                <span class="text-danger">{{ date('H:i', strtotime($transfer->missionr->finish)) }}</span>
                                            @else
                                                <span class="text-success">En Mission</span>
                                            @endif
                                        @endif
                                    </td>
                                    <td bgcolor="{{ isset($transfer->post->acente->color) ? $transfer->post->acente->color : '#000' }}" class="align-middle">
                                        <a class="text-white" href="{{ route('acentes.show', $transfer->post->acente->id ) }}?src=file">{{ $transfer->post->acente->name }}</a>
                                    </td>
                                    <td class="align-middle">{{ $transfer->servicetype->name }}</td>
                                    @if (isset($transfer->driver->name))
                                        <td class="align-middle" bgcolor="{{ isset($transfer->driver->color) ? $transfer->driver->color : '#FFF' }}">
                                            <a class="text-dark" href="{{ route('acentes.show', $transfer->driver->id) }}?src=service">{{ $transfer->driver->name }}</a>
                                        </td>
                                    @else 
                                        <td>NO DRIVER</td>
                                    @endif
                                    <td @if ($transfer->pax > 8) bgcolor='black' class="text-white" @endif>{{ $transfer->pax }}</td>
                                    <th @if (optional($transfer->vehicule)->capacity > 8) bgcolor='black' class="text-white" @endif>
                                   @if ($transfer->vehicule)
                                        <a href="{{ route('vehicules.show', $transfer->vehicule_id) }}">{{ $transfer->vehicule->name }}</a>
                                        
                                        @if($transfer->vehicule && $transfer->vehicule->hermes_uid)
                                     
                                        <button class="btn btn-sm btn-outline-info show-map"
                                            data-uid="{{ $transfer->vehicule->hermes_uid }}"
                                            data-name="{{ $transfer->vehicule->name }}"
                                            data-origin="{{ $origin }}"
                                            data-destination="{{ $destination }}"
                                            data-waypoints="{{ $waypoints }}">
                                            <i class="fas fa-map-marker-alt"></i>
                                        </button>
                                        
                                        @endif
                                    @else
                                        <span class="text-danger">NO VEHICULE</span>
                                    @endif

                                    </th>
                                   
                                    <td class="table-{{ isset($transfer->status->color->name)?$transfer->status->color->name:'' }} align-middle">{{ $transfer->from }}->
                                    {{$transfer->target }}
                                    @if ($transfer->trajets->count() == 0)
                                    <span class="text-danger"> !!!!!!bunlar eski yeniden bilgiler  girin</span><br>
                                    @else
                                    <ul class="list-group">                                    @foreach ($transfer->trajets as $index => $trajet)
                                  <li class="list-group-item"> 
                                    <span class="badge badge-primary badge-pill">{{$index+1 }}</span>
                                    @if (date("Y-m-d") == date('Y-m-d', strtotime($trajet->datetime)))
    {{ date('H:i', strtotime($trajet->datetime)) }}
@else
    {{ date('d/m/Y H:i', strtotime($trajet->datetime)) }}
@endif
                                            {{$trajet->type}}:
                                            {{$trajet->from}}
                                            {{$trajet->google_address}}
                                            
                                  </li> 
                                    @endforeach
                                   
                                </ul>
                                <a href="https://www.google.com/maps/dir/?api=1&origin={{ $origin }}&waypoints={{ $waypoints }}&destination={{ $destination }}" target="_blank">
                               Map </a>    
                                TOTAL KM:{{$transfer->km }} 
                                        @endif
                                </td>
                                    <td class="table-{{ isset($transfer->status->color->name) ? $transfer->status->color->name : '' }} align-middle">
                                        @php
                                            $comment = $transfer->comments;
                                            $isLong = strlen($comment) > 100;
                                            $shortComment = $isLong ? substr($comment, 0, 100) . '...' : $comment;
                                        @endphp
                                
                                        <span class="comment-text">{{ $shortComment }}</span>
                                        
                                        @if($isLong)
                                          
                                            <div id="fullComment-{{ $key }}" class="collapse">{{ $comment }}</div>
                                            <a href="#" class="read-more" data-toggle="collapse" data-target="#fullComment-{{ $key }}">Read more</a>
                                        @endif
                                    </td>
                                    <td>
                                    @hasanyrole('Admin|ofis')  
                                    <a class="btn btn-primary btn-sm" href="{{route('transfers.edit',$transfer->id)}}" >Edit Transfert</a>
                          
                                        </a>
                                    @endhasanyrole  

                             Chauffeur:     <span class="text" > {{isset($transfer->status->name)?$transfer->status->name:''}} </span>
                                  @if ($transfer->client_status_id==false)
                                <br>  <span class="text-danger" >   Les details du chauffeur ne sont pas envoyer au client</span>
                                  @endif
                                    @if ($transfer->accueil==true)
                                  <br>    !!!!! Pano d'acceuil !!!!!
                                  @endif  
                                    </td>
                                </tr>
                            @endforeach
                        </tbody>
                    </table>
                    {!! $transfers->appends(\Request::except('page'))->links('vendor/pagination/bootstrap-4') !!}
                </div>
            </div>
        </div>
    </div>

    <div class="alert alert-warning" role="alert">
        File without Invoice: 
        @foreach ($faturasiz as $fatura)
            <a href="{{ route('posts.show', $fatura->id) }}">{{ $fatura->id }}</a>
        @endforeach
    </div>
</div>

<div class="modal fade" id="mapModal" tabindex="-1" role="dialog">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
      <div class="modal-header"><h5 class="modal-title" id="mapTitle">Araç Konumu</h5></div>
      <div class="modal-body">
        <div id="map" style="height: 400px;"></div>
      </div>
    </div>
  </div>
</div>
<!-- Sayfanın başına dön butonu -->
<button id="scrollTopBtn" onclick="scrollToTop()" 
    class="btn btn-primary rounded-circle shadow"
    style="display:none; position: fixed; bottom: 30px; right: 90px; z-index: 1050; width: 50px; height: 50px;">
    <i class="fas fa-arrow-up"></i>
</button>

<!-- Sayfanın en altına git butonu -->
<button onclick="scrollToBottom()" 
    class="btn btn-secondary rounded-circle shadow"
    style="position: fixed; bottom: 30px; right: 30px; z-index: 1050; width: 50px; height: 50px;">
    <i class="fas fa-arrow-down"></i>

</button>
@endsection

@section('footer')
<script src="{{ asset('/js/moment.min.js') }}"></script>
<script src="{{ asset('/js/daterangepicker.js') }}"></script>
<script>
    $('input[name="daterange"]').daterangepicker({
        locale: {
            format: 'DD/MM/YYYY'
        }
    });

    $('input[name="daterange"]').on('apply.daterangepicker', function(ev, picker) {
        $('#hiddenStartDate').val(picker.startDate.format('YYYY-MM-DD'));
        $('#hiddenEndDate').val(picker.endDate.format('YYYY-MM-DD'));
        var x = document.getElementsByName('tarih');
        x[0].submit(); // Form submission
    });

    document.addEventListener('DOMContentLoaded', function() {
        setTimeout(() => {
            document.querySelectorAll('.toast').forEach(toast => {
                toast.style.display = 'none';
            });
        }, 5000); // 5 saniye sonra toast mesajlarını gizler
    });

    @if (session('toast-danger'))
        toastr.error("{{ session('toast-danger') }}");
    @endif
</script>


<script 
    src="https://maps.googleapis.com/maps/api/js?key={{ config('services.google_maps.api_key') }}" 
    async defer>
</script>
<script>$(document).on('click', '.show-map', function () {

   function getIconByStatus(code) {
    switch (code) {
        case 0: return 'https://maps.google.com/mapfiles/ms/icons/red-dot.png'; // Arrêt
        case 1: return 'https://maps.google.com/mapfiles/ms/icons/green-dot.png'; // Conduit
        case 2: return 'https://maps.google.com/mapfiles/ms/icons/yellow-dot.png'; // Moteur tournant
        default: return 'https://maps.google.com/mapfiles/ms/icons/blue-dot.png'; // bilinmiyor
    }
}


 

   const uid = $(this).data('uid');
    const name = $(this).data('name');
    const origin = $(this).data('origin');
    const destination = $(this).data('destination');
    const waypointsStr = $(this).data('waypoints');

    $.get(`/hermes/location/${uid}`, function (res) {
        if (res.latitude && res.longitude) {
            const pos = { lat: parseFloat(res.latitude), lng: parseFloat(res.longitude) };

            const map = new google.maps.Map(document.getElementById("map"), {
                center: pos,
                zoom: 10
            });

            new google.maps.Marker({
                position: pos,
                map: map,
                title: name,
                icon: getIconByStatus(res.status_code)
            });

            if (origin && destination) {
                const directionsService = new google.maps.DirectionsService();
                const directionsRenderer = new google.maps.DirectionsRenderer();
                directionsRenderer.setMap(map);

                const waypoints = waypointsStr
                    ? waypointsStr.split('|').map(location => ({ location, stopover: true }))
                    : [];

                directionsService.route({
                    origin: origin,
                    destination: destination,
                    waypoints: waypoints,
                    travelMode: google.maps.TravelMode.DRIVING
                }, function (result, status) {
                    if (status === google.maps.DirectionsStatus.OK) {
                        directionsRenderer.setDirections(result);
                    } else {
                        console.error('Directions request failed due to ' + status);
                    }
                });
            }

            $('#mapTitle').text(name + ' - ' + res.status);
            $('#mapModal').modal('show');
        } else {
            alert('Konum alınamadı.');
        }
    });
});

function scrollToTop() {
    window.scrollTo({
        top: 0,
        behavior: 'smooth'
    });
}
function scrollToBottom() {
    window.scrollTo({
        top: document.body.scrollHeight,
        behavior: 'smooth'
    });
}
document.addEventListener('scroll', function () {
    const btn = document.getElementById('scrollTopBtn');
    btn.style.display = window.scrollY > 300 ? 'block' : 'none';
});

</script>

@endsection
